﻿using BlogBase.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNet.Identity;

namespace BlogBase.Controllers
{
    public class BlogController : Controller
    {
        private IRepository repository;

        public BlogController()
        {
            repository = new Repository();
        }

        public BlogController(IRepository repo)
        {
            this.repository = repo;
        }

        //
        // GET: /Blog/
        public ActionResult Index(int blogId)
        {
            return View(repository.getBlog(blogId));
        }

        [Authorize]
        public ActionResult CreateBlog(string blogName, Boolean postable)
        {
            string userId = repository.getUserByName(User.Identity.Name).Id;
            Blog blog = new Blog() { Name = blogName, Postable = postable, OwnerId = userId, LastUpdated = DateTime.Now };
            int blogId = repository.saveBlog(blog);
            return RedirectToAction("Index", new { blogId = blogId });
        }

        [Authorize]
        public ActionResult savePost(int blogId, string text, string title, string userName)
        {
            IUser user = repository.getUserByName(userName);
            Post post = new Post() { BlogId = blogId, Text = text, Title = title, OwnerId = user.Id };
            repository.savePost(post);
            return RedirectToAction("Index", new { blogId = blogId });
        }

        [Authorize]
        public ActionResult deletePost(int postId)
        {
            int blogId = 0;
            if (repository.isPostOwner(User.Identity.GetUserId(), postId)) {
                Post post = repository.getPost(postId);
                blogId = post.BlogId;
                repository.deletePost(post);
            }
            return RedirectToAction("Index", new { blogId = blogId });
        }

        [Authorize]
        public ActionResult updatePost(int postId, string title, string text)
        {
            Post post = repository.getPost(postId);
            int blogId = post.BlogId;
            repository.updatePost(post, title, text);
            return RedirectToAction("Index", new { blogId = blogId });
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using BlogBase.Models;
using System.Web.Http.Description;

namespace BlogBase.Controllers
{
    public class WebController : ApiController
    {
        private MyDbContext db = new MyDbContext();
        private readonly IRepository Repository;

        public WebController() {
            Repository = new Repository();
        }

        public WebController(IRepository Repository) {
            this.Repository = Repository;
        }

        [ResponseType(typeof(List<Comment>))]
        [HttpGet]
        public IHttpActionResult GetComments(int postId) {
            List<Comment> comments = Repository.getComments(postId);
            return Ok(comments);
        }

        [ResponseType(typeof(int))]
        [HttpPost]
        public IHttpActionResult PostComment(CommentPost post) {
            string userId = Repository.getUserByName(User.Identity.Name).Id;
            int commentId = Repository.postComment(post.postId, post.text, userId);
            return Ok(commentId);
        }
    }
}

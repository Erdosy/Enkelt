﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace BlogBase.Models
{
    public interface IRepository 
    {
        List<Blog> getAllBlogs();
        List<Post> getAllPosts(int blogId);
        int saveBlog(Blog blog);
        void savePost(Post post);
        Blog getBlog(int blogId);
        Post getPost(int postId);
        void deletePost(Post post);
        void updatePost(Post post, string newTitle, string newText);
        ApplicationUser getUserByName(string name);
        bool isBlogOwner(string userId, int blogId);
        bool isPostOwner(string userId, int postId);
        bool isCommentOwner(string userId, int commentId);
        List<Comment> getComments(int postId);
        int postComment(int postId, string text, string userId);
    }
}
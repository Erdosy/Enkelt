﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ComponentModel.DataAnnotations;
using System.Web.Mvc;
using BlogBase.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace BlogBase.Models
{
    public class Repository : IRepository
    {
        private MyDbContext myDbContext;

        public Repository()
        {
            myDbContext = new MyDbContext();
        }

        [Authorize]
        public void savePost(Post post)
        {
            myDbContext.Posts.Add(post);
            myDbContext.SaveChanges();
        }

        [Authorize]
        public int saveBlog(Blog blog)
        {
            myDbContext.Blogs.Add(blog);
            myDbContext.SaveChanges();
            return blog.Id;
        }

        public List<Post> getAllPosts(int blogId)
        {
            var result = from post in myDbContext.Posts
                         where post.BlogId == blogId
                         select post;
            return result.ToList<Post>();
        }

        public List<Blog> getAllBlogs()
        {
            return myDbContext.Blogs.ToList();
            
        }

        public Blog getBlog(int blogId)
        {
            Blog result = myDbContext.Blogs.Single(i => i.Id == blogId);
            return result;
        }

        public Post getPost(int postId)
        {
            Post result = myDbContext.Posts.Single(i => i.Id == postId);
            return result;
        }

        [Authorize]
        public void deletePost(Post post)
        {
            var comments = myDbContext.Comments.Where(c => c.PostId == post.Id);
            foreach(Comment comment in comments) {
                myDbContext.Comments.Remove(comment);
            }
            myDbContext.Posts.Remove(post);
            myDbContext.SaveChanges();
        }

        [Authorize]
        public void updatePost(Post post, string newTitle, string newText) { 
            post.Text = newText;
            post.Title = newTitle;
            myDbContext.Entry(post).State = System.Data.Entity.EntityState.Modified;
            myDbContext.SaveChanges();
        }

        public bool isBlogOwner(string userId, int blogId)
        {
            Blog blog = myDbContext.Blogs.Single(i => i.Id == blogId);
            return (blog.OwnerId == userId);
        }

        public bool isPostOwner(string userId, int postId) {
            Post post = myDbContext.Posts.Single(i => i.Id == postId);
            return (post.OwnerId == userId);
        }

        public bool isCommentOwner(string userId, int commentId) {
            Comment comment = myDbContext.Comments.Single(i => i.Id == commentId);
            return (comment.OwnerId == userId);
        }

        public ApplicationUser getUserByName(string name)
        {
            UserManager<ApplicationUser> userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(new ApplicationDbContext()));
            return userManager.FindByName(name);
        }

        public List<Comment> getComments(int postId) {
            List<Comment> comments = myDbContext.Comments.Where(c => c.PostId == postId).ToList();
            return comments;
        }

        public int postComment(int postId, string text, string userId) {
            Comment comment = new Comment() { PostId = postId, Text = text, OwnerId = userId };
            myDbContext.Comments.Add(comment);
            myDbContext.SaveChanges();
            return comment.Id;
        }
    }
}
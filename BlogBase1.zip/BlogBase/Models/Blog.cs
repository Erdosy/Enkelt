﻿using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BlogBase.Models
{
    public class Blog
    {

        public Blog()
        {
            this.Post = new HashSet<Post>();
        }

        [Key]
        public int Id { get; set; }
        public bool Postable { get; set; }

        [Required]
        public string Name { get; set; }
        public DateTime LastUpdated { get; set; }
        public String Lead { get; set; }

        [Required]
        public string OwnerId { get; set; }

        public virtual ICollection<Post> Post { get; set; }
    }
}

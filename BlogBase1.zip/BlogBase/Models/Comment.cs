﻿
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BlogBase.Models
{


    public class Comment
    {
        [Key]
        public int Id { get; set; }
        public string Text { get; set; }
        [Required]
        public string OwnerId { get; set; }
        [Required]
        public int PostId { get; set; }
        
    }

    public class CommentPost {
        public int postId { get; set; }
        public string text { get; set; }
    }
    
}
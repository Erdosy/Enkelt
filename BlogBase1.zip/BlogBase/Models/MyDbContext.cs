﻿using System.Data.Entity;

namespace BlogBase.Models
{
    public class MyDbContext: DbContext
    {
        public DbSet<Blog> Blogs { get; set; }
        public DbSet<Post> Posts { get; set; }
        public DbSet<Comment> Comments { get; set; }
        //public DbSet<ApplicationUser> User { get; set; }

        public MyDbContext()
            : base("DefaultConnection") {}
    }
}
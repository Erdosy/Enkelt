﻿
using Microsoft.AspNet.Identity;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace BlogBase.Models
{


    public class Post
    {
        [Key]
        public int Id { get; set; }
        public string Title { get; set; }
        public string Text { get; set; }
        [Required]
        public string OwnerId { get; set; }
        [Required]
        public int BlogId { get; set; }

        
    }
}
﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using BlogBase.Controllers;
using BlogBase.Models;
using System.Collections.Generic;
using System.Web.Http.Results;
using System.Security.Principal;

namespace BlogBase.Tests.Controllers {
    [TestClass]
    public class WebControllerTest {

        private Mock<IRepository> _repository = new Mock<IRepository>();

        [TestMethod]
        public void showComments() {
            //Arrange
            List<Comment> fakeComments = new List<Comment>();
            fakeComments.Add(new Comment { Id = 1, OwnerId = "test", PostId = 1, Text = "Testing text 1" });
            fakeComments.Add(new Comment { Id = 2, OwnerId = "test", PostId = 1, Text = "Testing text 2" });
            fakeComments.Add(new Comment { Id = 3, OwnerId = "test2", PostId = 1, Text = "Testing text 3" });
            _repository.Setup(x => x.getComments(1)).Returns(fakeComments);
            WebController controller = new WebController(_repository.Object);

            //Act
            var result = controller.GetComments(1) as OkNegotiatedContentResult<List<Comment>>;

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(fakeComments, result.Content);
        }

        [TestMethod]
        public void postComment() {
            //Arrange
            _repository.Setup(x => x.postComment(1, "test", "userId")).Returns(1);
            ApplicationUser user = new ApplicationUser() { UserName = "test", Id = "userId" };
            _repository.Setup(x => x.getUserByName("test")).Returns(user);
            WebController controller = new WebController(_repository.Object);
            var principal = new Moq.Mock<IPrincipal>();
            principal.Setup(x => x.Identity.Name).Returns("test");
            controller.User = principal.Object;


            //Act
            var result = controller.postComment(1, "test") as OkNegotiatedContentResult<int>;

            //Assert
            Assert.IsNotNull(result);
            Assert.AreEqual(1, result.Content);
        }
    }
}

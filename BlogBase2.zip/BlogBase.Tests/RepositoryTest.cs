﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using BlogBase;
using BlogBase.Controllers;
using BlogBase.Models;
using Moq;


namespace BlogBase.Tests
{
    [TestClass]
    public class RepositoryTest
    {
        private List<Blog> blogs = new List<Blog>();
        private List<Post> posts = new List<Post>();
        private Mock<IRepository> _repository = new Mock<IRepository>();

        [TestInitialize]
        public void testInit()
        {

            // Populate blogs
            blogs.Add(new Blog() { Id = 1, Name = "Blog1", Postable = true });
            blogs.Add(new Blog() { Id = 2, Name = "Blog2", Postable = true });
            blogs.Add(new Blog() { Id = 3, Name = "Blog3", Postable = false });

            // Populate posts
            posts.Add(new Post() { Id = 1, BlogId = 1, Title = "First post", Text = "This is the first post in blog1" });
            posts.Add(new Post() { Id = 2, BlogId = 2, Title = "First post", Text = "This is the first post in blog2" });
            posts.Add(new Post() { Id = 3, BlogId = 2, Title = "Second post", Text = "This is the second post in blog2" });
            posts.Add(new Post() { Id = 4, BlogId = 1, Title = "Second post", Text = "This is the second post in blog1" });
            posts.Add(new Post() { Id = 5, BlogId = 2, Title = "Third post", Text = "This is the third post in blog2" });
            posts.Add(new Post() { Id = 6, BlogId = 1, Title = "Third post", Text = "This is the third post in blog1" });
        }

        [TestMethod]
        public void indexReturnsListOfBlogs()
        {
            // Arrange
            _repository.Setup(x => x.getAllBlogs()).Returns(blogs);
            var controller = new HomeController(_repository.Object);

            // Act
            var result = (ViewResult)controller.Index();

            // Assert
            CollectionAssert.AllItemsAreInstancesOfType((System.Collections.ICollection)result.ViewData.Model, typeof(Blog), "Not all instances of the Blog type");
            var blogsFromRepo = result.ViewData.Model as List<Blog>;
            Assert.AreEqual(blogs, blogsFromRepo);
        }

        [TestMethod]
        public void blogReturnsListOfPostsFromABlog()
        {
            // Arrange
            List<Post> fakePosts = new List<Post>();
            foreach (Post post in posts)
            {
                if (post.BlogId == 1)
                    fakePosts.Add(post);
            }
            _repository.Setup(x => x.getAllPosts(1)).Returns(fakePosts);
            var controller = new BlogController(_repository.Object);

            // Act
            ViewResult result = (ViewResult)controller.Index(1);

            // Assert
            Blog resultBlog = (Blog)result.ViewData.Model;
            List<Post> resultPosts = (List<Post>)resultBlog.Post;
            CollectionAssert.AllItemsAreInstancesOfType((System.Collections.ICollection)resultPosts, typeof(Post), "Not all instance of the Post type");
            var postsFromRepo = result.ViewData.Model as List<Post>;
            Assert.AreEqual(fakePosts, postsFromRepo);
        }
    }
}

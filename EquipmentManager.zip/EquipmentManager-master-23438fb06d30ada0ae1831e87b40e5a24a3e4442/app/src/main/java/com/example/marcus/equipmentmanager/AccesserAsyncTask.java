package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.os.AsyncTask;
import android.util.Pair;

import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.util.EntityUtils;

import java.io.IOException;
import java.util.List;

/**
 * Handles queries from QueryHandler class against backend in different thread
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
@SuppressWarnings({"deprecation", "unchecked"})
public class AccesserAsyncTask extends AsyncTask<Pair<List<NameValuePair>, HttpClient>, Void, String> {

    private Context context; // active calling context
    String queryType; // defines query type against backend

    /**
     * Constructor
     *
     * @param context context to use
     */
    public AccesserAsyncTask(Context context) {
        this.context = context;
    }

    @Override
    protected String doInBackground(Pair<List<NameValuePair>, HttpClient>... params) {
        Pair pair = params[0];
        List<NameValuePair> urlParams = (List<NameValuePair>) pair.first;
        NameValuePair query = urlParams.get(0);
        queryType = query.getValue();
        HttpClient httpClient = (HttpClient) pair.second;
        try {
            String serverUrl = "http://kark.hin.no:8088/d3330log_backend/" + queryType;
            urlParams.remove(0);
            HttpPost httpPost = new HttpPost(serverUrl);
            httpPost.setEntity(new UrlEncodedFormEntity(urlParams));
            HttpResponse response = httpClient.execute(httpPost);
            if (response.getStatusLine().getStatusCode() == 200) {
                return EntityUtils.toString(response.getEntity());
            } else {
                return context.getString(R.string.error) + response.getStatusLine().getStatusCode() + " " + response.getStatusLine().getReasonPhrase();
            }
        } catch (ClientProtocolException e) {
            return e.getMessage();
        } catch (IOException e) {
            return e.getMessage();
        }
    }

    @Override
    protected void onPostExecute(String result) {
        ((MainActivity) context).showResult(result, queryType);
    }
}

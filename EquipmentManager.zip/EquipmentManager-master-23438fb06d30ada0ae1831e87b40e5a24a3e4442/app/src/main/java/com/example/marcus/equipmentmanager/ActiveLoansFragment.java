package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Handle Active Loans Fragment.
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class ActiveLoansFragment extends Fragment implements View.OnClickListener {

    View view; // active view
    QueryHandler queryHandler; // handles queries from application
    ResponseHandler responseHandler; // handles response strings from backend
    ListView lvLoans; // listview of active loans
    String response; // response string from backend
    int index; // index of selected item in listview
    LayoutInflater inflater; // inflater to inflate views
    ViewGroup container; // container for view
    ArrayList<Equipment> equipmentList; // list of equipment
    ArrayList<User> userList; // list of users
    ArrayList<LogEntry> loans; // list of log entries
    User user; // current user
    Equipment equipment; // current equipment
    LogEntry loan; // current logentry


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_active_loans, container, false);
        this.container = container;
        this.inflater = inflater;
        ((MainActivity) getActivity()).setIsLoanUser(true);
        ((MainActivity) getActivity()).setIsLoanLog(true);
        ((MainActivity) getActivity()).setIsLoanEquipment(true);
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        queryHandler.getOpenLogEntries();
        queryHandler.getActiveUsers();
        queryHandler.getEquipment("IN_USE");
        responseHandler = new ResponseHandler(getActivity());
        lvLoans = (ListView) view.findViewById(R.id.lvLoanList);
        Button btnLoanDetails = (Button) view.findViewById(R.id.btnLoanDetails);
        btnLoanDetails.setOnClickListener(this);
        Button btnEndLoan = (Button) view.findViewById(R.id.btnEndLoan);
        btnEndLoan.setOnClickListener(this);
        return view;
    }

    /**
     * Populates list view, sets adapter and onItemClickListener
     */
    public void populateList() {
        LoanAdapter loanAdapter = new LoanAdapter(getActivity(), R.layout.loan_short, loans, equipmentList, userList);
        lvLoans.setAdapter(loanAdapter);
        lvLoans.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                index = position;
            }
        });
    }

    @Override
    public void onClick(View v) {
        loan = (LogEntry) lvLoans.getItemAtPosition(index);
        switch (v.getId()) {
            case R.id.btnLoanDetails:
                ((MainActivity) getActivity()).setLoanDetailsFragment(loan);
                break;
            case R.id.btnEndLoan:
                SimpleDateFormat sdf = new SimpleDateFormat("dd.mm.yyyy", Locale.US);
                String dateOut = sdf.format(new Date());
                queryHandler.registerReservationIn(loan.getLe_id(), dateOut);
                break;
        }
    }

    /**
     * Sets equipment list from response json string
     *
     * @param response response message from backend
     */
    public void setEquipment(String response) {
        equipmentList = responseHandler.getEquipmentResponse(response);
        if (loans != null && equipmentList != null && userList != null) {
            populateList();
        }
    }

    /**
     * Sets loans from response json string
     *
     * @param response response message from backend
     */
    public void setLoans(String response) {
        loans = responseHandler.getOpenLogEntriesForUserResponse(response);
        if (loans != null && equipmentList != null && userList != null) {
            populateList();
        }
    }

    /**
     * Sets users from response json string
     *
     * @param response response message from backend
     */
    public void setUsers(String response) {
        userList = responseHandler.getActiveUsersResponse(response);
        if (loans != null && equipmentList != null && userList != null) {
            populateList();
        }
    }
}

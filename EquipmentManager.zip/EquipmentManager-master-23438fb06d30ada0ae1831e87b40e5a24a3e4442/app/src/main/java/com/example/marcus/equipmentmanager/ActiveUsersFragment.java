package com.example.marcus.equipmentmanager;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Handle Active Users Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
*/
public class ActiveUsersFragment extends Fragment implements View.OnClickListener{

    QueryHandler queryHandler; // handles queries from application
    View view; // active view
    String response; // response string from backend
    ResponseHandler responseHandler; // handles response strings from backend
    ListView lvUsers; // list view of active users
    int index; // index of selected item in list view
    int userId;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_active_users, container, false);
        queryHandler = ((MainActivity)getActivity()).getQueryHandler();
        queryHandler.getActiveUsers();
        responseHandler = new ResponseHandler(getActivity());
        lvUsers = (ListView)view.findViewById(R.id.lvUserList);
        Button btnDeleteUser = (Button)view.findViewById(R.id.btnDeleteUser);
        btnDeleteUser.setOnClickListener(this);
        Button btnEditUser = (Button)view.findViewById(R.id.btnEditUser);
        btnEditUser.setOnClickListener(this);
        return view;
    }

    /**
     * Populates list view, sets adapter and onItemClickListener
     *
     * @param response response message from backend
     */
    public void populateList(String response) {
        ArrayList<User> users = responseHandler.getNotActivatedUsersResponse(response);
        UserAdapter userAdapter = new UserAdapter(getActivity(), R.layout.user_short , users);
        lvUsers.setAdapter(userAdapter);
        lvUsers.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                index = position;
            }
        });
    }

    @Override
    public void onClick(View v) {
        User user = (User)lvUsers.getItemAtPosition(index);
        userId = user.getU_id();
        switch(v.getId()) {
            case R.id.btnEditUser:
                ((MainActivity)getActivity()).setSelectedUser(user);   //Saves the selected user in mainactivity so it can be retrieved by the userprofile fragment.
                ((MainActivity)getActivity()).setUserProfileFragment();
                break;
            case R.id.btnDeleteUser:
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage(R.string.areYouSure)
                        .setTitle(R.string.deleteUser);
                builder.setPositiveButton(R.string.deleteOk, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        queryHandler.deleteUser(userId);
                    }
                });
                builder.setNegativeButton(R.string.deleteCancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.show();
                break;
        }
    }
}


package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

import java.util.ArrayList;

/**
 * Handle Add User Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class AddUserFragment extends Fragment implements View.OnClickListener {
    View view; // active view
    QueryHandler queryHandler; // handles queries from application to backend
    User user; // user object to be added

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        view = inflater.inflate(R.layout.fragment_add_user, container, false);
        Button button = (Button) view.findViewById(R.id.btnSaveUser);
        button.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSaveUser:
                if (((EditText) view.findViewById(R.id.etEditPassword)).getText().toString().
                        equals(((EditText) view.findViewById(R.id.etRepeatPassword)).getText().toString())) {
                    User user = new User();
                    user.setUserName(((EditText) view.findViewById(R.id.etUserName)).getText().toString());
                    user.setFirstname(((EditText) view.findViewById(R.id.etFirstName)).getText().toString());
                    user.setLastname(((EditText) view.findViewById(R.id.etLastName)).getText().toString());
                    user.setPhone(((EditText) view.findViewById(R.id.etPhoneNumber)).getText().toString());
                    user.setPassword(((EditText) view.findViewById(R.id.etEditPassword)).getText().toString());
                    if (((MainActivity) getActivity()).getLoggedIn() == 2) {
                        queryHandler.addUser(user);
                    } else {
                        queryHandler.addUserWithoutLogin(user);
                    }
                }
                break;
        }
    }

    /**
     * Confirms selected user
     *
     * @param response        json string with not active users
     * @param responseHandler handles responses from backend
     */
    public void confirmUser(String response, ResponseHandler responseHandler) {
        ArrayList<User> notActiveUsers = responseHandler.getNotActivatedUsersResponse(response);
        for (int i = 0; i < notActiveUsers.size(); i++) {
            if (notActiveUsers.get(i).getUserName().equals(user.getUserName()) && notActiveUsers.get(i).
                    getPhone().equals(user.getPhone())) {
                queryHandler.confirmRegisteredUser(notActiveUsers.get(i).getU_id());
            }
        }
    }
}

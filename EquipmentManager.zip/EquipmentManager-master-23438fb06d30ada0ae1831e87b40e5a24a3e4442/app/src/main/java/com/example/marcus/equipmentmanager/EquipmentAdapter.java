package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Custom adapter for equipment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class EquipmentAdapter extends ArrayAdapter<Equipment> {

    private ArrayList<Equipment> items; // list of equipment
    private Context context; // context to use

    /**
     * Constructor
     *
     * @param context            context to use
     * @param textViewResourceId resource to use for list
     * @param items              items to list out
     */
    public EquipmentAdapter(Context context, int textViewResourceId, ArrayList<Equipment> items) {
        super(context, textViewResourceId, items);
        this.items = items;
        this.context = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = vi.inflate(R.layout.equipment_short, null);
        }
        Equipment equipment = items.get(position);
        if (equipment != null) {
            TextView tvEquipmentType = (TextView) v.findViewById(R.id.tvEquipmentType);
            TextView tvEquipmentItNo = (TextView) v.findViewById(R.id.tvEquipmentItNo);
            TextView tvEquipmentBrand = (TextView) v.findViewById(R.id.tvEquipmentBrand);
            TextView tvEquipmentModel = (TextView) v.findViewById(R.id.tvEquipmentModel);
            Context context = getContext();
            if (tvEquipmentType != null)
                tvEquipmentType.setText(context.getString(R.string.equipmentType) + ": " + equipment.getType());
            if (tvEquipmentItNo != null)
                tvEquipmentItNo.setText(context.getString(R.string.equipmentItNo) + ": " + equipment.getIt_no());
            if (tvEquipmentBrand != null)
                tvEquipmentBrand.setText(context.getString(R.string.equipmentBrand) + ": " + equipment.getBrand());
            if (tvEquipmentModel != null)
                tvEquipmentModel.setText(context.getString(R.string.equipmentModel) + ": " + equipment.getModel());
        }
        return v;
    }

    @Override
    public View getDropDownView(int position, View convertView, ViewGroup parent) {
        TextView textView = new TextView(context);
        textView.setText(context.getString(R.string.equipmentItNo) + ": " + items.get(position).getIt_no() + " - " + items.get(position).getBrand() + " " + items.get(position).getModel());
        return textView;
    }
}

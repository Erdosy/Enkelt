package com.example.marcus.equipmentmanager;

import android.app.AlertDialog;
import android.app.Fragment;
import android.content.DialogInterface;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Handles Equipment Info Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class EquipmentInfoFragment extends Fragment implements View.OnClickListener {

    View view; // current view
    ViewGroup container; // container for view
    ViewGroup parent; // parent for view
    LayoutInflater inflater; // inflates views
    Equipment equip; // current equipment
    QueryHandler queryHandler; // handles queries to backend
    Spinner spnEquipmentType; // spinner for equipment list
    boolean loanedOut; // is equipment loaned out?
    int loaneeUId; // id of user who loaned equipment

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        container.removeAllViews();
        this.container = container;
        this.inflater = inflater;
        loanedOut = false;
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        view = inflater.inflate(R.layout.fragment_equipment_info, container, false);
        switch (((MainActivity) getActivity()).getLoggedIn()) {
            case QueryHandler.ADMIN_USER:
                view.findViewById(R.id.btnEditEquipment).setVisibility(View.VISIBLE);
                (view.findViewById(R.id.btnEditEquipment)).setOnClickListener(this);
                view.findViewById(R.id.btnRegisterLoan).setVisibility(View.VISIBLE);
                (view.findViewById(R.id.btnRegisterLoan)).setOnClickListener(this);
                view.findViewById(R.id.btnDeleteEquipment).setVisibility(View.VISIBLE);
                (view.findViewById(R.id.btnDeleteEquipment)).setOnClickListener(this);
                queryHandler.getOpenLogEntries();
                break;
            case QueryHandler.NORMAL_USER:
                view.findViewById(R.id.btnRegisterLoan).setVisibility(View.GONE);
                (view.findViewById(R.id.btnRegisterLoan)).setOnClickListener(this);
                view.findViewById(R.id.btnEditEquipment).setVisibility(View.GONE);
                view.findViewById(R.id.btnDeleteEquipment).setVisibility(View.GONE);
                queryHandler.getOpenLogEntries();
                break;
            case QueryHandler.LOGGED_OUT:
                view.findViewById(R.id.btnEditEquipment).setVisibility(View.GONE);
                view.findViewById(R.id.btnRegisterLoan).setVisibility(View.GONE);
                view.findViewById(R.id.btnDeleteEquipment).setVisibility(View.GONE);
        }
        if (equip != null) {
            TextView type = (TextView) view.findViewById(R.id.tvEquipmentType);
            type.setText(equip.getType());
            TextView itNo = (TextView) view.findViewById(R.id.tvEquipmentItNo);
            itNo.setText(equip.getIt_no());
            TextView brand = (TextView) view.findViewById(R.id.tvEquipmentBrand);
            brand.setText(equip.getBrand());
            TextView model = (TextView) view.findViewById(R.id.tvEquipmentModel);
            model.setText(equip.getModel());
            TextView description = (TextView) view.findViewById(R.id.tvEquipmentDescription);
            description.setText(equip.getDescription());
            TextView purchaseDate = (TextView) view.findViewById(R.id.tvEquipmentPurchasedDate);
            purchaseDate.setText(equip.getAquired());
            ImageView imageView = (ImageView) view.findViewById(R.id.ivEquipmentImage);
            if (equip.getImage() != null) {
                byte[] image = equip.getImage();
                Bitmap bitmap = BitmapFactory.decodeByteArray(image, 0, image.length);
                imageView.setImageBitmap(bitmap);
            }
        }
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnEditEquipment:
                parent = (ViewGroup) this.getView();
                assert parent != null;
                parent.removeAllViews();
                view = inflater.inflate(R.layout.edit_equipment, container, false);
                parent.addView(view);
                spnEquipmentType = (Spinner) view.findViewById(R.id.spnEquipmentType);
                ((MainActivity) getActivity()).equipmentTypeQuery("EditEquipment");
                queryHandler.getTypeFile();
                ((EditText) view.findViewById(R.id.etEquipmentBrand)).setText(equip.getBrand());
                ((EditText) view.findViewById(R.id.etEquipmentDescription)).setText(equip.getDescription());
                ((EditText) view.findViewById(R.id.etEquipmentItNo)).setText(equip.getIt_no());
                ((EditText) view.findViewById(R.id.etEquipmentModel)).setText(equip.getModel());
                ((EditText) view.findViewById(R.id.etEquipmentPurchasedDate)).setText(equip.getAquired());
                view.findViewById(R.id.btnSaveEquipmentEdit).setOnClickListener(this);
                break;
            case R.id.btnSaveEquipmentEdit:
                equip.setType(((Spinner) view.findViewById(R.id.spnEquipmentType)).getSelectedItem().toString());
                equip.setBrand(((EditText) view.findViewById(R.id.etEquipmentBrand)).getText().toString());
                equip.setModel(((EditText) view.findViewById(R.id.etEquipmentModel)).getText().toString());
                equip.setDescription(((EditText) view.findViewById(R.id.etEquipmentDescription)).getText().toString());
                equip.setIt_no(((EditText) view.findViewById(R.id.etEquipmentItNo)).getText().toString());
                equip.setAquired(((EditText) view.findViewById(R.id.etEquipmentPurchasedDate)).getText().toString());
                queryHandler.updateEquipment(equip);
                parent = (ViewGroup) this.getView();
                assert parent != null;
                parent.removeAllViews();
                view = inflater.inflate(R.layout.fragment_equipment_info, container, false);
                parent.addView(view);
                break;
            case R.id.btnRegisterLoan:
                if (loanedOut) {
                    ((MainActivity) getActivity()).setIsSendSMS(true);
                    queryHandler.getUsers(loaneeUId);
                    Toast.makeText(getActivity(), "User: " + loaneeUId + " has your item", Toast.LENGTH_LONG).show();
                    loanedOut = false;
                } else {
                    ((MainActivity) getActivity()).setRegisterLoanFragment(equip);
                }
                break;
            case R.id.btnDeleteEquipment:
                AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
                builder.setMessage(R.string.areYouSure)
                        .setTitle(R.string.deleteEquipment);
                builder.setPositiveButton(R.string.deleteOk, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        queryHandler.deleteEquipment(equip.getE_id());
                    }
                });
                builder.setNegativeButton(R.string.deleteCancel, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                    }
                });
                builder.show();
                break;
        }
    }

    /**
     * Populates equipment types
     *
     * @param types list of types
     */
    public void populateEquipmentTypes(ArrayList<String> types) {
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, types);
        spnEquipmentType.setAdapter(typeAdapter);
        for (int i = 0; i < types.size(); i++) {
            if (equip.getType().equals(types.get(i))) {
                spnEquipmentType.setSelection(i);
            }
        }
    }

    /**
     * Set current equipment
     *
     * @param equipment equipment to set
     */
    public void setEquipment(Equipment equipment) {
        this.equip = equipment;
    }

    /**
     * Checks if equipment is loaned out
     *
     * @param response response message from backend
     */
    public void isLoanedOut(String response) {
        ResponseHandler responseHandler = new ResponseHandler(getActivity());
        ArrayList<LogEntry> logEntries = responseHandler.getOpenLogEntriesResponse(response);
        for (LogEntry logEntry : logEntries) {
            if (equip.getE_id() == logEntry.getE_id()) {
                loaneeUId = logEntry.getU_id();
                loanedOut = true;
                if (((MainActivity) getActivity()).getLoggedIn() == 1) {
                    (view.findViewById(R.id.btnRegisterLoan)).setVisibility(View.VISIBLE);
                }
                ((Button) view.findViewById(R.id.btnRegisterLoan)).setText(R.string.btnAskForHandIn);
            }
        }
    }

    /**
     * Sends sms to user with predefined message
     *
     * @param users user to send message to
     */
    public void sendSMS(ArrayList<User> users) {
        String phoneNumber = users.get(0).getPhone();
        String text = Utility.capitalizeFirstLetter(getString(R.string.user)) + " " + (((MainActivity) getActivity()).getUser()).getU_id() +
                getString(R.string.wouldLikeYouToReturnItem) + " " + equip.getBrand() + " " +
                equip.getModel() + ", " + getString(R.string.bestRegardsTheTeamAt) + " " +
                getString(R.string.app_name);
        Toast.makeText(getActivity(), "Phone number: " + phoneNumber + "text: " + text, Toast.LENGTH_LONG).show();
        Utility.sendSMS(phoneNumber, text);
    }

    /**
     * Sets image of image view
     *
     * @param image image to set
     */
    public void setImage(Bitmap image) {
        ImageView imageView = (ImageView) view.findViewById(R.id.ivEquipmentImage);
        imageView.setImageBitmap(image);
    }
}
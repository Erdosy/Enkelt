package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class EquipmentOverviewFragment extends Fragment implements View.OnClickListener {

    ResponseHandler responseHandler; // handles response strings from backend
    ArrayList<Equipment> equipment; // list of equipment
    ArrayList<Equipment> allEquipment; // list of all equipment
    QueryHandler queryHandler; // handles queries to backend
    View view; // current view
    EquipmentAdapter adapter; // adapter for equipment list
    boolean showAvailable = false; // show just available?
    boolean searching = false; // searching?

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        container.removeAllViews();
        view = inflater.inflate(R.layout.fragment_equipment_overview, container, false);
        if (!showAvailable) {
            ((TextView) view.findViewById(R.id.tvWhatEquipment)).setText(getString(R.string.allEquipment));
        }
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        responseHandler = new ResponseHandler(getActivity());
        if (((MainActivity) getActivity()).getLoggedIn() == 0) {
            queryHandler.getEquipmentWithoutLogin();
        } else {
            queryHandler.getEquipment("ALL");
            view.findViewById(R.id.equipmentOverviewFirst).setVisibility(View.VISIBLE);
            view.findViewById(R.id.btnShowAvailable).setOnClickListener(this);
            view.findViewById(R.id.imgBtnSearch).setOnClickListener(this);
            view.findViewById(R.id.imgBtnCancelSearch).setOnClickListener(this);
        }
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnShowAvailable:
                if (!showAvailable) {
                    showAvailable = true;
                    ((MainActivity) getActivity()).setIsAvailable(true);
                    queryHandler.getEquipment("AVAILABLE");
                    ((TextView) view.findViewById(R.id.tvWhatEquipment)).setText(getString(R.string.availableEquipment));
                    ((Button) view.findViewById(R.id.btnShowAvailable)).setText(getString(R.string.allEquipment));
                } else {
                    ((MainActivity) getActivity()).setIsAvailable(true); //While strictly not true, this makes the transition smoother.
                    queryHandler.getEquipment("ALL");
                    ((TextView) view.findViewById(R.id.tvWhatEquipment)).setText(getString(R.string.allEquipment));
                    ((Button) view.findViewById(R.id.btnShowAvailable)).setText(getString(R.string.availableEquipment));
                    showAvailable = false;
                }
                break;
            case R.id.imgBtnSearch:
                if (searching) {
                    String searchString = ((EditText) view.findViewById(R.id.etSearchEquipment)).getText().toString();
                    String equipString;
                    ArrayList<Equipment> results = new ArrayList<>();
                    for (int i = 0; i < allEquipment.size(); i++) {
                        equipString = allEquipment.get(i).toString();
                        if (equipString.contains(searchString)) {
                            results.add(allEquipment.get(i));
                        }
                    }
                    adapter.clear();
                    adapter.addAll(results);
                    ((TextView) view.findViewById(R.id.tvWhatEquipment)).setText("Search result for: " + searchString);
                    view.findViewById(R.id.imgBtnCancelSearch).setVisibility(View.GONE);
                    view.findViewById(R.id.etSearchEquipment).setVisibility(View.GONE);
                    view.findViewById(R.id.btnShowAvailable).setVisibility(View.VISIBLE);
                    searching = false;
                } else {
                    view.findViewById(R.id.imgBtnCancelSearch).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.etSearchEquipment).setVisibility(View.VISIBLE);
                    view.findViewById(R.id.btnShowAvailable).setVisibility(View.GONE);
                    searching = true;
                }
                break;
            case R.id.imgBtnCancelSearch:
                view.findViewById(R.id.imgBtnCancelSearch).setVisibility(View.GONE);
                view.findViewById(R.id.etSearchEquipment).setVisibility(View.GONE);
                view.findViewById(R.id.btnShowAvailable).setVisibility(View.VISIBLE);
                break;
        }
    }

    /**
     * Sets equipment lists
     *
     * @param context  context to use
     * @param response response message from backend
     */
    public void setEquipment(Context context, String response) {
        responseHandler = new ResponseHandler(context);
        allEquipment = responseHandler.getEquipmentResponse(response);
        equipment = new ArrayList<>(allEquipment);
        adapter = new EquipmentAdapter(context, R.layout.equipment_short, equipment);
        if (!showAvailable) {
            ((TextView) view.findViewById(R.id.tvWhatEquipment)).setText(R.string.allEquipment);
        }
        ListView list = (ListView) view.findViewById(R.id.lvEquipmentList);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Equipment currentEquipment = equipment.get(position);
                ((MainActivity) getActivity()).setEquipmentInfoFragment(currentEquipment);
            }
        });
    }
}

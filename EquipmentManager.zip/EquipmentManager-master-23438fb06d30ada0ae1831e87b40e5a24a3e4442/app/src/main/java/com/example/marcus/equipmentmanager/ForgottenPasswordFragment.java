package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.Toast;

/**
 * Handles Forgotten Password Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class ForgottenPasswordFragment extends Fragment implements View.OnClickListener {

    View view;  //The active view
    QueryHandler queryHandler; //The active queryhandler, to send queries to the server
    ResponseHandler responseHandler; //An object of the responsehandler class, to handle the response from the server.

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_forgotten_password, container, false);
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        view.findViewById(R.id.trNewPassRow).setVisibility(View.GONE);
        view.findViewById(R.id.trRepeatPassRow).setVisibility(View.GONE);
        view.findViewById(R.id.btnChangePassword).setVisibility(View.GONE);
        view.findViewById(R.id.trCode).setVisibility(View.GONE);
        (view.findViewById(R.id.btnRequestCode)).setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnRequestCode:
                view.findViewById(R.id.trNewPassRow).setVisibility(View.VISIBLE);
                view.findViewById(R.id.trRepeatPassRow).setVisibility(View.VISIBLE);
                view.findViewById(R.id.btnChangePassword).setVisibility(View.VISIBLE);
                view.findViewById(R.id.trCode).setVisibility(View.VISIBLE);
                view.findViewById(R.id.btnRequestCode).setVisibility(View.GONE);
                String phoneNumber = ((EditText) view.findViewById(R.id.etPhone)).getText().toString();
                view.findViewById(R.id.trPhone).setVisibility(View.GONE);
                (view.findViewById(R.id.btnChangePassword)).setOnClickListener(this);
                queryHandler.changeUserPasswordGetCode("+47", phoneNumber);
                break;
            case R.id.btnChangePassword:
                String newPassword = ((EditText) view.findViewById(R.id.etNewPassword)).getText().toString();
                String newPassRepeat = ((EditText) view.findViewById(R.id.etNewPasswordRepeat)).getText().toString();
                String code = ((EditText) view.findViewById(R.id.etCode)).getText().toString();
                if (newPassword.equals(newPassRepeat)) {
                    queryHandler.changeUserPasswordByCode(code, newPassword);
                } else {
                    Toast.makeText(getActivity(), R.string.passwordNoMatch, Toast.LENGTH_LONG).show();
                }
        }
    }

    /**
     * Gets the response from server after call on changeUserPasswordByCode
     * Checks the response in response handler, and redirects to the login screen if true.
     *
     * @param response the response from server
     */
    public void changeResult(String response) {
        responseHandler = new ResponseHandler(getActivity());
        if (responseHandler.changeUserPasswordByCodeResponse(response)) {
            ((MainActivity) getActivity()).setLoginFragment();
        }
    }
}

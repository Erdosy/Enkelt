package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;

/**
 * Takes in byte array, transforms to bitmap and resize bitmap in own thread
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class ImageResizeAsyncTask extends AsyncTask<byte[], Void, Bitmap> {

    Context context; // context to use

    /**
     * Constructor
     *
     * @param context context to use
     */
    public ImageResizeAsyncTask(Context context) {
        this.context = context;
    }

    @Override
    protected Bitmap doInBackground(byte[]... params) {
        byte[] imageByteArray = params[0];
        Bitmap image = BitmapFactory.decodeByteArray(imageByteArray, 0, imageByteArray.length);
        int width = image.getWidth();
        int height = image.getHeight();
        double scaleFactor;
        if (width > height) {
            scaleFactor = (double) (width / 150);
            width = 150;
            height = (int) (height / scaleFactor);
        } else {
            scaleFactor = (double) (height / 150);
            height = 150;
            width = (int) (width / scaleFactor);
        }
        return Bitmap.createScaledBitmap(image, width, height, false);
    }

    @Override
    protected void onPostExecute(Bitmap scaledImage) {
        ((MainActivity) context).setImage(scaledImage);
    }
}

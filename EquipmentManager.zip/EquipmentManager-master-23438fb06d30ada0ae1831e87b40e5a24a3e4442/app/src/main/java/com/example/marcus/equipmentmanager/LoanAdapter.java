package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Custom adapter for log entries list
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class LoanAdapter extends ArrayAdapter<LogEntry> {

    private ArrayList<LogEntry> loans; // list of log entries
    private ArrayList<Equipment> items; // list of equipment
    private ArrayList<User> users; // list of users

    /**
     * Constructor
     *
     * @param context            context to use
     * @param textViewResourceId resource for list
     * @param loans              list of log entries
     * @param items              list of equipment
     * @param users              list of users
     */
    public LoanAdapter(Context context, int textViewResourceId, ArrayList<LogEntry> loans, ArrayList<Equipment> items, ArrayList<User> users) {
        super(context, textViewResourceId, loans);
        this.loans = loans;
        this.items = items;
        this.users = users;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        if (v == null) {
            LayoutInflater vi = (LayoutInflater) getContext().getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            v = vi.inflate(R.layout.loan_short, null);
        }
        LogEntry loan = loans.get(position);
        if (loan != null) {
            Equipment loanedEquipment = null;
            User loanUser = null;
            for (Equipment equip : items) {
                if (loan.getE_id() == equip.getE_id()) {
                    loanedEquipment = equip;
                }
            }
            for (User user : users) {
                if (loan.getU_id() == user.getU_id()) {
                    loanUser = user;
                }
            }
            if (loanedEquipment != null && loanUser != null) {
                TextView tvEquipmentType = (TextView) v.findViewById(R.id.tvEquipmentType);
                TextView tvEquipmentItNo = (TextView) v.findViewById(R.id.tvEquipmentItNo);
                TextView tvUserName = (TextView) v.findViewById(R.id.tvUserName);
                TextView tvLoanOut = (TextView) v.findViewById(R.id.tvLoanOut);
                Context context = getContext();
                if (tvEquipmentType != null)
                    tvEquipmentType.setText(context.getString(R.string.equipmentType) + ": " + loanedEquipment.getType());
                if (tvEquipmentItNo != null)
                    tvEquipmentItNo.setText(context.getString(R.string.equipmentItNo) + ": " + loanedEquipment.getIt_no());
                if (tvUserName != null)
                    tvUserName.setText(context.getString(R.string.username) + ": " + loanUser.getUserName());
                if (tvLoanOut != null)
                    tvLoanOut.setText(context.getString(R.string.loanDateOut) + ": " + loan.getOut());
            }
        }
        return v;
    }
}


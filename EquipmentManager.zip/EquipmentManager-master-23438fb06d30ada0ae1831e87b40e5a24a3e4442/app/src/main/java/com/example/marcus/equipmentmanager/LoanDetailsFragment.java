package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Handles Loan Details Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class LoanDetailsFragment extends Fragment {

    View view; // active view
    QueryHandler queryHandler; // handles queries from application
    ResponseHandler responseHandler; // handles response strings from backend
    String response; // response string from backend
    LayoutInflater inflater; // inflater to inflate views
    ViewGroup container; // container of views
    User user; // current user
    Equipment equipment; // current equipment
    LogEntry loan; // current log entry

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.loan_details, container, false);
        this.container = container;
        this.inflater = inflater;
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        if (((MainActivity) getActivity()).getLoggedIn() == 1) {
            user = ((MainActivity) getActivity()).getUser();
            ((TextView) view.findViewById(R.id.tvUserName)).setText(this.user.getUserName());
            ((TextView) view.findViewById(R.id.tvFullName)).setText(this.user.getFirstname() + " " + this.user.getLastname());
            ((TextView) view.findViewById(R.id.tvPhoneNumber)).setText(this.user.getPhone());
        }
        ((MainActivity) getActivity()).setIsLoanDetails(true);
        ((MainActivity) getActivity()).setIsLoanUser(true);
        queryHandler.getEquipment("IN_USE");
        responseHandler = new ResponseHandler(getActivity());
        loan = ((MainActivity)getActivity()).getSelectedLoan();
        queryHandler.getUsers(loan.getU_id());
        return view;
    }

    /**
     * Sets user from response json string
     *
     * @param response response message from backend
     */
    public void setUser(String response) {
        ArrayList<User> userList = responseHandler.getUsersResponse(response);
        this.user = userList.get(0);
        ((TextView) view.findViewById(R.id.tvUserName)).setText(this.user.getUserName());
        ((TextView) view.findViewById(R.id.tvFullName)).setText(this.user.getFirstname() + " " + this.user.getLastname());
        ((TextView) view.findViewById(R.id.tvPhoneNumber)).setText(this.user.getPhone());
    }

    /**
     * Sets equipment from json string
     *
     * @param response response message from backend
     */
    public void setEquipment(String response) {
        ArrayList<Equipment> equipments = responseHandler.getEquipmentResponse(response);
        for (int i = 0; i < equipments.size(); i++) {
            if (equipments.get(i).getE_id() == loan.getE_id()) {
                this.equipment = equipments.get(i);
            }
        }
        ((TextView) view.findViewById(R.id.tvEquipmentType)).setText(this.equipment.getType());
        ((TextView) view.findViewById(R.id.tvEquipmentBrand)).setText(this.equipment.getBrand());
        ((TextView) view.findViewById(R.id.tvEquipmentDescription)).setText(this.equipment.getDescription());
        ((TextView) view.findViewById(R.id.tvDateOut)).setText(this.loan.getOut());
        ((TextView) view.findViewById(R.id.tvComment)).setText(this.loan.getComment());
    }
}

package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;

/**
 * Handles Login Fragment
 */
public class LoginFragment extends Fragment implements View.OnClickListener {

    QueryHandler queryHandler; // handles queries from application
    View view; // current view
    Context context; // context to use

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_login, container, false);
        context = getActivity();
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        checkRemembered();
        Button btnDoLogin = (Button) view.findViewById(R.id.btnDoLogin);
        Button btnDoLoginAdmin = (Button) view.findViewById(R.id.btnDoLoginAdmin);
        Button btnForgottenPassword = (Button) view.findViewById(R.id.btnForgottenPassword);
        btnDoLogin.setOnClickListener(this);
        btnDoLoginAdmin.setOnClickListener(this);
        btnForgottenPassword.setOnClickListener(this);
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnDoLogin:
                saveNameAndPassword();
                queryHandler.logIn(view);
                break;
            case R.id.btnDoLoginAdmin:
                saveNameAndPassword();
                queryHandler.logInAdmin(view);
                break;
            case R.id.btnForgottenPassword:
                ((MainActivity) getActivity()).setForgottenPasswordFragment();
                break;
        }
    }

    /**
     * Sets username and password to be remembered, if settings in preferences is set
     */
    public void saveNameAndPassword() {
        if (((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getBoolean("rememberUsername", false)) {
            String userNameToRemember = ((EditText) view.findViewById(R.id.etUsernameLogin)).getText().toString();
            ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).edit().putString("Username", userNameToRemember).commit();
        }
        if (((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getBoolean("rememberPassword", false)) {
            String passwordToRemember = ((EditText) view.findViewById(R.id.etPasswordLogin)).getText().toString();
            ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).edit().putString("Password", passwordToRemember).commit();
        }
    }

    /**
     * Sets remembered username and password, if settings in preferences is set.
     */
    public void checkRemembered() {
        if (((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getString("Username", null) != null) {
            ((EditText) view.findViewById(R.id.etUsernameLogin)).setText(((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getString("Username", null));
        }
        if (((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getString("Password", null) != null) {
            ((EditText) view.findViewById(R.id.etPasswordLogin)).setText(((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getString("Password", null));
        }
    }
}

package com.example.marcus.equipmentmanager;

import android.app.Activity;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.graphics.Bitmap;
import android.content.res.Configuration;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;

/**
 * Main Activity that everything is based around.
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class MainActivity extends Activity {

    private Fragment currentFragment; //A reference to the currently active fragment
    private EquipmentOverviewFragment equipmentOverviewFragment; // equipment overview fragment
    private EquipmentInfoFragment equipmentInfoFragment; // equipment info fragment
    private ActiveLoansFragment activeLoansFragment; // active loans fragment
    private ActiveUsersFragment activeUsersFragment; // active users fragment
    private AddUserFragment addUserFragment; // add user fragment
    private ConfirmUsersFragment confirmUsersFragment; // confirm users fragment
    private MenubarFragment menubarFragment; // menu bar fragment
    private RegisterLoanFragment registerLoanFragment; // register loan fragment
    private RegisterEquipmentFragment registerEquipmentFragment; // register equipment fragment
    private UserProfileFragment userProfileFragment; // user profile fragment
    private LoginFragment loginFragment; // login fragment
    private MainActivityFragment mainActivityFragment; // main activity fragment
    private LoanDetailsFragment loanDetailsFragment; // loan details fragment
    private MyLoansFragment myLoansFragment; // my loans fragment
    private ForgottenPasswordFragment forgottenPasswordFragment; // forgotten password fragment
    private QueryHandler queryHandler = null; //The queryhandler. Handles queries to the server.
    private ResponseHandler responseHandler = null; //The responsehandler. Handles the responses from the server.
    private int isLoggedIn = 0; //A help-value to determine the user-level of the currently logged in user (not logged in, normal user, or admin).
    private boolean isRegisterLoan = false; //Help-value for a switch.
    private User user; //The currently logged in user.
    private boolean isAddUser = false; //Help-value for a switch.
    private User selectedUser; //Help-value to move a selected user from one fragment to another.
    private boolean isLoanDetails = false; //Help-value for a switch.
    private boolean isAvailable = false; //Help-value for a switch.
    private String querySource; //Help-value for a switch.
    private boolean isLandscape = false; //Help-value for functions that behave differently based on orientation.
    private boolean isLoanLog = false; //Help-value for a switch.
    private boolean isLoanUser = false; //Help-value for a switch.
    private boolean isRegister = false; // help value for switch
    private boolean isMyLoansEquipment = false; // help value for switch
    private boolean isLoanEquipment = false; // help value for switch
    private boolean isSendSMS = false; // help value for switch
    private LogEntry selectedLoan; //Help-value to move a selected loan object from one fragment to another.
    private FragmentManager manager; // manages all fragment operations

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) {
            isLandscape = true;
        }
        manager = getFragmentManager();
        goHome();
        queryHandler = new QueryHandler(this);
        responseHandler = new ResponseHandler(this);
        checkAutomaticLogin();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        if (newConfig.orientation == Configuration.ORIENTATION_LANDSCAPE) {
            isLandscape = true;
        } else if (newConfig.orientation == Configuration.ORIENTATION_PORTRAIT) {
            isLandscape = false;
        }
        goHome();
    }


    /**
     * Decides what fragment goes in what container. Called on startup and orientation change.
     */
    private void goHome() {
        setContentView(R.layout.activity_main);
        if (!isLandscape) {
            if (currentFragment == null) {
                menubarFragment = new MenubarFragment();
                currentFragment = menubarFragment;
            }
            changeMainFragmentOrientation(currentFragment);
        } else {
            menubarFragment = new MenubarFragment();
            changeMenuFragment(menubarFragment);
            if (currentFragment == null) {
                mainActivityFragment = new MainActivityFragment();
                currentFragment = mainActivityFragment;
            }
            refreshFragment(menubarFragment);
            changeMainFragmentOrientation(currentFragment);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        switch (id) {
            case (R.id.action_settings):
                Fragment fragment = new SettingsFragment();
                changeMainFragment(fragment);
                return true;
            case (R.id.action_home):
                if (menubarFragment == null) {
                    menubarFragment = new MenubarFragment();
                }
                changeMainFragmentOrientation(menubarFragment);
                return true;
            case R.id.action_exit:
                queryHandler.logOut();
                this.finish();
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * handles responses from the server. Called by the asynctasks when they are finished.
     *
     * @param response response from the server
     * @param type     the type of query, used in a switch to handle the response.
     */
    public void showResult(String response, String type) {
        switch (type) {
            case "logIn":
                user = responseHandler.logInResponse(response);
                if (user != null) {
                    Toast.makeText(this, user.getFirstname(), Toast.LENGTH_LONG).show();   //Just a test of the button onclick.
                    setLoggedIn(1);
                    openMenuBar();
                }
                break;
            case "logInAdmin":
                user = responseHandler.logInResponse(response);
                if (user != null) {
                    Toast.makeText(this, user.getFirstname(), Toast.LENGTH_LONG).show();   //Just a test of the button onclick.
                    setLoggedIn(2);
                    openMenuBar();
                }
                break;
            case "getEquipment":
                showEquipment(response);
                break;
            case "logOut":
                responseHandler.logOutResponse(response);
                refreshFragment(menubarFragment);
                break;
            case "addEquipment":
                responseHandler.addEquipmentResponse(response);
                break;
            case "addUser":
                if (responseHandler.addUserResponse(response)) {
                    isAddUser = true;
                    queryHandler.getNotActivatedUsers();
                }
                break;
            case "addUserWithoutLogin":
                responseHandler.addUserWithoutLoginResponse(response);
                break;
            case "confirmRegisteredUser":
                responseHandler.confirmRegisteredUserResponse(response);
                break;
            case "changeUserPassword":
                responseHandler.changeUserPasswordResponse(response);
                break;
            case "deleteEquipment":
                responseHandler.deleteEquipmentResponse(response);
                break;
            case "deleteUser":
                responseHandler.deleteUserResponse(response);
                break;
            case "getActiveUsers":
                if (isRegisterLoan) {
                    registerLoanFragment.populateUsers(response);
                } else if (isLoanUser) {
                    activeLoansFragment.setUsers(response);
                    isLoanUser = false;
                } else {
                    if (activeUsersFragment == null) {
                        activeUsersFragment = new ActiveUsersFragment();
                    }
                    activeUsersFragment.populateList(response);
                }
                break;
            case "getAllLogEntriesForAllUser":
                responseHandler.getAllLogEntriesForAllUserResponse(response);
                break;
            case "getEquipmentType":
                responseHandler.getEquipmentTypeResponse(response);
                break;
            case "getEquipmentWithoutLogin":
                showEquipment(response);
                break;
            case "getLogEntriesForUser":
                responseHandler.getLogEntriesForUserResponse(response);
                break;
            case "getNotActivatedUsers":
                if (isAddUser) {
                    addUserFragment.confirmUser(response, responseHandler);
                    isAddUser = false;
                } else {
                    confirmUsersFragment.populateList(response);
                }
                break;
            case "getOpenLogEntries":
                if (isLoanLog) {
                    activeLoansFragment.setLoans(response);
                    isLoanLog = false;
                } else {
                    equipmentInfoFragment.isLoanedOut(response);
                }
                break;
            case "getOpenLogEntriesForUser":
                myLoansFragment.setLoans(response);
                break;
            case "getUsers":
                if (isLoanUser) {
                    loanDetailsFragment.setUser(response);
                    isLoanUser = false;
                } else if (isSendSMS) {
                    ArrayList<User> users = responseHandler.getUsersResponse(response);
                    equipmentInfoFragment.sendSMS(users);
                    isSendSMS = false;
                }
                break;
            case "registerReservationIn":
                responseHandler.registerReservationInResponse(response);
                refreshFragment(activeLoansFragment);
                break;
            case "registerReservationOut":
                responseHandler.registerReservationOutResponse(response);
                break;
            case "updateEquipment":
                responseHandler.updateEquipmentResponse(response);
                break;
            case "updateUser":
                responseHandler.updateUserResponse(response);
                break;
            case "getTypeFile":
                ArrayList<String> types = responseHandler.getTypeFileResponse(response);
                switch (querySource) {
                    case "RegisterEquipment":
                        registerEquipmentFragment.populateEquipmentTypes(types);
                        break;
                    case "EditEquipment":
                        equipmentInfoFragment.populateEquipmentTypes(types);
                        break;
                }
                break;
            case "changeUserPasswordByCode":
                forgottenPasswordFragment.changeResult(response);
                break;
            case "changeUserPasswordGetCode":
                responseHandler.changeUserPasswordGetCodeResponse(response);
                break;
        }
    }

    /**
     * Called when user clicks a clickable view. Switch statement decides which view and takes action
     *
     * @param view calling view
     */
    public void onClick(View view) {
        switch (view.getId()) {
            case R.id.btnLogin:
                if (loginFragment == null) {
                    loginFragment = new LoginFragment();
                }
                changeMainFragment(loginFragment);
                break;
            case R.id.btnListEquipment:
                if (equipmentOverviewFragment == null) {
                    equipmentOverviewFragment = new EquipmentOverviewFragment();
                }
                changeMainFragment(equipmentOverviewFragment);
                break;
            case R.id.btnRegisterEquipment:
                if (registerEquipmentFragment == null) {
                    registerEquipmentFragment = new RegisterEquipmentFragment();
                }
                changeMainFragment(registerEquipmentFragment);
                break;
            case R.id.btnRegister:
                if (addUserFragment == null) {
                    addUserFragment = new AddUserFragment();
                }
                changeMainFragment(addUserFragment);
                break;
            case R.id.btnInactiveUsers:
                queryHandler.getNotActivatedUsers();
                if (confirmUsersFragment == null) {
                    confirmUsersFragment = new ConfirmUsersFragment();
                }
                changeMainFragment(confirmUsersFragment);
                break;
            case R.id.btnActiveUsers:
                if (activeUsersFragment == null) {
                    activeUsersFragment = new ActiveUsersFragment();
                }
                changeMainFragment(activeUsersFragment);
                break;
            case R.id.btnAddUser:
                if (addUserFragment == null) {
                    addUserFragment = new AddUserFragment();
                }
                changeMainFragment(addUserFragment);
                break;
            case R.id.btnActiveLoans:
                if (activeLoansFragment == null) {
                    activeLoansFragment = new ActiveLoansFragment();
                }
                changeMainFragment(activeLoansFragment);
                break;
            case R.id.btnRegisterLoan:
                if (registerLoanFragment == null) {
                    registerLoanFragment = new RegisterLoanFragment();
                }
                changeMainFragment(registerLoanFragment);
                registerLoanFragment.useList(true);
                break;
            case R.id.btnLogOut:
                queryHandler.logOut();
                break;
            case R.id.btnProfile:
                if (userProfileFragment == null) {
                    userProfileFragment = new UserProfileFragment();
                }
                changeMainFragment(userProfileFragment);
                break;
            case R.id.btnMyLoans:
                if (myLoansFragment == null) {
                    myLoansFragment = new MyLoansFragment();
                }
                changeMainFragment(myLoansFragment);
        }
    }

    /**
     * Getter for the currently used query handler.
     *
     * @return the query handler.
     */
    public QueryHandler getQueryHandler() {
        return queryHandler;
    }

    /**
     * Getter for the isLoggedIn value. Lets fragments know the user_level of the currently logged in user.
     *
     * @return user level of logged in user
     */
    public int getLoggedIn() {
        return isLoggedIn;
    }

    /**
     * Setter for the isLoggedIn value.
     * Called when the user logs in, or if the queryhandler notice a timeout.
     *
     * @param isLoggedIn user level of logged in user
     */
    public void setLoggedIn(int isLoggedIn) {
        this.isLoggedIn = isLoggedIn;
        if (isLoggedIn == 0) {
            refreshFragment(menubarFragment);
        }
    }

    /**
     * Checks what fragment queried the server for the equipment list, and sends it to that fragment.
     *
     * @param response the equipment list, in form of a json-string.
     */
    public void showEquipment(String response) {
        if (isRegisterLoan) {
            registerLoanFragment.setEquipmentList(response);
        } else if (isLoanDetails) {
            loanDetailsFragment.setEquipment(response);
            isLoanDetails = false;
        } else if (isAvailable) {
            equipmentOverviewFragment.setEquipment(this, response);
            isAvailable = false;
        } else if (isMyLoansEquipment) {
            myLoansFragment.setEquipment(response);
            isMyLoansEquipment = false;
        } else if (isLoanEquipment) {
            activeLoansFragment.setEquipment(response);
            isLoanEquipment = false;
        } else {
            equipmentOverviewFragment.setEquipment(this, response);
        }
    }

    /**
     * Sets the current active fragment to menubarfragment.
     */
    public void openMenuBar() {
        if (isLandscape) {
            if (mainActivityFragment == null) {
                mainActivityFragment = new MainActivityFragment();
            }
            changeMainFragment(mainActivityFragment);
        } else {
            if (menubarFragment == null) {
                menubarFragment = new MenubarFragment();
            }
            changeMainFragment(menubarFragment);
        }
        refreshFragment(menubarFragment);
    }

    /**
     * Getter for fragments to get the currently logged in user object.
     *
     * @return the current user.
     */
    public User getUser() {
        return user;
    }

    /**
     * Changes the current active fragment.
     *
     * @param fragment the fragment to change to.
     */
    public void changeMainFragment(Fragment fragment) {
        if (isLandscape) {
            if (fragment.getClass() == MenubarFragment.class) {
                if (mainActivityFragment == null) {
                    mainActivityFragment = new MainActivityFragment();
                }
                fragment = mainActivityFragment;
            }
        }
        FragmentTransaction ft = manager.beginTransaction();
        ft.replace(R.id.main_fragment, fragment);
        ft.setTransition(FragmentTransaction.TRANSIT_ENTER_MASK);
        ft.addToBackStack(null);
        ft.commit();
        currentFragment = fragment;
    }

    /**
     * Moves the menu bar fragment to the main_menu bar container/placeholder on change to landscape orientation.
     */
    public void changeMenuFragment(Fragment fragment) {
        manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        manager.beginTransaction().remove(fragment).commit();
        manager.executePendingTransactions();
        manager.beginTransaction()
                .replace(R.id.main_menubar, fragment)
                .commit();
        manager.executePendingTransactions();
    }

    /**
     * Moves the main fragment between containers on orientation change.
     * Also makes sure we don't get two menu bar fragments on screen in landscape, or the main activity fragment on screen in vertical mode.
     *
     * @param fragment the fragment to be moved.
     */
    public void changeMainFragmentOrientation(Fragment fragment) {
        if (isLandscape) {
            if (fragment.getClass() == MenubarFragment.class) {
                if (mainActivityFragment == null) {
                    mainActivityFragment = new MainActivityFragment();
                }
                fragment = mainActivityFragment;
            }
        } else {
            if (fragment.getClass() == MainActivityFragment.class) {
                if (menubarFragment == null) {
                    menubarFragment = new MenubarFragment();
                }
                fragment = menubarFragment;
            }
        }
        manager.popBackStackImmediate(null, FragmentManager.POP_BACK_STACK_INCLUSIVE);
        manager.beginTransaction().remove(fragment).commit();
        manager.executePendingTransactions();
        manager.beginTransaction()
                .replace(R.id.main_fragment, fragment)
                .commit();
        currentFragment = fragment;
    }

    /**
     * Setter for a boolean used in the showResult switch.
     *
     * @param value the value we want for the boolean.
     */
    public void setRegisterLoan(boolean value) {
        this.isRegisterLoan = value;
    }

    /**
     * Help function for fragments to set the selected user for use in another fragment.
     *
     * @param selectedUser the selected user.
     */
    public void setSelectedUser(User selectedUser) {
        this.selectedUser = selectedUser;
    }

    /**
     * Help function for fragments to get the selected user in another fragment.
     *
     * @return the selected user.
     */
    public User getSelectedUser() {
        return selectedUser;
    }

    /**
     * Setter for a boolean used in the showResult switch.
     *
     * @param isLoanDetails value of the boolean.
     */
    public void setIsLoanDetails(boolean isLoanDetails) {
        this.isLoanDetails = isLoanDetails;
    }

    /**
     * Setter for a boolean used in the showResult switch.
     *
     * @param isAvailable value of the boolean.
     */
    public void setIsAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }

    /**
     * Help function for a switch regarding equipmentType query.
     *
     * @param querySource value we want the switch to select.
     */
    public void equipmentTypeQuery(String querySource) {
        this.querySource = querySource;
    }

    /**
     * Sets the active fragment to registerLoanFragment
     *
     * @param equipment the selected equipment to register a loan for.
     */
    public void setRegisterLoanFragment(Equipment equipment) {
        if (registerLoanFragment == null) {
            registerLoanFragment = new RegisterLoanFragment();
        }
        isRegisterLoan = true;
        registerLoanFragment.useList(false);
        registerLoanFragment.setSingleEquipment(equipment);
        changeMainFragment(registerLoanFragment);
    }

    /**
     * Sets the active fragment to equipmentInfoFragment.
     *
     * @param equipment the selected equipment to show info from.
     */
    public void setEquipmentInfoFragment(Equipment equipment) {
        if (equipmentInfoFragment == null) {
            equipmentInfoFragment = new EquipmentInfoFragment();
        }
        changeMainFragment(equipmentInfoFragment);
        equipmentInfoFragment.setEquipment(equipment);
    }

    /**
     * Sets the active fragment to userProfileFragment.
     */
    public void setUserProfileFragment() {
        if (userProfileFragment == null) {
            userProfileFragment = new UserProfileFragment();
        }
        changeMainFragment(userProfileFragment);
    }

    /**
     * Sets the active fragment to loanDetailsFragment.
     *
     * @param loan the selected loan to show details from.
     */
    public void setLoanDetailsFragment(LogEntry loan) {
        if (loanDetailsFragment == null) {
            loanDetailsFragment = new LoanDetailsFragment();
        }
        changeMainFragment(loanDetailsFragment);
        this.selectedLoan = loan;
    }

    /**
     * Sets the active fragment to forgottenPasswordFragment.
     */
    public void setForgottenPasswordFragment() {
        if (forgottenPasswordFragment == null) {
            forgottenPasswordFragment = new ForgottenPasswordFragment();
        }
        changeMainFragment(forgottenPasswordFragment);
    }

    /**
     * Sets the active fragment to loginFragment.
     */
    public void setLoginFragment() {
        if (loginFragment == null) {
            loginFragment = new LoginFragment();
        }
        changeMainFragment(loginFragment);
    }

    /**
     * Sets the active fragment to menubarFragment.
     */
    public void setMenubarFragment() {
        if (isLandscape) {
            if (mainActivityFragment == null) {
                mainActivityFragment = new MainActivityFragment();
            }
            changeMainFragment(mainActivityFragment);
        } else {
            if (menubarFragment == null) {
                menubarFragment = new MenubarFragment();
            }
            changeMainFragment(menubarFragment);
        }
    }

    /**
     * Refreshes a fragment. Called if we want the users screen to update without changing fragment
     *
     * @param fragmentToRefresh the fragment to be refreshed.
     */
    public void refreshFragment(Fragment fragmentToRefresh) {
        FragmentTransaction ft = manager.beginTransaction();
        ft.detach(fragmentToRefresh);
        ft.attach(fragmentToRefresh);
        ft.commit();
    }

    /**
     * setter for the help-value isLoanUser.
     *
     * @param isLoanUser help-value used in a switch.
     */
    public void setIsLoanUser(boolean isLoanUser) {
        this.isLoanUser = isLoanUser;
    }

    /**
     * setter for the help-value isLoanLog.
     *
     * @param isLoanLog help-value used in a switch.
     */
    public void setIsLoanLog(boolean isLoanLog) {
        this.isLoanLog = isLoanLog;
    }

    /**
     * Getter for fragments to get a selected loan from another fragment.
     *
     * @return returns the selected loan in form og a logentry object.
     */
    public LogEntry getSelectedLoan() {
        return selectedLoan;
    }

    /**
     * Setter for images. Sends the image to the relevant fragment.
     *
     * @param bitmap the image to send.
     */
    public void setImage(Bitmap bitmap) {
        if (isRegister) {
            registerEquipmentFragment.setImage(bitmap);
        } else {
            equipmentInfoFragment.setImage(bitmap);
        }
    }

    /**
     * Setter for the help-value isRegister.
     *
     * @param isRegister help-value used in a switch.
     */
    public void setIsRegister(boolean isRegister) {
        this.isRegister = isRegister;
    }

    public void setIsMyLoans(boolean isMyLoans) {
        this.isMyLoansEquipment = isMyLoans;
    }

    public void setIsLoanEquipment(boolean isLoanEquipment) {
        this.isLoanEquipment = isLoanEquipment;
    }

    public void setIsRegisterLoan(boolean isRegisterLoan) {
        this.isRegisterLoan = isRegisterLoan;
    }

    public void setIsSendSMS(boolean isSendSMS) {
        this.isSendSMS = isSendSMS;
    }

    /**
     * Checks if the application on this phone is set to automatic login in the settings,
     * and logs the user in if it is.
     */
    public void checkAutomaticLogin() {
        boolean automaticLogin = getPreferences(Context.MODE_PRIVATE).getBoolean("autoLogin", false);
        if (automaticLogin) {
            String userName = getPreferences(Context.MODE_PRIVATE).getString("Username", null);
            String password = getPreferences(Context.MODE_PRIVATE).getString("Password", null);
            queryHandler.logInAutomatically(userName, password);
        }
    }
}

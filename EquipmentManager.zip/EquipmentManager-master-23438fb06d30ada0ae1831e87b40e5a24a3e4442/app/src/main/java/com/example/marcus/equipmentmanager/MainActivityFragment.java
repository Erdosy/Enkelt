package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

/**
 * Default fragment for second fragment in landscape
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class MainActivityFragment extends Fragment {

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.welcome, container, false);
    }
}

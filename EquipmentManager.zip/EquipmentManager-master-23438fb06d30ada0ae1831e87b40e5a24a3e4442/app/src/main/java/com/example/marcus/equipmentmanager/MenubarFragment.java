package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;


/**
 * Handles Menu Bar Fragment
 */
public class MenubarFragment extends Fragment {

    QueryHandler queryHandler; // handles queries from application
    int isLoggedIn; // user level of logged in user
    View view; // current view

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        queryHandler = new QueryHandler(this.getActivity());
        view = inflater.inflate(R.layout.fragment_menubar, container, false);
        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        isLoggedIn = ((MainActivity) getActivity()).getLoggedIn();
        if (isLoggedIn == 0) {
            view.findViewById(R.id.btnInactiveUsers).setVisibility(View.GONE);
            view.findViewById(R.id.btnActiveUsers).setVisibility(View.GONE);
            view.findViewById(R.id.btnAddUser).setVisibility(View.GONE);
            view.findViewById(R.id.btnActiveLoans).setVisibility(View.GONE);
            view.findViewById(R.id.btnRegisterLoan).setVisibility(View.GONE);
            view.findViewById(R.id.btnLogOut).setVisibility(View.GONE);
            view.findViewById(R.id.btnProfile).setVisibility(View.GONE);
            view.findViewById(R.id.btnRegisterEquipment).setVisibility(View.GONE);
            view.findViewById(R.id.btnMyLoans).setVisibility(View.GONE);
        } else {
            view.findViewById(R.id.btnLogin).setVisibility(View.GONE);
            view.findViewById(R.id.btnRegister).setVisibility(View.GONE);
        }
        if (isLoggedIn == 1) {
            view.findViewById(R.id.btnActiveUsers).setVisibility(View.GONE);
            view.findViewById(R.id.btnInactiveUsers).setVisibility(View.GONE);
            view.findViewById(R.id.btnRegisterEquipment).setVisibility(View.GONE);
            view.findViewById(R.id.btnActiveLoans).setVisibility(View.GONE);
            view.findViewById(R.id.btnAddUser).setVisibility(View.GONE);
            view.findViewById(R.id.btnRegisterLoan).setVisibility(View.GONE);
        }
    }
}

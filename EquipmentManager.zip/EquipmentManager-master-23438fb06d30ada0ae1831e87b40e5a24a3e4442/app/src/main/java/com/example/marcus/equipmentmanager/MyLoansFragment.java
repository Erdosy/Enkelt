package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;

import java.util.ArrayList;

/**
 * Handles My Loans Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class MyLoansFragment extends Fragment implements View.OnClickListener {

    View view; // active view
    QueryHandler queryHandler; // handles queries from application
    ResponseHandler responseHandler; // handles response strings from backend
    ListView lvLoans; // listview of active loans
    String response; // response string from backend
    int index; // index of selected item in listview
    LayoutInflater inflater; // inflater to inflate views
    ViewGroup container; // container for view
    User user; // current user
    ArrayList<Equipment> equipmentList; // list of equipment
    ArrayList<LogEntry> loans; // list of log entries
    LogEntry loan; // current log entry
    Context context; // current context


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_active_loans, container, false);

        this.container = container;
        this.inflater = inflater;
        this.context = getActivity();

        queryHandler = ((MainActivity) context).getQueryHandler();
        user = ((MainActivity) context).getUser();
        queryHandler.getOpenLogEntriesForUser(user.getU_id());
        ((MainActivity) context).setIsMyLoans(true);
        queryHandler.getEquipment("IN_USE");
        responseHandler = new ResponseHandler(getActivity());

        lvLoans = (ListView) view.findViewById(R.id.lvLoanList);
        Button btnLoanDetails = (Button) view.findViewById(R.id.btnLoanDetails);
        btnLoanDetails.setOnClickListener(this);
        view.findViewById(R.id.btnEndLoan).setVisibility(View.GONE);
        return view;
    }

    /**
     * Populates list of log entries
     */
    public void populateList() {
        ArrayList<User> users = new ArrayList<>();
        users.add(user);
        LoanAdapter loanAdapter = new LoanAdapter(context, R.layout.loan_short, loans, equipmentList, users);
        lvLoans.setAdapter(loanAdapter);
        lvLoans.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                index = position;
            }
        });
    }

    @Override
    public void onClick(View v) {
        loan = (LogEntry) lvLoans.getItemAtPosition(index);
        switch (v.getId()) {
            case R.id.btnLoanDetails:
                ((MainActivity) context).setLoanDetailsFragment(loan);
                break;
        }
    }

    /**
     * Sets list of equipment
     *
     * @param response response message from backend
     */
    public void setEquipment(String response) {
        equipmentList = responseHandler.getEquipmentResponse(response);
        if (loans != null && equipmentList != null && user != null) {
            populateList();
        }
    }

    /**
     * Sets list of log entries
     *
     * @param response response message from backend
     */
    public void setLoans(String response) {
        loans = responseHandler.getOpenLogEntriesForUserResponse(response);
        if (loans != null && equipmentList != null && user != null) {
            populateList();
        }
    }
}

package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.util.Pair;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import org.apache.http.NameValuePair;
import org.apache.http.client.HttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import java.util.ArrayList;
import java.util.List;

/**
 * Handles queries to backend
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
@SuppressWarnings({"deprecation", "unchecked"})  //As far as to my understanding, this warning is not relevant in this context. The varargs should be safe for array creation.
public class QueryHandler {

    HttpClient httpClient = null;  //The httpClient for communication with the server.
    HttpClient httpClientNewPass = null; //Separate httpClient for changing password without login.
    Context context = null; //The context (MainActivity)
    final static int NORMAL_USER = 1; //int value for a normal user.
    final static int LOGGED_OUT = 0; //int value for a not logged in user.
    final static int ADMIN_USER = 2; //int value for admin user.
    private static String DB_CONNECTSTRING = "jdbc:mysql://kark.hin.no:3306/"; //The database location.
    private static String DB_NAME = "stud_v15_andersson"; //The database name
    private static String DB_UID = "andersson"; //The database username
    private static String DB_PWD = "databaser2015"; //The database password

    /**
     * Constructor
     * @param context the context (MainActivity)
     */
    public QueryHandler(Context context){
        this.context = context;
    }

    /**
     * Calls the logIn method on the server.
     *
     * @param view The login view. Used to pass the login data without sending it as strings in the code.
     */
    public void logIn(View view){
        String uId = ((EditText)view.findViewById(R.id.etUsernameLogin)).getText().toString();
        String password = ((EditText)view.findViewById(R.id.etPasswordLogin)).getText().toString();
        boolean success = handleQuery(true, LOGGED_OUT, true, null, "logIn", uId, password, true);
        if(!success)
            Toast.makeText(context, R.string.alreadyLoggedIn, Toast.LENGTH_LONG).show();
    }

    /**
     * Calls the logInAdmin method on the server.
     *
     * @param view The login view. Used to pass the login data without sending it as string in the code.
     */
    public void logInAdmin(View view){
        if (((MainActivity)context).getLoggedIn() == LOGGED_OUT){
            httpClient = new DefaultHttpClient();
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(7);
            nameValuePairs.add(new BasicNameValuePair("query_type", "logInAdmin"));
            EditText etUsername = (EditText)view.findViewById(R.id.etUsernameLogin);
            nameValuePairs.add(new BasicNameValuePair("uid", etUsername.getText().toString()));
            EditText etPassword = (EditText)view.findViewById(R.id.etPasswordLogin);
            nameValuePairs.add(new BasicNameValuePair("pwd", etPassword.getText().toString()));
            nameValuePairs.add(new BasicNameValuePair("connectstring", DB_CONNECTSTRING));
            nameValuePairs.add(new BasicNameValuePair("dbName", DB_NAME));
            nameValuePairs.add(new BasicNameValuePair("db_uid", DB_UID));
            nameValuePairs.add(new BasicNameValuePair("db_pwd", DB_PWD));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.alreadyLoggedIn, Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Calls the logIn method on the server. Called automatically on startup if the setting are
     * set to automatic login.
     *
     * @param username Username from sharedPreferences.
     * @param password Password from sharedPreferences.
     */
    public void logInAutomatically(String username, String password) {
        boolean success = handleQuery(true, LOGGED_OUT, true, null, "logIn", username, password, true);
        if (!success)
            Toast.makeText(context, R.string.alreadyLoggedIn, Toast.LENGTH_LONG).show();
    }

    public void getEquipment(String which){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getEquipment"));
            nameValuePairs.add(new BasicNameValuePair("which_equipment", which));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(LOGGED_OUT);
        }
    }

    /**
     * Calls the logOut method on the server.
     */
    public void logOut(){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(1);
            nameValuePairs.add(new BasicNameValuePair("query_type", "logOut"));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.alreadyLoggedOut, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the addEquipment method on the server. Adds new equipment to the database
     *
     * @param equipment Equipment object to be added.
     */
    public void addEquipment(Equipment equipment){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "addEquipment"));
            nameValuePairs.add(new BasicNameValuePair("equipment", equipment.toJSONString()));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the addUser method on the server. Adds a new user to the database.
     *
     * @param user User object to be added.
     */
    public void addUser(User user){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "addUser"));
            nameValuePairs.add(new BasicNameValuePair("user", user.toJSONString()));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the addUserWithoutLogin method on the server. For new users to register themselves.
     *
     * @param user The user object to be added.
     */
    public void addUserWithoutLogin(User user){
        if (httpClient == null) {
            httpClient = new DefaultHttpClient();
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(6);
            nameValuePairs.add(new BasicNameValuePair("query_type", "addUserWithoutLogin"));
            nameValuePairs.add(new BasicNameValuePair("user", user.toJSONString()));
            nameValuePairs.add(new BasicNameValuePair("connectstring", DB_CONNECTSTRING));
            nameValuePairs.add(new BasicNameValuePair("dbName", DB_NAME));
            nameValuePairs.add(new BasicNameValuePair("db_uid", DB_UID));
            nameValuePairs.add(new BasicNameValuePair("db_pwd", DB_PWD));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
    }

    /**
     * Calls the confirmRegisteredUser method on the server. Requires admin.
     *
     * @param userId The id of the user to be confirmed.
     */
    public void confirmRegisteredUser(int userId){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "confirmRegisteredUser"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the changeUserPassword method on the server.
     *
     * @param userId The id of the user to change password on.
     * @param newPassword The new password.
     */
    public void changeUserPassword(int userId, String newPassword){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(3);
            nameValuePairs.add(new BasicNameValuePair("query_type", "changeUserPassword"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            nameValuePairs.add(new BasicNameValuePair("newPassword", newPassword));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the deleteEquipment method on the server.
     *
     * @param equipmentId Id of the equipment to remove from the database.
     */
    public void deleteEquipment(int equipmentId){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "deleteEquipment"));
            nameValuePairs.add(new BasicNameValuePair("equipmentId", Integer.toString(equipmentId)));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the deleteUser method on the server.
     *
     * @param userId Id of the user to remove from the database.
     */
    public void deleteUser(int userId){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "deleteUser"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getActiveUsers method on the server.
     */
    public void getActiveUsers(){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(1);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getActiveUsers"));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getAllLogEntriesForAllUser method on the server.
     * Currently not used (found no reason to request finished loans info).
     * Left in for possible future implementation
     */
    public void getAllLogEntriesForAllUser(){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(1);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getAllLogEntriesForAllUser"));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getEquipmentType method on the server.
     * Currently not used. The search function is a better implementation of this.
     * Left in for possible future implementation
     *
     * @param type Type of equipment to request.
     */
    public void getEquipmentType(String type){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getEquipmentType"));
            nameValuePairs.add(new BasicNameValuePair("type", type));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getEquipmentWithoutLogin method on the server.
     */
    public void getEquipmentWithoutLogin(){
        httpClient = new DefaultHttpClient();
        List<NameValuePair> nameValuePairs;
        nameValuePairs = new ArrayList<>(5);
        nameValuePairs.add(new BasicNameValuePair("query_type", "getEquipmentWithoutLogin"));
        nameValuePairs.add(new BasicNameValuePair("connectstring", DB_CONNECTSTRING));
        nameValuePairs.add(new BasicNameValuePair("dbName", DB_NAME));
        nameValuePairs.add(new BasicNameValuePair("db_uid", DB_UID));
        nameValuePairs.add(new BasicNameValuePair("db_pwd", DB_PWD));
        new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
    }

    /**
     * Calls the getLogEntriesForUser on the server.
     * Left in for possible future implementation
     *
     * @param userId Id of the user to request logentries for.
     */
    public void getLogEntriesForUser(int userId){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getLogEntriesForUser"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getNotActivatedUsers method on the server.
     */
    public void getNotActivatedUsers(){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(1);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getNotActivatedUsers"));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getOpenLogEntries method on the server.
     */
    public void getOpenLogEntries(){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getOpenLogEntries"));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getOpenLogEntriesForUser method on the server.
     *
     * @param userId Id of the user to request open log entries for.
     */
    public void getOpenLogEntriesForUser(int userId){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getOpenLogEntriesForUser"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the getUsers method on the server.
     *
     * @param userId Id of the user to request info about.
     */
    public void getUsers(int userId){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(2);
            nameValuePairs.add(new BasicNameValuePair("query_type", "getUsers"));
            if(userId != 0) {
                nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            }
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the registerReservationIn method on the server.
     * @param le_id Id of the logEntry to register in.
     * @param dateIn Date of delivery.
     */
    public void registerReservationIn(int le_id, String dateIn){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(3);
            nameValuePairs.add(new BasicNameValuePair("query_type", "registerReservationIn"));
            nameValuePairs.add(new BasicNameValuePair("le_id", Integer.toString(le_id)));
            nameValuePairs.add(new BasicNameValuePair("dateIn", dateIn));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the registerReservationOut method on the server.
     *
     * @param userId Id of the user that requested the loan.
     * @param equipmentId Id of the equipment loaned out.
     * @param dateOut Date of loan start.
     * @param comment Comment about the loan.
     */
    public void registerReservationOut(int userId, int equipmentId, String dateOut, String comment){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(5);
            nameValuePairs.add(new BasicNameValuePair("query_type", "registerReservationOut"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(userId)));
            nameValuePairs.add(new BasicNameValuePair("equipmentId", Integer.toString(equipmentId)));
            nameValuePairs.add(new BasicNameValuePair("dateOut", dateOut));
            nameValuePairs.add(new BasicNameValuePair("comment", comment));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the updateEquipment method on the server.
     *
     * @param equipment Equipment object to be updated.
     */
    public void updateEquipment(Equipment equipment){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(3);
            nameValuePairs.add(new BasicNameValuePair("query_type", "updateEquipment"));
            nameValuePairs.add(new BasicNameValuePair("equipmentId", Integer.toString(equipment.getE_id())));
            nameValuePairs.add(new BasicNameValuePair("equipment", equipment.toJSONString()));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the updateUser method on the server.
     *
     * @param user User object to be updated.
     */
    public void updateUser(User user){
        if(httpClient != null){
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(3);
            nameValuePairs.add(new BasicNameValuePair("query_type", "updateUser"));
            nameValuePairs.add(new BasicNameValuePair("userId", Integer.toString(user.getU_id())));
            nameValuePairs.add(new BasicNameValuePair("user", user.toJSONString()));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
        }
        else{
            Toast.makeText(context, R.string.haveToBeLoggedIn, Toast.LENGTH_LONG).show();
            ((MainActivity)context).setLoggedIn(0);
        }
    }

    /**
     * Calls the changeUserPasswordGetCode method on the server.
     *
     * @param countryCode country code of the users phone.
     * @param phoneNo The users phone number to send the code to.
     */
    public void changeUserPasswordGetCode(String countryCode, String phoneNo){
        httpClientNewPass = new DefaultHttpClient();
        List<NameValuePair> nameValuePairs;
        nameValuePairs = new ArrayList<>(7);
        nameValuePairs.add(new BasicNameValuePair("query_type", "changeUserPasswordGetCode"));
        nameValuePairs.add(new BasicNameValuePair("countryCode", countryCode));
        nameValuePairs.add(new BasicNameValuePair("phoneNo", phoneNo));
        nameValuePairs.add(new BasicNameValuePair("connectstring", DB_CONNECTSTRING));
        nameValuePairs.add(new BasicNameValuePair("dbName", DB_NAME));
        nameValuePairs.add(new BasicNameValuePair("db_uid", DB_UID));
        nameValuePairs.add(new BasicNameValuePair("db_pwd", DB_PWD));
        new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClientNewPass));
    }

    /**
     * Calls the changeUserPasswordByCode method on the server.
     *
     * @param code The code sent by SMS to the user.
     * @param newPassword The new password to change to.
     */
    public void changeUserPasswordByCode(String code, String newPassword){
        if(httpClientNewPass != null) {
            List<NameValuePair> nameValuePairs;
            nameValuePairs = new ArrayList<>(7);
            nameValuePairs.add(new BasicNameValuePair("query_type", "changeUserPasswordByCode"));
            nameValuePairs.add(new BasicNameValuePair("code", code));
            nameValuePairs.add(new BasicNameValuePair("newPassword", newPassword));
            nameValuePairs.add(new BasicNameValuePair("connectstring", DB_CONNECTSTRING));
            nameValuePairs.add(new BasicNameValuePair("dbName", DB_NAME));
            nameValuePairs.add(new BasicNameValuePair("db_uid", DB_UID));
            nameValuePairs.add(new BasicNameValuePair("db_pwd", DB_PWD));
            new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClientNewPass));
        }
    }

    /**
     * Gets the txt file with the different equipment types from the server.
     */
    public void getTypeFile(){
        new TypeFileAsyncTask(context).execute();
    }

    /**
     * Had plans to refactor the QueryHandler a bit. Only refactored the login methods so far.
     *
     * @param requireLogin is login required?
     * @param loggedInAs user level of logged in user
     * @param withoutLogin do without login?
     * @param httpClient http client to use
     * @param queryType the type of query
     * @param uId user id
     * @param password user password
     * @param requireConnection requires connection to database?
     * @return true if query was successfully sent
     */
    public boolean handleQuery(boolean requireLogin, int loggedInAs, boolean withoutLogin, HttpClient httpClient, String queryType, String uId, String password, boolean requireConnection){
        if (((MainActivity)context).getLoggedIn() == loggedInAs || !requireLogin){ //If login is correct or login isn't required
            if(withoutLogin)
                this.httpClient = httpClient = new DefaultHttpClient();
            if(httpClient != null) {
                List<NameValuePair> nameValuePairs;
                nameValuePairs = new ArrayList<>();
                nameValuePairs.add(new BasicNameValuePair("query_type", queryType));
                if(uId != null)
                    nameValuePairs.add(new BasicNameValuePair("uid", uId));
                if(password != null)
                    nameValuePairs.add(new BasicNameValuePair("pwd", password));
                if(requireConnection) {
                    nameValuePairs.add(new BasicNameValuePair("connectstring", DB_CONNECTSTRING));
                    nameValuePairs.add(new BasicNameValuePair("dbName", DB_NAME));
                    nameValuePairs.add(new BasicNameValuePair("db_uid", DB_UID));
                    nameValuePairs.add(new BasicNameValuePair("db_pwd", DB_PWD));
                }
                new AccesserAsyncTask(context).execute(new Pair<>(nameValuePairs, httpClient));
                return true;
            }
        }
        return false;
    }
}

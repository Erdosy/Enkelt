package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.hardware.Camera;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import java.io.File;
import java.io.FileInputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Handle Register Equipment Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class RegisterEquipmentFragment extends Fragment implements View.OnClickListener {

    Context context; //context used in fragment, from calling activity
    Button btnTakePicture; // button to redirect to camera
    View view; // active view
    File photoFile; // photo from camera
    QueryHandler queryHandler; // handles queries from application
    Spinner spnEquipmentType; // spinner with selected type options from downloaded file
    final int REQUEST_IMAGE_CAPTURE = 1; // constant int value for requesting picture from camera
    Equipment equipment; // the equipment object to eventually be saved to database

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        context = getActivity();
        view = inflater.inflate(R.layout.fragment_register_equipment, container, false);
        btnTakePicture = (Button) view.findViewById(R.id.btnEquipmentPicture);
        btnTakePicture.setOnClickListener(this);
        Button btnRegister = (Button) view.findViewById(R.id.btnSaveEquipmentRegister);
        btnRegister.setOnClickListener(this);
        queryHandler = ((MainActivity) getActivity()).getQueryHandler();
        spnEquipmentType = (Spinner) view.findViewById(R.id.spnEquipmentType);
        ((MainActivity) getActivity()).equipmentTypeQuery("RegisterEquipment");
        queryHandler.getTypeFile();
        equipment = new Equipment();
        return view;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnEquipmentPicture:
                takePicture();
                break;
            case R.id.btnSaveEquipmentRegister:
                equipment.setBrand(((EditText) view.findViewById(R.id.etEquipmentBrand)).getText().toString());
                equipment.setType(((Spinner) view.findViewById(R.id.spnEquipmentType)).getSelectedItem().toString());
                equipment.setModel(((EditText) view.findViewById(R.id.etEquipmentModel)).getText().toString());
                equipment.setIt_no(((EditText) view.findViewById(R.id.etEquipmentItNo)).getText().toString());
                equipment.setDescription(((EditText) view.findViewById(R.id.etEquipmentDescription)).getText().toString());
                equipment.setAquired(new SimpleDateFormat(getString(R.string.dateFormat), Locale.US).format(new Date()));
                queryHandler.addEquipment(equipment);
                refreshView();
                break;
        }
    }

    /**
     * Checks if camera is active on phone.
     * Tries to let the user take a picture and then displays it in register view.
     */
    private void takePicture() {
        //noinspection deprecation
        if ((Build.VERSION.SDK_INT > 20 && context.getPackageManager().hasSystemFeature(PackageManager.FEATURE_CAMERA)) || (Build.VERSION.SDK_INT < 21 && Camera.getNumberOfCameras() > 0)) {
            if (!dispatchTakePictureIntent())
                Toast.makeText(context, Utility.capitalizeFirstLetter(getString(R.string.imageAcquisitionFailed)), Toast.LENGTH_LONG).show();
        } else {
            Toast.makeText(context, R.string.no_camera_found, Toast.LENGTH_LONG).show();
        }
    }

    /**
     * Calls camera app to take picture and store it in public pictures folder.
     *
     * @return true if intent to take picture was successfully dispatched
     */
    private boolean dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        if (takePictureIntent.resolveActivity(context.getPackageManager()) != null) {
            try {
                String filename = new SimpleDateFormat("ddMMyy_HHmmss", Locale.US).format(new Date());
                File directory = Environment.getExternalStoragePublicDirectory(
                        Environment.DIRECTORY_PICTURES);
                photoFile = File.createTempFile(filename, ".png", directory);
            } catch (Exception e) {
                Toast.makeText(context, getString(R.string.storage_error), Toast.LENGTH_LONG).show();
                return false;
            }
            takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, Uri.fromFile(photoFile));
            startActivityForResult(takePictureIntent, REQUEST_IMAGE_CAPTURE);
            return true;
        }
        return false;
    }

    /**
     * Populates type spinner
     *
     * @param types defined types from input.
     */
    public void populateEquipmentTypes(ArrayList<String> types) {
        ArrayAdapter<String> typeAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1, types);
        spnEquipmentType.setAdapter(typeAdapter);
    }

    /**
     * Refreshes the view
     */
    public void refreshView() {
        ((Spinner) view.findViewById(R.id.spnEquipmentType)).setSelection(0);
        ((EditText) view.findViewById(R.id.etEquipmentBrand)).setText(null);
        ((EditText) view.findViewById(R.id.etEquipmentModel)).setText(null);
        ((EditText) view.findViewById(R.id.etEquipmentItNo)).setText(null);
        ((EditText) view.findViewById(R.id.etEquipmentDescription)).setText(null);
        ImageView imageView = (ImageView) view.findViewById(R.id.ivEquipmentImage);
        imageView.setImageBitmap(null);
        equipment = new Equipment();
    }

    /**
     * Sets the image in view, transforms bitmap to byte array and sets to equipment object image
     *
     * @param image the bitmap image to put in view and transform to byte array for equipment object
     */
    public void setImage(Bitmap image) {
        byte[] imageByteArray = Utility.bitmapToByteArray(image);
        equipment.setImage(imageByteArray);
        ImageView imageView = (ImageView) view.findViewById(R.id.ivEquipmentImage);
        imageView.setImageBitmap(image);
        if (imageView.getDrawable() == null) {
            Toast.makeText(context, Utility.capitalizeFirstLetter(getString(R.string.noPictureFound)), Toast.LENGTH_LONG).show();
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        byte[] image = new byte[(int) photoFile.length()];
        try {
            //noinspection ResultOfMethodCallIgnored
            new FileInputStream(photoFile).read(image);
            ((MainActivity) getActivity()).setIsRegister(true);
            new ImageResizeAsyncTask(context).execute(image);
        } catch (Exception e) {
            Toast.makeText(context, getString(R.string.readingImageFileToByteArrayFailed), Toast.LENGTH_LONG).show();
        }
    }
}

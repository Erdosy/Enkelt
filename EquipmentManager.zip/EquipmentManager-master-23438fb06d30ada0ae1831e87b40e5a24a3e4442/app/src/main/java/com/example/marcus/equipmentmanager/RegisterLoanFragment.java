package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

/**
 * Handle Register Loan Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class RegisterLoanFragment extends Fragment implements View.OnClickListener{

    QueryHandler queryHandler; // handles queries from application
    ResponseHandler responseHandler; // handles response strings from backend
    View view; // active view
    Spinner spnUsers; // spinner for list of users
    Spinner spnEquipment; // spinner for list of equipment
    EditText etComment; // edit text view for comment
    User selectedUser; // current selected user
    Equipment selectedEquipment; // current selected equipment
    ArrayList<Equipment> equipmentList; // list of equipment
    boolean isEquipSpinner; // is equipment displayed with spinner?
    boolean isUserSpinner; // is users displayed with spinner?
    boolean useList = false; // use list for equipment?



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        container.removeAllViews();
        view = inflater.inflate(R.layout.fragment_register_loan, container, false);
        queryHandler = ((MainActivity)getActivity()).getQueryHandler();
        Button btnSaveLoan = (Button)view.findViewById(R.id.btnSaveLoanRegister);
        btnSaveLoan.setOnClickListener(this);
        spnUsers = (Spinner)view.findViewById(R.id.spnUsers);
        etComment = (EditText)view.findViewById(R.id.etComment);
        responseHandler = new ResponseHandler(getActivity());
        if(useList) {
            ((MainActivity)getActivity()).setIsRegisterLoan(true);
            queryHandler.getEquipment("AVAILABLE");
            spnEquipment = (Spinner)view.findViewById(R.id.spnEquipment);
            view.findViewById(R.id.tvEquipment).setVisibility(View.GONE);
            view.findViewById(R.id.spnEquipment).setVisibility(View.VISIBLE);
        }
        else{
            view.findViewById(R.id.spnEquipment).setVisibility(View.GONE);
            view.findViewById(R.id.tvEquipment).setVisibility(View.VISIBLE);
            populateEquipment();
        }
        queryHandler.getActiveUsers();
        return view;
    }

    @Override
    public void onDestroyView(){
        super.onDestroyView();
        ((MainActivity)getActivity()).setRegisterLoan(false);
        selectedUser = null;
    }

    @Override
    public void onClick(View v) {
        if(isUserSpinner){
            if(spnUsers != null && spnUsers.getSelectedItem() != null){
                selectedUser = (User)spnUsers.getSelectedItem();
            }
            else {
                Toast.makeText(getActivity(), getString(R.string.there_was_error) + getString(R.string.loan_registration), Toast.LENGTH_LONG ).show();
            }
        }
        if(isEquipSpinner){
            if(spnEquipment != null && spnEquipment.getSelectedItem() != null){
                selectedEquipment = (Equipment)spnEquipment.getSelectedItem();
            }
            else {
                Toast.makeText(getActivity(), getString(R.string.there_was_error) + getString(R.string.loan_registration), Toast.LENGTH_LONG ).show();
            }
        }
        int equipmentId = selectedEquipment.getE_id();
        int userId = selectedUser.getU_id();
        SimpleDateFormat sdf = new SimpleDateFormat(getString(R.string.dateFormat), Locale.US);
        String dateOut = sdf.format(new Date());
        String comment = "";
        if(etComment !=null && etComment.getText() != null) {
            comment = etComment.getText().toString();
            etComment.setText("");
        }

        queryHandler.registerReservationOut(userId, equipmentId, dateOut, comment);
    }

    /**
     * Populates user list view, sets adapter and onItemClickListener
     *
     * @param response   response message with list of users
     */
    public void populateUsers(String response) {
        // if user sent with args, set user text instead of spinner
        if(((MainActivity)getActivity()).getLoggedIn() == QueryHandler.NORMAL_USER) {
            isUserSpinner = false;
            selectedUser = ((MainActivity)getActivity()).getUser();
            ViewGroup vg = (ViewGroup)spnUsers.getParent();
            int index = vg.indexOfChild(spnUsers);
            vg.removeView(spnUsers);
            TextView tvUser = (TextView)getActivity().getLayoutInflater().inflate(R.layout.tv_default, vg, false);
            tvUser.setText(selectedUser.toString());
            vg.addView(tvUser, index);
        }else{
            // Populate user spinner
            isUserSpinner = true;
            ArrayList<User> users = responseHandler.getActiveUsersResponse(response);
            ArrayAdapter<User> userAdapter = new ArrayAdapter<>(getActivity(), android.R.layout.simple_list_item_1 , users);
            spnUsers.setAdapter(userAdapter);
        }
    }

    /**
     * Populates equipment list view, sets adapter and onItemClickListener
     */
    public void populateEquipment() {
        // if equipment sent with args, set equipment instead of spinner
        if(!useList) {
            isEquipSpinner = false;
            ((TextView)view.findViewById(R.id.tvEquipment)).setText(selectedEquipment.toString());
        }else{
            // Populate equipment spinner
            isEquipSpinner = true;
            EquipmentAdapter equipmentAdapter = new EquipmentAdapter(getActivity(), android.R.layout.simple_list_item_1, equipmentList);
            spnEquipment.setAdapter(equipmentAdapter);

        }
    }

    /**
     * Sets single equipment
     *
     * @param equipment equipment to set
     */
    public void setSingleEquipment(Equipment equipment){
        this.selectedEquipment = equipment;
    }

    /**
     * Sets equipment list
     *
     * @param response  response message with list of equipment
     */
    public void setEquipmentList(String response){
        equipmentList = responseHandler.getEquipmentResponse(response);
        populateEquipment();
    }

    /**
     * Sets use list boolean
     * @param useList   use list?
     */
    public void useList(boolean useList){
        this.useList = useList;
    }
}

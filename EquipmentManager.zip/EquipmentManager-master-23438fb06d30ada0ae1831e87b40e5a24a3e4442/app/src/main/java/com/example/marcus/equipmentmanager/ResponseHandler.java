package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


import java.lang.reflect.Type;
import java.util.ArrayList;

/**
 * Handles response json strings from backend
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class ResponseHandler {

    Context context;  // context to be used
    Gson gson; // gson object for converting json strings

    /**
     * Constructor
     *
     * @param context   context to use
     */
    public ResponseHandler(Context context) {
        this.context = context;
        gson = new Gson();
    }

    /**
     * Converts response string to user object
     *
     * @param response  response string from backend to convert
     * @return  user object from response string
     */
    public User logInResponse(String response) {
        User user;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.loggingIn};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            user = gson.fromJson(json, User.class);
            return user;
        }
    }

    /**
     * Converts response message to array list with equipment objects
     *
     * @param response  response string from backend to convert
     * @return  array list with equipment objects
     */
    public ArrayList<Equipment> getEquipmentResponse(String response) {
        ArrayList<Equipment> equipmentList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.equipment};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<Equipment>>() {
            }.getType();
            equipmentList = gson.fromJson(json, type);
            return equipmentList;
        }
    }

    /**
     * Logs user out if response returns with positive result
     *
     * @param response  response string from backend
     */
    public void logOutResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.alreadyLoggedOut};
            makeToast(stringIds, null);
        } else {
            int[] stringIds = {R.string.logoutSuccessful};
            makeToast(stringIds, null);
            ((MainActivity) context).setLoggedIn(0);
        }
    }

    /**
     * Checks if adding equipment to database was successful
     *
     * @param response  reponse message from backend
     */
    public void addEquipmentResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.addingEquipment};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.equipment, R.string.succesfullyAddedToDatabase};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if adding user was successful
     *
     * @param response  response message from backend
     * @return  returns positive or negative result from backend
     */
    public boolean addUserResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.addingUser};
            makeToast(stringIds, res.getMessage());
            return false;
        } else {
            int[] stringIds = {R.string.userSuccessfullyAddedToDatabase};
            makeToast(stringIds, null);
            return true;
        }
    }

    /**
     * Checks if adding user to database was successful
     *
     * @param response  response message from backend
     */
    public void addUserWithoutLoginResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.addingUser};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.userSuccessfullyAddedToDatabase};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if confirmation of user was successful
     *
     * @param response  response message from backend
     */
    public void confirmRegisteredUserResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.activatingUser};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.userSuccessfullyActivated};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if user password was successfully changed
     *
     * @param response  response message from backend
     */
    public void changeUserPasswordResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.duringPasswordChange};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.passwordSuccessfullyChanged};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if deletion of equipment from database was successful
     *
     * @param response  response message from backend
     */
    public void deleteEquipmentResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.deletingEquipment};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.equipment, R.string.succesfullyRemovedFromDatabase};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if deletion of user from database was successful
     *
     * @param response  response message from backend
     */
    public void deleteUserResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.deletingUser};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.userSuccessfullyRemovedFromDatabase};
            makeToast(stringIds, null);
        }
    }

    /**
     * Converts response message to array list of users
     *
     * @param response  response message from backend
     * @return  array list of users
     */
    public ArrayList<User> getActiveUsersResponse(String response) {
        ArrayList<User> userList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.users};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<User>>() {
            }.getType();
            userList = gson.fromJson(json, type);
            return userList;
        }
    }

    /**
     * Converts response message to array list of log entries
     * @param response  reponse message from backend
     * @return  array list of log entries
     */
    public ArrayList<LogEntry> getAllLogEntriesForAllUserResponse(String response) {
        ArrayList<LogEntry> logList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.logs};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<LogEntry>>() {
            }.getType();
            logList = gson.fromJson(json, type);
            return logList;
        }
    }

    /**
     * Converts response message to array list of equipment
     *
     * @param response  response message from backend
     * @return  array list of equipment
     */
    public ArrayList<Equipment> getEquipmentTypeResponse(String response) {
        ArrayList<Equipment> equipmentList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.equipment};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<Equipment>>() {
            }.getType();
            equipmentList = gson.fromJson(json, type);
            return equipmentList;
        }
    }

    /**
     * Converts response message to array list of log entries
     *
     * @param response  response message from backend
     * @return  array list of log entries
     */
    public ArrayList<LogEntry> getLogEntriesForUserResponse(String response) {
        ArrayList<LogEntry> logList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.logs};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<LogEntry>>() {
            }.getType();
            logList = gson.fromJson(json, type);
            return logList;
        }
    }

    /**
     * Converts response message to array list of users
     * @param response  response message from backend
     * @return  array list of users
     */
    public ArrayList<User> getNotActivatedUsersResponse(String response) {
        ArrayList<User> userList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.users};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<User>>() {
            }.getType();
            userList = gson.fromJson(json, type);
            return userList;
        }
    }

    /**
     * Converts response message to array list of log entries
     *
     * @param response  response message from backend
     * @return  array list with log entries
     */
    public ArrayList<LogEntry> getOpenLogEntriesResponse(String response) {
        ArrayList<LogEntry> logList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.logs};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<LogEntry>>() {
            }.getType();
            logList = gson.fromJson(json, type);
            return logList;
        }
    }

    /**
     * Converts response message to array list of log entries
     *
     * @param response  response message from backend
     * @return  array list of log entries
     */
    public ArrayList<LogEntry> getOpenLogEntriesForUserResponse(String response) {
        ArrayList<LogEntry> logList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.logs};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<LogEntry>>() {
            }.getType();
            logList = gson.fromJson(json, type);
            return logList;
        }
    }

    /**
     * Converts response message to array list of users
     *
     * @param response  response message from backend
     * @return  array list of users
     */
    public ArrayList<User> getUsersResponse(String response) {
        ArrayList<User> userList;
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.fetching, R.string.users};
            makeToast(stringIds, res.getMessage());
            return null;
        } else {
            String json = res.getJsonResponse();
            Type type = new TypeToken<ArrayList<User>>() {
            }.getType();
            userList = gson.fromJson(json, type);
            return userList;
        }
    }

    /**
     * Checks if register reservation in was successful
     *
     * @param response  response message from backend
     */
    public void registerReservationInResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.registeringEquipment};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.equipment, R.string.succesfullyRegisteredAsDelivered};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if register reservation out was successful
     *
     * @param response  response message from backend
     */
    public void registerReservationOutResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.registeringEquipment};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.equipment, R.string.succesfullyRegisteredAsReserved};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if update of equipment was successful
     *
     * @param response  response message from bacend
     */
    public void updateEquipmentResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.updatingEquipment};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.equipment, R.string.successfullyUpdated};
            makeToast(stringIds, null);
        }
    }

    /**
     * Checks if update of user was successful
     *
     * @param response  response message from backend
     */
    public void updateUserResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (!res.getResult()) {
            int[] stringIds = {R.string.there_was_error, R.string.updatingUser};
            makeToast(stringIds, res.getMessage());
        } else {
            int[] stringIds = {R.string.userSuccessfullyUpdated};
            makeToast(stringIds, null);
        }
    }

    /**
     * Converts response message to array list of types as strings
     *
     * @param response  response message from backend
     * @return  array list of types as strings
     */
    public ArrayList<String> getTypeFileResponse(String response) {
        Gson gson = new Gson();
        Type type = new TypeToken<ArrayList<String>>() {
        }.getType();
        return gson.fromJson(response, type);
    }

    /**
     * Checks if request to get code was successful
     *
     * @param response  response message from backend
     * @return  result from backend
     */
    public boolean changeUserPasswordGetCodeResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (res.getResult()) {
            int[] stringIds = {R.string.getCodeSuccess};
            makeToast(stringIds, null);
            return true;
        } else {
            int[] stringIds = {R.string.there_was_error, R.string.requestCode};
            makeToast(stringIds, null);
            return false;
        }
    }

    /**
     * Checks if change of password by code was successful
     *
     * @param response  response message from backend
     * @return  result from backend
     */
    public boolean changeUserPasswordByCodeResponse(String response) {
        ResponseMsg res = gson.fromJson(response, ResponseMsg.class);
        if (res.getResult()) {
            int[] stringIds = {R.string.passwordSuccessfullyChanged};
            makeToast(stringIds, null);
            return true;
        } else {
            int[] stringIds = {R.string.there_was_error, R.string.duringPasswordChange};
            makeToast(stringIds, null);
            return false;
        }
    }

    /**
     * Displays toast with first letter capitalized.
     *
     * @param stringIds resource strings in message to display
     * @param extraString   extra string in message to display
     */
    public void makeToast(int[] stringIds, String extraString) {
        StringBuilder message = new StringBuilder(32);
        message.append(Utility.capitalizeFirstLetter(context.getString(stringIds[0])));
        for (int i = 1; i < stringIds.length; i++) {
            message.append(" ");
            message.append(context.getString(stringIds[i]));
        }
        if (extraString != null) {
            message.append(": ");
            message.append(extraString);
        }
        Toast.makeText(context, message, Toast.LENGTH_LONG).show();
    }
}

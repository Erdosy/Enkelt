package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.content.Context;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CheckBox;
import android.widget.CompoundButton;

/**
 * Handles the Settings Fragment
 *
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class SettingsFragment extends Fragment implements CheckBox.OnCheckedChangeListener, View.OnClickListener {

    View view; // current view
    Context context; // context from activity
    boolean rememberPassword; // remember password setting
    boolean rememberUsername; // remember username setting
    boolean autoLogin; // auto login setting
    CheckBox cbPassword; // checkbox for remember password
    CheckBox cbUsername; // checkbox for remember username
    CheckBox cbAutoLogin; // checkbox for auto login

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        view = inflater.inflate(R.layout.fragment_settings, container, false);
        context = getActivity();
        rememberPassword = ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getBoolean("rememberPassword", false);
        rememberUsername = ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getBoolean("rememberUsername", false);
        autoLogin = ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).getBoolean("autoLogin", false);
        cbPassword = (CheckBox) view.findViewById(R.id.cbPassword);
        cbUsername = (CheckBox) view.findViewById(R.id.cbUsername);
        cbAutoLogin = (CheckBox) view.findViewById(R.id.cbAutomaticLogin);
        cbPassword.setOnCheckedChangeListener(this);
        cbUsername.setOnCheckedChangeListener(this);
        cbAutoLogin.setOnCheckedChangeListener(this);
        view.findViewById(R.id.btnSaveSettings).setOnClickListener(this);
        fillInMarkers();
        checkWhatToShow();
        return view;
    }

    /**
     * Check/uncheck checkboxes based on class booleans
     */
    public void fillInMarkers() {
        if (rememberPassword) {
            cbPassword.setChecked(true);
        } else {
            cbPassword.setChecked(false);
        }
        if (rememberUsername) {
            cbUsername.setChecked(true);
        } else {
            cbUsername.setChecked(false);
        }
        if (autoLogin) {
            cbAutoLogin.setChecked(true);
        } else {
            cbAutoLogin.setChecked(false);
        }
    }

    /**
     * Shows auto login option if remember password and remember username are both checked
     */
    public void checkWhatToShow() {
        if (rememberPassword && rememberUsername) {
            cbAutoLogin.setVisibility(View.VISIBLE);
        } else {
            cbAutoLogin.setVisibility(View.GONE);
            cbAutoLogin.setChecked(false);
            autoLogin = false;
        }
    }

    @Override
    public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
        switch (buttonView.getId()) {
            case R.id.cbUsername:
                rememberUsername = isChecked;
                checkWhatToShow();
                break;
            case R.id.cbPassword:
                rememberPassword = isChecked;
                checkWhatToShow();
                break;
            case R.id.cbAutomaticLogin:
                autoLogin = isChecked;
                break;
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnSaveSettings:
                ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).edit().putBoolean("rememberPassword", rememberPassword).commit();
                ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).edit().putBoolean("rememberUsername", rememberUsername).commit();
                ((MainActivity) context).getPreferences(Context.MODE_PRIVATE).edit().putBoolean("autoLogin", autoLogin).commit();
                ((MainActivity) context).setMenubarFragment();
        }
    }
}

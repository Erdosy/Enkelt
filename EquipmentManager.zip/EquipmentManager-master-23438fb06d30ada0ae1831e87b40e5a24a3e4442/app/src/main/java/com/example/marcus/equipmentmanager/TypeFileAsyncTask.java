package com.example.marcus.equipmentmanager;

import android.content.Context;
import android.os.AsyncTask;
import android.widget.Toast;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.lang.reflect.Type;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;

/**
 * Downloads and transforms type file to json string in separate thread from main.
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class TypeFileAsyncTask extends AsyncTask<Void, Void, String> {


    private Context context; // context from calling activity (MainActivity)
    String queryType; // query type to be passed to showResult in MainActivity

    public TypeFileAsyncTask(Context context){
        this.context = context;
    }

    @Override
    protected String doInBackground(Void... params) {
        ArrayList<String> types = new ArrayList<>();
        queryType = "getTypeFile";
        try {

            URL url = new URL("http://kark.hin.no:8088/d3330log_backend/utstyrstyper.txt");


            BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
            String line;

            while ((line = in.readLine()) != null) {
                types.add(line);
            }
            in.close();
            Gson gson = new Gson();
            Type fileType = new TypeToken<ArrayList<String>>(){}.getType();
            return gson.toJson(types, fileType);

        } catch (MalformedURLException e) {
            Toast.makeText(context, context.getString(R.string.there_was_error), Toast.LENGTH_LONG).show();
        } catch (IOException e) {
            Toast.makeText(context, context.getString(R.string.there_was_error), Toast.LENGTH_SHORT).show();
        }
        return null;
    }

    @Override
    protected void onPostExecute(String result){
        ((MainActivity)context).showResult(result, queryType);
    }
}

package com.example.marcus.equipmentmanager;

import android.app.Fragment;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.TextView;

/**
 * Handles User Profile Fragment
 */
public class UserProfileFragment extends Fragment implements View.OnClickListener {

    View view; // current view
    User user; // current logged in user
    User notSelf; // current selected user
    ViewGroup container; // container for the view
    LayoutInflater inflater; // inflater to inflate views
    QueryHandler queryHandler; // handles queries from application
    ViewGroup parent; // parent view group used to add/remove views

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        this.inflater = inflater;
        this.container = container;
        this.queryHandler = ((MainActivity)getActivity()).getQueryHandler();
        view = inflater.inflate(R.layout.fragment_profile, container, false);
        if ((notSelf = ((MainActivity)getActivity()).getSelectedUser()) != null) {
            user = ((MainActivity) getActivity()).getSelectedUser();
            ((MainActivity)getActivity()).setSelectedUser(null);
        }
        else{
            user = ((MainActivity) getActivity()).getUser();
        }
        ((TextView)view.findViewById(R.id.tvUserName)).setText(getString(R.string.tvUserName) + " " + user.getUserName());
        ((TextView)view.findViewById(R.id.tvFullName)).setText(getString(R.string.tvFullName) + " " + user.getFirstname()+ " " + user.getLastname());
        ((TextView)view.findViewById(R.id.tvPhoneNumber)).setText(getString(R.string.tvPhoneNumber) + " " + user.getPhone());
        (view.findViewById(R.id.btnEditProfile)).setOnClickListener(this);
        (view.findViewById(R.id.btnEditPassword)).setOnClickListener(this);
        return view;
    }

    /**
     * Changes current view
     * @param choice    sets which view to change to
     */

    public void changeView(String choice){
        switch(choice){
            case "profile":
                parent = (ViewGroup)this.getView();
                assert parent != null;
                parent.removeAllViews();
                view = inflater.inflate(R.layout.edit_profile, container, false);
                parent.addView(view);
                ((EditText)view.findViewById(R.id.etUserName)).setText(user.getUserName());
                ((EditText)view.findViewById(R.id.etFirstName)).setText(user.getFirstname());
                ((EditText)view.findViewById(R.id.etLastName)).setText(user.getLastname());
                ((EditText)view.findViewById(R.id.etPhoneNumber)).setText(user.getPhone());
                (view.findViewById(R.id.btnSaveProfile)).setOnClickListener(this);
                (view.findViewById(R.id.btnGoBack)).setOnClickListener(this);
                break;
            case "password":
                parent = (ViewGroup)this.getView();
                assert parent != null;
                parent.removeAllViews();
                view = inflater.inflate(R.layout.edit_password, container, false);
                parent.addView(view);
                (view.findViewById(R.id.btnSavePassword)).setOnClickListener(this);
                (view.findViewById(R.id.btnGoBack)).setOnClickListener(this);
                break;
            case "back":
                parent.removeAllViews();
                view = inflater.inflate(R.layout.fragment_profile, container, false);
                parent.addView(view);
                ((TextView)view.findViewById(R.id.tvUserName)).setText(getString(R.string.tvUserName) + " " + user.getUserName());
                ((TextView)view.findViewById(R.id.tvFullName)).setText(getString(R.string.tvFullName) + " " + user.getFirstname()+ " " + user.getLastname());
                ((TextView)view.findViewById(R.id.tvPhoneNumber)).setText(getString(R.string.tvPhoneNumber) + " " + user.getPhone());
                (view.findViewById(R.id.btnEditProfile)).setOnClickListener(this);
                (view.findViewById(R.id.btnEditPassword)).setOnClickListener(this);
        }

    }

    @Override
    public void onClick(View v) {
        switch(v.getId()){
            case R.id.btnEditProfile:
                changeView("profile");
                break;
            case R.id.btnSaveProfile:
                user.setUserName(((EditText)view.findViewById(R.id.etUserName)).getText().toString());
                user.setFirstname(((EditText)view.findViewById(R.id.etFirstName)).getText().toString());
                user.setLastname(((EditText)view.findViewById(R.id.etLastName)).getText().toString());
                user.setPhone(((EditText)view.findViewById(R.id.etPhoneNumber)).getText().toString());
                queryHandler.updateUser(user);
                break;
            case R.id.btnSavePassword:
                String newPass = ((EditText)view.findViewById(R.id.etNewPassword)).getText().toString();
                String repeat = ((EditText)view.findViewById(R.id.etRepeatNewPassword)).getText().toString();
                if (newPass.equals(repeat) ){
                    queryHandler.changeUserPassword(user.getU_id(), newPass);
                }
                break;
            case R.id.btnEditPassword:
                changeView("password");

                break;
            case R.id.btnGoBack:
                changeView("back");
        }
    }
}

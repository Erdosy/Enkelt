package com.example.marcus.equipmentmanager;

import android.graphics.Bitmap;
import android.telephony.SmsManager;

import java.io.ByteArrayOutputStream;

/**
 * Utility class containing static helper methods
 * @author Kjell Anderssen & Marcus Andersson
 * @version 1.0
 */
public class Utility {

    /**
     * Returns string with first character capitalized.
     * @param string    The input string.
     * @return  String with first character capitalized.
     */
    static String capitalizeFirstLetter(String string) {
        return Character.toUpperCase(string.charAt(0)) + string.substring(1);
    }

    /**
     * Sends an SMS to speciefied phone number, with specified text
     * @param phoneNumber   destionation phone number
     * @param text  messagetext to send
     */
    static void sendSMS(String phoneNumber, String text) {
        SmsManager smsManager = SmsManager.getDefault();
        smsManager.sendTextMessage(phoneNumber, "EquipmentManager Team", text, null, null);
    }

    /**
     * Converts Bitmap to byte array.
     * @param bitmap    The bitmap to be converted
     * @return  the byte array representation of bitmap
     */
    static byte[] bitmapToByteArray(Bitmap bitmap) {
        ByteArrayOutputStream byteArrayOutputStream = new ByteArrayOutputStream(bitmap.getWidth() * bitmap.getHeight());
        bitmap.compress(Bitmap.CompressFormat.PNG, 100, byteArrayOutputStream);
        return byteArrayOutputStream.toByteArray();
    }
}

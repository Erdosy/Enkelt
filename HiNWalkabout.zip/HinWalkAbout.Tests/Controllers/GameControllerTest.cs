﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using HinWalkAbout.Controllers;
using System.Web.Mvc;
using HinWalkAbout.DAL;
using Moq;

namespace HinWalkAbout.Tests.Controllers
{
    [TestClass]
    public class GameControllerTest
    {
        [TestMethod]
        public void Index()
        {
            // Arrange
            GameController controller = new GameController();

            // Act
            ViewResult result = controller.Index() as ViewResult;

            // Assert
            Assert.IsNotNull(result);
        }

        [TestMethod]
        public void EmptyConstructor() {
            //Act
            var result = new GameController();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(GameController));
        }

        [TestMethod]
        public void ConstructorWithRepository() {
            //Arrange
            var repo = new Mock<IRepository>();

            //Act
            var result = new GameController(repo.Object);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(GameController));
        }
    }

}

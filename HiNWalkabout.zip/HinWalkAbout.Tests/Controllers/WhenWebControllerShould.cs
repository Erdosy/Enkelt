﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using HinWalkAbout.Controllers;
using HinWalkAbout.DAL;
using System.Web.Http;
using System.Web.Http.Results;
using System.Collections.Generic;
using HinWalkAbout.Models;
using System.Security.Claims;
using System.Security.Principal;
using System.Linq;

namespace HinWalkAbout.Tests.Controllers
{
    [TestClass]
    public class WhenWebControllerShould
    {
        MemoryRepository MemoryRepository;

        [TestInitialize]
        public void Initialize() {
            MemoryRepository = new MemoryRepository();
        }

        [TestMethod]
        public void EmptyConstructor() {
            //Act
            var result = new WebController();

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(WebController));
        }

        [TestMethod]
        public void ConstructorWithRepository() {
            //Arrange
            var repo = new Mock<IRepository>();

            //Act
            var result = new WebController(repo.Object);

            //Assert
            Assert.IsNotNull(result);
            Assert.IsInstanceOfType(result, typeof(WebController));
        }

        [TestMethod]
        public void GetFurnitures() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResult = controller.GetFurnitures();
            var contentResult = actionResult as OkNegotiatedContentResult<IQueryable<FurnitureViewModel>>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.Count(), MemoryRepository.FakeFurnitures.Where(item => item.locationTypeId == fakeUser.userLocation).ToList().Count);

        }

        [TestMethod]
        public void GetFurnituresDefaultPosition() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[1];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResult = controller.GetFurnitures();
            var contentResult = actionResult as OkNegotiatedContentResult<IQueryable<FurnitureViewModel>>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.Count(), MemoryRepository.FakeFurnitures.Where(furniture => furniture.locationTypeId == 1).ToList().Count);

        }

        [TestMethod]
        public void GetItems() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));
            
            // Act
            IHttpActionResult actionResult = controller.GetItems();
            var contentResult = actionResult as OkNegotiatedContentResult<IQueryable<ItemsViewModel>>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.Count(), MemoryRepository.FakeItems.Where(item => item.locationTypeId == fakeUser.userLocation).ToList().Count );
        }

        [TestMethod]
        public void GetItemsDefaultPosition() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[1];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResult = controller.GetItems();
            var contentResult = actionResult as OkNegotiatedContentResult<IQueryable<ItemsViewModel>>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.Count(), MemoryRepository.FakeItems.Where(item => item.locationTypeId == 1).ToList().Count);
        }


        [TestMethod]
        public void GetStartPosition() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResult = controller.GetStartPosition();
            var contentResult = actionResult as OkNegotiatedContentResult<MovementViewModel>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.userLocation, fakeUser.userLocation);
        }

        [TestMethod]
        public void GetStartPositionDoesNotExist() {
            //Arrange
            MemoryRepository = new MemoryRepository();
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[1];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResult = controller.GetStartPosition();
            var contentResult = actionResult as OkNegotiatedContentResult<MovementViewModel>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(1, contentResult.Content.userLocation);
        }


        [TestMethod]
        public void InteractWithItemWrite() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            Item fakeItem = MemoryRepository.FakeItems[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            CommandInputModel commandInput = new CommandInputModel();
            String testAction = "skriv:";
            String testData = "dette er en test";
            String testCommand = testAction + testData;
            commandInput.command = testCommand;
            commandInput.itemid = Convert.ToString(fakeItem.id);

            // Act
            IHttpActionResult actionResult = controller.InteractWithItem(commandInput);
            var contentResult = actionResult as OkNegotiatedContentResult<ItemsViewModel>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.data, fakeUser.UserName + ": " + testData + "<br/>");
        }

        [TestMethod]
        public void InteractWithItemErase() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            Item fakeItem = MemoryRepository.FakeItems[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            CommandInputModel commandInput = new CommandInputModel();
            String testAction = "visk ut";
            String testData = "";
            String testCommand = testAction + testData;
            commandInput.command = testCommand;
            commandInput.itemid = Convert.ToString(fakeItem.id);

            // Act
            IHttpActionResult actionResult = controller.InteractWithItem(commandInput);
            var contentResult = actionResult as OkNegotiatedContentResult<ItemsViewModel>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.data, "");
        }

        [TestMethod]
        public void InteractWithItemRead() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            Item fakeItem = MemoryRepository.FakeItems[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            CommandInputModel commandInput = new CommandInputModel();
            String testAction = "les";
            String testData = "";
            String testCommand = testAction + testData;
            commandInput.command = testCommand;
            commandInput.itemid = Convert.ToString(fakeItem.id);

            // Act
            IHttpActionResult actionResult = controller.InteractWithItem(commandInput);
            var contentResult = actionResult as OkNegotiatedContentResult<ItemsViewModel>;

            // Assert
            Assert.IsNotNull(contentResult);
            Assert.IsNotNull(contentResult.Content);
            Assert.AreEqual(contentResult.Content.data, fakeItem.data);
        }

        [TestMethod]
        public void InteractWithItemInvalid() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            Item fakeItem = MemoryRepository.FakeItems[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            CommandInputModel commandInput = new CommandInputModel();
            String testAction = "invalid";
            String testData = "";
            String testCommand = testAction + testData;
            commandInput.command = testCommand;
            commandInput.itemid = Convert.ToString(fakeItem.id);

            // Act
            IHttpActionResult actionResult = controller.InteractWithItem(commandInput);

            // Assert
            Assert.IsNotNull(actionResult);
            Assert.AreEqual(actionResult is BadRequestResult, true);
        }

        [TestMethod]
        public void MoveUser() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[0];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResultN = controller.MoveUser("N");
            var contentResultN = actionResultN as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultS = controller.MoveUser("S");
            var contentResultS = actionResultS as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultE = controller.MoveUser("E");
            var contentResultE = actionResultE as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultW = controller.MoveUser("W");
            var contentResultW = actionResultW as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultU = controller.MoveUser("U");
            var contentResultU = actionResultU as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultD = controller.MoveUser("D");
            var contentResultD = actionResultD as OkNegotiatedContentResult<MovementViewModel>;

            // Assert
            Assert.IsNotNull(contentResultN);
            Assert.IsNotNull(contentResultN.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassNorth, false);

            Assert.IsNotNull(contentResultS);
            Assert.IsNotNull(contentResultS.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassSouth, false);

            Assert.IsNotNull(contentResultW);
            Assert.IsNotNull(contentResultW.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassWest, false);

            Assert.IsNotNull(contentResultE);
            Assert.IsNotNull(contentResultE.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassEast, true);

            Assert.IsNotNull(contentResultU);
            Assert.IsNotNull(contentResultU.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassUp, false);

            Assert.IsNotNull(contentResultD);
            Assert.IsNotNull(contentResultD.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassDown, false);
        }

        [TestMethod]
        public void MoveUserDefaultLocation() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[1];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResultN = controller.MoveUser("N");
            var contentResultN = actionResultN as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultS = controller.MoveUser("S");
            var contentResultS = actionResultS as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultE = controller.MoveUser("E");
            var contentResultE = actionResultE as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultW = controller.MoveUser("W");
            var contentResultW = actionResultW as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultU = controller.MoveUser("U");
            var contentResultU = actionResultU as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultD = controller.MoveUser("D");
            var contentResultD = actionResultD as OkNegotiatedContentResult<MovementViewModel>;

            // Assert
            Assert.IsNotNull(contentResultN);
            Assert.IsNotNull(contentResultN.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassNorth, false);

            Assert.IsNotNull(contentResultS);
            Assert.IsNotNull(contentResultS.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassSouth, false);

            Assert.IsNotNull(contentResultW);
            Assert.IsNotNull(contentResultW.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassWest, false);

            Assert.IsNotNull(contentResultE);
            Assert.IsNotNull(contentResultE.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassEast, true);

            Assert.IsNotNull(contentResultU);
            Assert.IsNotNull(contentResultU.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassUp, false);

            Assert.IsNotNull(contentResultD);
            Assert.IsNotNull(contentResultD.Content);
            Assert.AreEqual(contentResultN.Content.GameCompassDown, false);
        }


        [TestMethod]
        public void MoveUserTestAllConnections() {
            //Arrange
            ApplicationUser fakeUser = MemoryRepository.FakeUsers[2];
            var controller = new WebController(MemoryRepository.Repository.Object);
            controller.User = new ClaimsPrincipal(new GenericPrincipal(new GenericIdentity(fakeUser.UserName), null));

            // Act
            IHttpActionResult actionResultN = controller.MoveUser("N");
            var contentResultN = actionResultN as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultS = controller.MoveUser("S");
            var contentResultS = actionResultS as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultE = controller.MoveUser("E");
            var contentResultE = actionResultE as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultW = controller.MoveUser("W");
            var contentResultW = actionResultW as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultU = controller.MoveUser("U");
            var contentResultU = actionResultU as OkNegotiatedContentResult<MovementViewModel>;

            IHttpActionResult actionResultD = controller.MoveUser("D");
            var contentResultD = actionResultD as OkNegotiatedContentResult<MovementViewModel>;

            // Assert
            Assert.IsNotNull(contentResultN);
            Assert.IsNotNull(contentResultN.Content);
            Assert.AreEqual(false, contentResultN.Content.GameCompassNorth, "Move north");

            Assert.IsNotNull(contentResultS);
            Assert.IsNotNull(contentResultS.Content);
            Assert.AreEqual(true, contentResultS.Content.GameCompassSouth, "Move south");

            Assert.IsNotNull(contentResultW);
            Assert.IsNotNull(contentResultW.Content);
            Assert.AreEqual(false, contentResultW.Content.GameCompassWest, "Move west");

            Assert.IsNotNull(contentResultE);
            Assert.IsNotNull(contentResultE.Content);
            Assert.AreEqual(false, contentResultE.Content.GameCompassEast, "Move east");

            Assert.IsNotNull(contentResultU);
            Assert.IsNotNull(contentResultU.Content);
            Assert.AreEqual(false, contentResultU.Content.GameCompassUp, "Move up");

            Assert.IsNotNull(contentResultD);
            Assert.IsNotNull(contentResultD.Content);
            Assert.AreEqual(false, contentResultD.Content.GameCompassDown, "Move down");
        }
    }
}

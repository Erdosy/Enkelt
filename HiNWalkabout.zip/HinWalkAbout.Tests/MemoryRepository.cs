﻿
using HinWalkAbout.DAL;
using HinWalkAbout.Models;
using Moq;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace HinWalkAbout.Tests {
    class MemoryRepository {
        public Mock<IRepository> Repository = new Mock<IRepository>();

        public List<ApplicationUser> FakeUsers = new List<ApplicationUser> {
                new ApplicationUser { Id = "testuser01@test.com", UserName = "testuser01@test.com", userLocation = 1 },
                new ApplicationUser { Id = "testuser02@test.com", UserName = "testuser02@test.com", userLocation = 0 },
                new ApplicationUser { Id = "testuser03@test.com", UserName = "testuser03@test.com", userLocation = 101 }
            };

        public List<Connection> FakeConnections = new List<Connection> {
                new Connection {roomAId = 1, roomBId = 2, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 86, lrPosY = 193, ulPosX = 84, ulPosY = 189, visiblilty = true }, // gymsal <-> kantine
				new Connection {roomAId = 2, roomBId = 3, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 113, lrPosY = 117, ulPosX = 109, ulPosY = 115, visiblilty = true }, // kantine <-> trappehall
				new Connection {roomAId = 3, roomBId = 4, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 118, lrPosY = 74, ulPosX = 95, ulPosY = 72, visiblilty = false }, // trappehall <-> glassg1
                new Connection {roomAId = 101, roomBId = 102, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S" },
                new Connection {roomAId = 101, roomBId = 103, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "S", directionBA = "S" },
                new Connection {roomAId = 101, roomBId = 104, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "W", directionBA = "S" },
                new Connection {roomAId = 101, roomBId = 105, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "S" },
                new Connection {roomAId = 101, roomBId = 106, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "U", directionBA = "S" },
                new Connection {roomAId = 101, roomBId = 107, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "D", directionBA = "S" }
            };

        public List<Room> FakeRooms = new List<Room> {
                new Room {id = 1, roomNr = "E1800", name = "Gymsal", etg = 1, descShort = "Helsefabrikk", descLong = "Studenter bruker dette rommet for å komme i form, tror de ihvertfall.", lrPosX = 85, lrPosY = 197, ulPosX = 39, ulPosY = 167 },
                new Room {id = 2, roomNr = "E1750", name = "Kantine", etg = 1, descShort = "Foringstasjon", descLong = "Her spiser alle som er noe.", lrPosX = 118, lrPosY = 198, ulPosX = 85, ulPosY = 116 },
                new Room {id = 3, roomNr = "E1300", name = "Trappehall", etg = 1, descShort = "Veien til mat", descLong = "En hall alle sultne studenter går gjennom på vei til kantinen.", lrPosX = 118, lrPosY = 116, ulPosX = 85, ulPosY = 74 },
                new Room {id = 4, roomNr = "F1000-1", name = "Glassg1", etg = 1, descShort = "Hovedveien", descLong = "Glassgata er HINs versjon av E6, her er det liv hele dagen.", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 101, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 102, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 103, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 104, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 105, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 106, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 107, roomNr = "Fake", name = "Fake", etg = 1, descShort = "", descLong = "", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 }
            };

        public List<Furniture> FakeFurnitures = new List<Furniture> {
                new Furniture { id = 1, shortDesc = "Sofa",  longDesc = "En god og behagelig sofa", locationType = "Room", locationTypeId = 1 },
                new Furniture { id = 2, shortDesc = "Stol",  longDesc = "Pinnestol som raserer ryggraden", locationType = "Room", locationTypeId = 1 },
                new Furniture { id = 3, shortDesc = "Stol",  longDesc = "Rolls-Royce fra stol-industrien", locationType = "Room", locationTypeId = 3 }
            };

        public List<Item> FakeItems = new List<Item> {
                new Item { id = 1, shortDesc = "Bok",  longDesc = "En bok om c# utvikling", locationType = "Room", locationTypeId = 1, data = "" },
                new Item { id = 2, shortDesc = "Bok",  longDesc = "En bok om systemdrift", locationType = "Room", locationTypeId = 1, data = "" },
                new Item { id = 3, shortDesc = "Bok",  longDesc = "En bok om Microsoft", locationType = "Room", locationTypeId = 1, data = "" },
                new Item { id = 4, shortDesc = "Bok",  longDesc = "En bok om Windows server", locationType = "Room", locationTypeId = 2, data = "" },
                new Item { id = 5, shortDesc = "Bok",  longDesc = "En bok om IIS", locationType = "Room", locationTypeId = 3, data = "" },
                new Item { id = 6, shortDesc = "Bok",  longDesc = "En bok om Azure", locationType = "Room", locationTypeId = 3, data = "" },
                new Item { id = 7, shortDesc = "Bok",  longDesc = "En bok om Hyper-V", locationType = "Room", locationTypeId = 3, data = "" },
                new Item { id = 8, shortDesc = "Bok",  longDesc = "En bok om sertifiseringer", locationType = "Room", locationTypeId = 3, data = "" },
            };

        public MemoryRepository() {

            /// Users
            Repository.Setup(x => x.getAllUsers()).Returns(FakeUsers);
            Repository.Setup(
                x => x.getUserByName(
                    It.IsAny<string>()
                )
            ).Returns<string>(
                (string s) => FakeUsers.AsQueryable().Where(user => user.UserName.Equals(s)).SingleOrDefault()
            );

            /// Rooms
            Repository.Setup(
                x => x.getRoom(
                    It.Is<int>(i => i is int)
                )
            ).Returns<int>(
                (int i) => FakeRooms.AsQueryable().Where(r => r.id == i).SingleOrDefault()
            );


            /// Connections
            Repository.Setup(
                x => x.getRoomConnections(
                    It.Is<int>(i => i is int)
                )
            ).Returns<int>(
                (int roomId) => FakeConnections.AsQueryable().Where(r => r.roomAId.Equals(roomId) || r.roomBId.Equals(roomId)).ToList()
            );


            /// Furnitures
            Repository.Setup(
                x => x.findFurniture(
                    It.Is<string>(p => p is string),
                    It.Is<int>(i => i is int)
                )
            ).Returns<string, int>(
                (string s, int i) => FakeFurnitures.AsQueryable().Where(f => f.locationTypeId == i)
            );


            /// Items
            Repository.Setup(
                x => x.findItem(
                    It.Is<string>(p => p is string),
                    It.Is<int>(i => i is int)
                )
            ).Returns<string, int>(
                (string s, int i) => FakeItems.AsQueryable().Where(f => f.locationTypeId == i)
            );

            Repository.Setup(
                x => x.getItemById(
                    It.Is<int>(i => i is int)
                )
            ).Returns<int>(
                (int i) => FakeItems.AsQueryable().Where(item => item.id == i).SingleOrDefault()
            );


            Repository.Setup(
                x => x.updateItem(
                    It.Is<Item>(i => i is Item)
                )
            ).Callback<Item>(
                (Item newItem) => FakeItems.Insert(FakeItems.IndexOf( FakeItems.Find(oldItem => oldItem.id == newItem.id) ), newItem)
            );
        }
    }
}

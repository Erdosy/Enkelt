﻿using HinWalkAbout.DAL;
using HinWalkAbout.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace HinWalkAbout.Controllers
{
    [Authorize]
    public class GameController : Controller
    {

        private ApplicationDbContext db = new ApplicationDbContext();
        private readonly IRepository Repository;

        public GameController()
        {
            DatabaseRepository DataBaseRepository = new DatabaseRepository();
            this.Repository = DataBaseRepository;
        }

        public GameController(IRepository Repository)
        {
            this.Repository = Repository;
        }

        // GET: Game
        public ActionResult Index()
        {
            MovementViewModel model = new MovementViewModel();
            return View(model);
        }
    }
}
﻿using HinWalkAbout.DAL;
using HinWalkAbout.Hubs;
using HinWalkAbout.Models;
using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Net.Http;
using System.Text.RegularExpressions;
using System.Web.Http;
using System.Web.Http.Description;
using System.Web.Routing;

namespace HinWalkAbout.Controllers {


    public class WebController : ApiController {

        private ApplicationDbContext db = new ApplicationDbContext();
        private readonly IRepository Repository;
        private readonly int defaultUserLocation = 1;


        /// <summary>
        /// Default constructor for controller that sets up the default database repository
        /// </summary>
        public WebController() {
            DatabaseRepository DataBaseRepository = new DatabaseRepository();
            this.Repository = DataBaseRepository;
        }

        /// <summary>
        /// Constructor for the controller that sets up database repository from parameter
        /// </summary>
        /// <param name="Repository">The database repository</param>
        public WebController(IRepository Repository) {
            this.Repository = Repository;
        }

        /// <summary>
        /// Derives the user location from User and fetches a list of furnitures in that location
        /// </summary>
        /// <returns>List of furnitures in User location</returns>
        [ResponseType(typeof(IEnumerable<FurnitureViewModel>))]
        public IHttpActionResult GetFurnitures() {
            ApplicationUser user = Repository.getUserByName(User.Identity.Name);
            int userLocation = user.userLocation == 0 ? defaultUserLocation : user.userLocation;
            IEnumerable<Furniture> itemList = Repository.findFurniture("Room", userLocation);

            List<FurnitureViewModel> resultList = new List<FurnitureViewModel>();
            foreach (Furniture item in itemList) {
                resultList.Add(
                    new FurnitureViewModel {
                        shortDesc = item.shortDesc,
                        longDesc = item.longDesc,
                        locationType = item.locationType
                    }
                );
            }

            return Ok(resultList.AsQueryable());
        }

        /// <summary>
        /// Derives the user location from User and fetches a list of items in that location
        /// </summary>
        /// <returns>List of items in the User location</returns>
        [ResponseType(typeof(IEnumerable<ItemsViewModel>))]
        public IHttpActionResult GetItems() {
            ApplicationUser user = Repository.getUserByName(User.Identity.Name);
            int userLocation = user.userLocation == 0 ? defaultUserLocation : user.userLocation;
            IEnumerable<Item> itemList = Repository.findItem("Room", userLocation);

            List<ItemsViewModel> resultList = new List<ItemsViewModel>();
            foreach (Item item in itemList) {
                resultList.Add(
                    new ItemsViewModel {
                        id = item.id,
                        shortDesc = item.shortDesc,
                        longDesc = item.longDesc,
                        locationType = item.locationType,
                        data = item.data
                    }
                );
            }
            return Ok(resultList.AsQueryable());
        }

        /// <summary>
        /// Interacts with the speciefied item in a predefined way
        /// </summary>
        /// <param name="commandInputModel">Contains the items id and the command to be enacted upon the item</param>
        /// <returns>The item that has been interacted with</returns>
        [ResponseType(typeof(ItemsViewModel))]
        [HttpPost]
        public IHttpActionResult InteractWithItem(CommandInputModel commandInputModel) {
            Item item = Repository.getItemById(Convert.ToInt32(commandInputModel.itemid));

            String command = commandInputModel.command;
            Regex.Replace(command, @"<[^>]*>", String.Empty);

            String action = command.IndexOf(":") > 0 ?  command.ToLower().Substring(0, command.IndexOf(":")+1) : command;
            String value = command.IndexOf(":") > 0 ?command.Substring(command.IndexOf(":") + 1, command.Length - (command.IndexOf(":") + 1)) : "";
            switch (action) {
                case "skriv:":
                    value = User.Identity.Name + ": " + value.Trim() + "<br/>";
                    item.data = item.data + value;
                    Repository.updateItem(item);
                    break;
                case "les":
                    
                    break;
                case "visk ut":
                    item.data = "";
                    Repository.updateItem(item);
                    break;
                default:
                    return BadRequest();
            }

            ItemsViewModel result = new ItemsViewModel {
                id = item.id,
                shortDesc = item.shortDesc,
                longDesc = item.longDesc,
                locationType = item.locationType,
                data = item.data
            };

            return Ok(result);
        }

        /// <summary>
        /// Moves the user in the specified direction, if a move in that direction is possible.
        /// Alerts users in the exited and entered room of the movement.
        /// </summary>
        /// <param name="Id">The specified direction</param>
        /// <returns>ViewModel with necessary information to update game client</returns>
        [ResponseType(typeof(MovementViewModel))]
        public IHttpActionResult MoveUser(string Id) {
            string userDirection = Id;
            ApplicationUser user = Repository.getUserByName(User.Identity.Name);
            int userLocation = user.userLocation == 0 ? defaultUserLocation : user.userLocation;
            int oldUserLocation = userLocation;

            Direction currentDirection = Common.getDirection(userLocation, this.Repository);

            switch (userDirection.ToUpper()) {
                case "N":
                    if (currentDirection.DirectionNorth != null) {
                        userLocation = currentDirection.DirectionNorth.id;
                    }
                    break;

                case "S":
                    if (currentDirection.DirectionSouth != null) {
                        userLocation = currentDirection.DirectionSouth.id;
                    }
                    break;

                case "W":
                    if (currentDirection.DirectionWest != null) {
                        userLocation = currentDirection.DirectionWest.id;
                    }
                    break;

                case "E":
                    if (currentDirection.DirectionEast != null) {
                        userLocation = currentDirection.DirectionEast.id;
                    }
                    break;
                case "U":
                    if (currentDirection.DirectionUp != null) {
                        userLocation = currentDirection.DirectionUp.id;
                    }
                    break;
                case "D":
                    if (currentDirection.DirectionDown != null) {
                        userLocation = currentDirection.DirectionDown.id;
                    }
                    break;
            }

            Repository.updateUserLocation(user, userLocation);
            Direction newDirection = Common.getDirection(userLocation, this.Repository);
            Room room = Repository.getRoom(userLocation);

            Common.broadcastMove(Repository, oldUserLocation, userLocation);

            return Ok(Common.fillModel(User.Identity.Name, userLocation, newDirection, room, this.Repository));
        }

        /// <summary>
        /// Checks if the user has a position, puts user in default start location if not.
        /// </summary>
        /// <returns>ViewModel with necessary information to update game client</returns>
        [ResponseType(typeof(MovementViewModel))]
        public IHttpActionResult GetStartPosition() {
            ApplicationUser user = Repository.getUserByName(User.Identity.Name);

            int userLocation = user.userLocation == 0 ? defaultUserLocation : user.userLocation;


            Room room = Repository.getRoom(userLocation);


            Direction direction = Common.getDirection(userLocation, this.Repository);

            return Ok(Common.fillModel(User.Identity.Name, userLocation, direction, room, this.Repository));
        }


    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using HinWalkAbout.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;

namespace HinWalkAbout.DAL {
    // Implementation of generic repository http://www.codeguru.com/csharp/.net/net_asp/mvc/using-the-repository-pattern-with-asp.net-mvc-and-entity-framework.htm
    //public class DatabaseRepository<T> : IRepository<T> where T : class {
    public class DatabaseRepository : IRepository {

            private ApplicationDbContext db = new ApplicationDbContext();
        private UserManager<ApplicationUser> userManager;

        public DatabaseRepository()
        {
            InitUserManager();
        }

        public void InitUserManager()
        {
            this.userManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(db));
        }



        public IEnumerable<ApplicationUser> getAllUsers()
        {
            return db.Users;
        }

        public IEnumerable<ApplicationUser> getAllUsersInRoom(int roomId)
        {
            return db.Users.Where(u => u.userLocation == roomId).ToList();
        }


        public Room getRoom(int roomId)
        {
            return db.room.Where(r => r.id == roomId).SingleOrDefault();
        }



        public ApplicationUser getUserByName(string userName)
        {
            return db.Users.Where(u => u.UserName == userName).Single();
        }

        public IEnumerable<Connection> getRoomConnections(int roomId) {
            return db.connection.Where(r => r.roomAId.Equals(roomId) || r.roomBId.Equals(roomId)).ToList();
        }


        public void updateUserLocation(ApplicationUser user, int userLocation)
        {
            user.userLocation = userLocation;
            db.SaveChanges();
        }

        public byte[] getRoomImage(int roomId)
        {
            return db.image.Where(i => i.roomId == roomId).Single().image;
        }

        public IEnumerable<Item> findItem(string type, int typeId)
        {
            IEnumerable<Item> result = db.item.Where(i => i.locationType.Equals(type) && i.locationTypeId == typeId).ToList();
            return result;
        }

        public IEnumerable<Furniture> findFurniture(string type, int typeId) {
            IEnumerable<Furniture> result = db.furniture.Where(i => i.locationType.Equals(type) && i.locationTypeId == typeId).ToList();
            return result;
        }

        public IEnumerable<Room> getAllRooms() {
            return db.room.ToList();
        }

        public void updateUserOnline(ApplicationUser user) {
            user.lastOnline = DateTime.Now;
            db.SaveChanges();
        }

        public Item getItemById(int id) {
            return db.item.Where(i => i.id.Equals(id)).Single();
        }

        public Item updateItem(Item item) {
            db.SaveChanges();
            return item;
        }
    }
}
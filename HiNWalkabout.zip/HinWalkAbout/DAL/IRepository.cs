﻿using HinWalkAbout.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HinWalkAbout.DAL {
    //public interface IRepository<T> where T :class {
    public interface IRepository {

        // Room methods
        Room getRoom(int roomId);
        IEnumerable<Room> getAllRooms();
        byte[] getRoomImage(int roomId);
        IEnumerable<Connection> getRoomConnections(int roomId);




            // User methods
            ApplicationUser getUserByName(String userName);
        ///int getUserAccessType(int userId);
        ///User getAuthenticatedUser();
        IEnumerable<ApplicationUser> getAllUsers();
        IEnumerable<ApplicationUser> getAllUsersInRoom(int roomId);

        void updateUserLocation(ApplicationUser user, int userLocation);
        void updateUserOnline(ApplicationUser user);



        // Items methods
        IEnumerable<Item> findItem(string type, int typeId);
        ///bool pickUpItem(int userId, int itemId);
        ///bool dropItem(int userId, int itemId);
        Item getItemById(int id);
        Item updateItem(Item item);


        // Furniture methods
        IEnumerable<Furniture> findFurniture(string type, int typeId);
    }
}
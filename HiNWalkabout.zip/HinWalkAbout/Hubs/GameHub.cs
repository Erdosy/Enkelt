﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using Microsoft.AspNet.SignalR;
using HinWalkAbout.DAL;
using HinWalkAbout.Models;
using System.Text.RegularExpressions;

namespace HinWalkAbout.Hubs {
    public class GameHub : Hub {
        private IRepository repository;

        public GameHub() {
            this.repository = new DatabaseRepository();
        }

        public GameHub(DatabaseRepository repository) {
            this.repository = repository;
        }

        /// <summary>
        /// Sends chat message to other users in same room or globally across game.
        /// </summary>
        /// <param name="broadcast">Broadcast globally?</param>
        /// <param name="message">Message to be sent</param>
        public void sendMessage(bool broadcast, string message) {
            int roomId = repository.getUserByName(Context.User.Identity.Name).userLocation;
            string name = Context.User.Identity.Name;
            message = Regex.Replace(message, @"<[^>]*>", String.Empty);

            if (broadcast) {
                Clients.All.recieveChatMessage("(Alle) " + name, message);
            } else {
                IEnumerable<ApplicationUser> usersInRoom = repository.getAllUsersInRoom(roomId);

                foreach (ApplicationUser user in usersInRoom) {
                    ApplicationUser senderUser = repository.getUserByName(name);

 
                    if (senderUser.Id.Equals(user.Id)) {
                        Clients.User(user.Id).recieveChatMessage("(Rom) meg", message);
                    }
                    else {
                        Clients.User(user.Id).recieveChatMessage("(Rom) " + name, message);
                    }
                    Clients.User(user.Id).notifyOnline();
                }
            }
        }

        /// <summary>
        /// Updates users in room
        /// </summary>
        public void getUsersInRoom() {
            int roomId = repository.getUserByName(Context.User.Identity.Name).userLocation;
            string name = Context.User.Identity.Name;

            IEnumerable<ApplicationUser> usersInRoom = repository.getAllUsersInRoom(roomId);

            foreach (ApplicationUser user in usersInRoom) {
                ApplicationUser senderUser = repository.getUserByName(name);
                Clients.User(user.Id).updateUsersUnRoom(usersInRoom);
            }
        }

        /// <summary>
        /// Updates that user is online
        /// </summary>
        public void notifyOnline() {
            ApplicationUser user = repository.getUserByName(Context.User.Identity.Name);
            repository.updateUserOnline(user);
            System.Diagnostics.Debug.WriteLine(user.UserName + " is online");
        }

    }
}
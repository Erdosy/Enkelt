﻿using HinWalkAbout.Hubs;
using HinWalkAbout.Models;
using Microsoft.AspNet.SignalR;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading;
using System.Web;


namespace HinWalkAbout.DAL {
    [ExcludeFromCodeCoverage]
    public class BackgroundThreads {
        private static Thread moveInstance = null;
        private static Thread pingInstance = null;

        private static readonly double userTimeout = 2.0;

        private IRepository repository;


        public BackgroundThreads() {
            this.repository = new DatabaseRepository();
        }

        public BackgroundThreads(DatabaseRepository repository) {
            this.repository = repository;
        }

        /// <summary>
        /// Starts thread to move virtual users around
        /// </summary>
        public static void startSingletonThread() {
            if (moveInstance == null) {
                moveInstance = new Thread(new ThreadStart(new BackgroundThreads().moveVirtualUsers));
                moveInstance.Start();
            }

            if (pingInstance == null) {
                pingInstance = new Thread(new ThreadStart(new BackgroundThreads().pingUsers));
                pingInstance.Start();
            }
        }

        /// <summary>
        /// Thread to move autonomous users around.
        /// Users that timeouts on online status become autonomous users as well.
        /// </summary>
        private void moveVirtualUsers() {
            while (true) {
                this.repository = new DatabaseRepository();
                var context = GlobalHost.ConnectionManager.GetHubContext<GameHub>();

                List<Room> rooms = repository.getAllRooms().ToList();
                List<ApplicationUser> list = this.repository.getAllUsers().ToList();

                DateTime dateTime = DateTime.Now;


                List<ApplicationUser> onlineUsers = new List<ApplicationUser>();

                foreach (ApplicationUser user in list) {
                    var minutes = (dateTime - user.lastOnline).TotalMinutes;

                    System.Diagnostics.Debug.WriteLine(dateTime + " - moving autonomous user " + user.UserName + " last online " + minutes + " minutes ago.");

                    if (minutes > userTimeout) {
                        int oldUserLocation = user.userLocation;
                        int newUserLocation = Common.randomRoomPosition(rooms);
                        repository.updateUserLocation(user, newUserLocation);
                        Common.broadcastMove(repository, oldUserLocation, newUserLocation);
                    } else {
                        onlineUsers.Add(user);
                    }
                }

                context.Clients.All.updateOnlineUsers(onlineUsers);

                list.Clear();

                Thread.Sleep(5000);
            }
        }

        /// <summary>
        /// Pings users to check online
        /// </summary>
        private void pingUsers() {
            while (true) {
                System.Diagnostics.Debug.WriteLine(DateTime.Now + " - pinging all active clients");

                var context = GlobalHost.ConnectionManager.GetHubContext<GameHub>();
                context.Clients.All.ping();
                Thread.Sleep(5000);
            }
        }

    }
}
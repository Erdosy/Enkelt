﻿using HinWalkAbout.Hubs;
using HinWalkAbout.Models;
using Microsoft.AspNet.SignalR;
using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Web;

namespace HinWalkAbout.DAL {
    public class Common {

        /// <summary>
        /// Finds a random room (position)
        /// </summary>
        /// <param name="rooms">List of available rooms</param>
        /// <returns>Id of random room</returns>
        [ExcludeFromCodeCoverage]
        public static int randomRoomPosition(List<Room> rooms) {
            Random random = new Random();
            int randomRoomFromList = random.Next(0, rooms.Count);
            return rooms[randomRoomFromList].id;
        }

        /// <summary>
        /// Broadcasts move to users in exited and entered rooms
        /// </summary>
        /// <param name="Repository">The database repository</param>
        /// <param name="oldroom">Id of exited room</param>
        /// <param name="newroom">Id of entered room</param>
        [ExcludeFromCodeCoverage]
        public static void broadcastMove(IRepository Repository, int oldroom, int newroom) {
            System.Diagnostics.Debug.WriteLine(DateTime.Now + ": broadcasting move");

            var context = GlobalHost.ConnectionManager.GetHubContext<GameHub>();

            IEnumerable<ApplicationUser> usersInOldRoom = Repository.getAllUsersInRoom(oldroom);
            IEnumerable<ApplicationUser> usersInNewRoom = Repository.getAllUsersInRoom(newroom);

            foreach (ApplicationUser user in usersInOldRoom) {
                context.Clients.User(user.Id).updateRoomUsers(usersInOldRoom);
            }

            foreach (ApplicationUser user in usersInNewRoom) {
                context.Clients.User(user.Id).updateRoomUsers(usersInNewRoom);
            }
        }

        /// <summary>
        /// Gets list of available directions to move in from room.
        /// </summary>
        /// <param name="roomId">Id of room</param>
        /// <param name="repository">The database repository</param>
        /// <returns>Direction model containing available rooms in every direction</returns>
        [ExcludeFromCodeCoverage]
        public static Direction getDirection(int roomId, IRepository repository) {
            Room currentRoom = repository.getRoom(roomId);

            IEnumerable<Connection> list = repository.getRoomConnections(roomId);
            Direction direction = new Direction();
            foreach (Connection item in list) {
                int room = item.roomAId.Equals(roomId) ? item.roomBId : item.roomAId;
                String test = item.roomAId.Equals(roomId) ? item.directionAB : item.directionBA;

                Room roomTo = repository.getRoom(room);

                switch (test.ToUpper()) {
                    case "N":
                        if (currentRoom.etg.Equals(roomTo.etg))
                            direction.DirectionNorth = roomTo;
                        break;
                    case "S":
                        if (currentRoom.etg.Equals(roomTo.etg))
                            direction.DirectionSouth = roomTo;
                        break;
                    case "W":
                        if (currentRoom.etg.Equals(roomTo.etg))
                            direction.DirectionWest = roomTo;
                        break;
                    case "E":
                        if (currentRoom.etg.Equals(roomTo.etg))
                            direction.DirectionEast = roomTo;
                        break;
                    case "U":
                        direction.DirectionUp = roomTo;
                        break;
                    case "D":
                        direction.DirectionDown = roomTo;
                        break;
                    default:
                        break;
                }
            }

            return direction;
        }

        /// <summary>
        /// Fills the view model with all necessary information to update game client
        /// </summary>
        /// <param name="userName">Users name</param>
        /// <param name="userLocation">Users location</param>
        /// <param name="direction">Direction model containing available rooms in every direction</param>
        /// <param name="room">Current room</param>
        /// <param name="repository">The database repository</param>
        /// <returns>View model with all the necessary information to update game client</returns>
        [ExcludeFromCodeCoverage]
        public static MovementViewModel fillModel(string userName, int userLocation, Direction direction, Room room, IRepository repository) {
            MovementViewModel movementViewModel = new MovementViewModel();
            movementViewModel.Timestamp = DateTime.Now.ToString(@"MM\/dd\ HH:mm");
            movementViewModel.UserName = userName;
            movementViewModel.userLocation = userLocation;

            movementViewModel.GameCompassNorth = (direction.DirectionNorth != null) ? true : false;
            movementViewModel.roomNorthShortDesc = (direction.DirectionNorth != null) ? direction.DirectionNorth.descShort : "";
            movementViewModel.roomNorthLongDesc = (direction.DirectionNorth != null) ? direction.DirectionNorth.descLong : "";

            movementViewModel.GameCompassSouth = (direction.DirectionSouth != null) ? true : false;
            movementViewModel.roomSouthShortDesc = (direction.DirectionSouth != null) ? direction.DirectionSouth.descShort : "";
            movementViewModel.roomSouthLongDesc = (direction.DirectionSouth != null) ? direction.DirectionSouth.descLong : "";

            movementViewModel.GameCompassWest = (direction.DirectionWest != null) ? true : false;
            movementViewModel.roomWestShortDesc = (direction.DirectionWest != null) ? direction.DirectionWest.descShort : "";
            movementViewModel.roomWestLongDesc = (direction.DirectionWest != null) ? direction.DirectionWest.descLong : "";

            movementViewModel.GameCompassEast = (direction.DirectionEast != null) ? true : false;
            movementViewModel.roomEastShortDesc = (direction.DirectionEast != null) ? direction.DirectionEast.descShort : "";
            movementViewModel.roomEastLongDesc = (direction.DirectionEast != null) ? direction.DirectionEast.descLong : "";

            movementViewModel.GameCompassUp = (direction.DirectionUp != null) ? true : false;
            movementViewModel.roomUpShortDesc = (direction.DirectionUp != null) ? direction.DirectionUp.descShort : "";
            movementViewModel.roomUpLongDesc = (direction.DirectionUp != null) ? direction.DirectionUp.descLong : "";

            movementViewModel.GameCompassDown = (direction.DirectionDown != null) ? true : false;
            movementViewModel.roomDownShortDesc = (direction.DirectionDown != null) ? direction.DirectionDown.descShort : "";
            movementViewModel.roomDownLongDesc = (direction.DirectionDown != null) ? direction.DirectionDown.descLong : "";

            movementViewModel.roomId = room.id;
            movementViewModel.roomName = room.name;
            movementViewModel.roomNumber = room.roomNr;
            movementViewModel.roomFloor = room.etg;
            movementViewModel.roomLongDesc = room.descLong;
            movementViewModel.roomShortDesc = room.descShort;
            movementViewModel.roomImage = repository.getRoomImage(room.id);
            return movementViewModel;
        }
    }
}
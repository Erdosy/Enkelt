﻿using HinWalkAbout.DAL;
using HinWalkAbout.Models;
using Microsoft.AspNet.SignalR;
using System.Diagnostics.CodeAnalysis;

namespace HinWalkAbout.Infrastructure {
    [ExcludeFromCodeCoverage]
    public class GameUserIdProvider : IUserIdProvider {

        /// <summary>
        /// Gets users id
        /// </summary>
        /// <param name="request">Request</param>
        /// <returns>Users id</returns>
        public string GetUserId(IRequest request) {
            IRepository repository = new DatabaseRepository();
            ApplicationUser user = repository.getUserByName(request.User.Identity.Name);
            return user.Id;
        }
    }
}
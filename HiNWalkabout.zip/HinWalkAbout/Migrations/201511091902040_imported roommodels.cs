namespace HinWalkAbout.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class importedroommodels : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Boards",
                c => new
                    {
                        boardId = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.boardId);
            
            CreateTable(
                "dbo.Connections",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        type = c.String(nullable: false),
                        directionAB = c.String(nullable: false),
                        directionBA = c.String(nullable: false),
                        ulPosX = c.Double(nullable: false),
                        ulPosY = c.Double(nullable: false),
                        lrPosX = c.Double(nullable: false),
                        lrPosY = c.Double(nullable: false),
                        visiblilty = c.Boolean(nullable: false),
                        roomAId = c.Int(nullable: false),
                        roomBId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id)
                .ForeignKey("dbo.Rooms", t => t.roomAId, cascadeDelete: false)
                .ForeignKey("dbo.Rooms", t => t.roomBId, cascadeDelete: false)
                .Index(t => t.roomAId)
                .Index(t => t.roomBId);
            
            CreateTable(
                "dbo.Rooms",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        roomNr = c.String(nullable: false),
                        etg = c.Int(nullable: false),
                        name = c.String(nullable: false),
                        descShort = c.String(),
                        descLong = c.String(),
                        ulPosX = c.Double(nullable: false),
                        ulPosY = c.Double(nullable: false),
                        lrPosX = c.Double(nullable: false),
                        lrPosY = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Furnitures",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        shortDesc = c.String(nullable: false),
                        longDesc = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
            CreateTable(
                "dbo.Images",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        image = c.Binary(),
                        roomId = c.Int(nullable: false),
                    })
                .PrimaryKey(t => t.id)
                .ForeignKey("dbo.Rooms", t => t.roomId, cascadeDelete: true)
                .Index(t => t.roomId);
            
            CreateTable(
                "dbo.Items",
                c => new
                    {
                        id = c.Int(nullable: false, identity: true),
                        shortDesc = c.String(nullable: false),
                        longDesc = c.String(),
                    })
                .PrimaryKey(t => t.id);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Images", "roomId", "dbo.Rooms");
            DropForeignKey("dbo.Connections", "roomBId", "dbo.Rooms");
            DropForeignKey("dbo.Connections", "roomAId", "dbo.Rooms");
            DropIndex("dbo.Images", new[] { "roomId" });
            DropIndex("dbo.Connections", new[] { "roomBId" });
            DropIndex("dbo.Connections", new[] { "roomAId" });
            DropTable("dbo.Items");
            DropTable("dbo.Images");
            DropTable("dbo.Furnitures");
            DropTable("dbo.Rooms");
            DropTable("dbo.Connections");
            DropTable("dbo.Boards");
        }
    }
}

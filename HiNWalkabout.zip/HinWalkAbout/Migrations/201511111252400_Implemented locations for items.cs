namespace HinWalkAbout.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Implementedlocationsforitems : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Items", "locationType", c => c.String(nullable: false));
            AddColumn("dbo.Items", "locationTypeId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Items", "locationTypeId");
            DropColumn("dbo.Items", "locationType");
        }
    }
}

namespace HinWalkAbout.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Addedlocationtypetofurniture : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Furnitures", "locationType", c => c.String(nullable: false));
            AddColumn("dbo.Furnitures", "locationTypeId", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Furnitures", "locationTypeId");
            DropColumn("dbo.Furnitures", "locationType");
        }
    }
}

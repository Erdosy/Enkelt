namespace HinWalkAbout.Migrations
{
    using System;
    using System.Data.Entity;
    using System.Data.Entity.Migrations;
    using System.Linq;
    using Models;
    using System.Reflection;
    using System.IO;


    internal sealed class Configuration : DbMigrationsConfiguration<ApplicationDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(ApplicationDbContext context)
        {
            Room[] rooms1etg =
            {
                new Room {id = 1, roomNr = "E1800", name = "Gymsal", etg = 1, descShort = "Helsefabrikk", descLong = "Studenter bruker dette rommet for � komme i form, tror de ihvertfall.", lrPosX = 85, lrPosY = 197, ulPosX = 39, ulPosY = 167 },
                new Room {id = 2, roomNr = "E1750", name = "Kantine", etg = 1, descShort = "Foringstasjon", descLong = "Her spiser alle som er noe.", lrPosX = 118, lrPosY = 198, ulPosX = 85, ulPosY = 116 },
                new Room {id = 3, roomNr = "E1300", name = "Trappehall", etg = 1, descShort = "Veien til mat", descLong = "En hall alle sultne studenter g�r gjennom p� vei til kantinen.", lrPosX = 118, lrPosY = 116, ulPosX = 85, ulPosY = 74 },
                new Room {id = 4, roomNr = "F1000-1", name = "Glassg1", etg = 1, descShort = "Hovedveien", descLong = "Glassgata er HINs versjon av E6, her er det liv hele dagen.", lrPosX = 126, lrPosY = 74, ulPosX = 85, ulPosY = 50 },
                new Room {id = 5, roomNr = "F1000-2", name = "Glassg2", etg = 1, descShort = "Hovedveien", descLong = "Glassgata er HINs versjon av E6, her er det liv hele dagen.", lrPosX = 168, lrPosY = 74, ulPosX = 126, ulPosY = 50 },
                new Room {id = 6, roomNr = "F1000-3", name = "Glassg3", etg = 1, descShort = "Hovedveien", descLong = "Glassgata er HINs versjon av E6, her er det liv hele dagen.", lrPosX = 208, lrPosY = 74, ulPosX = 168, ulPosY = 50 },
                new Room {id = 7, roomNr = "X0000", name = "Kiosk", etg = 1, descShort = "Akademika", descLong = "Kiosken ogs� kjent som akademika er stedet for � kj�pe b�ker og kaffe. For de desperate selges ogs� div. drikke, godteri, snus ol. til blodpris aka bensinstasjon pris.", lrPosX = 157, lrPosY = 88, ulPosX = 126, ulPosY = 74 },
                new Room {id = 8, roomNr = "D1080", name = "Aud1", etg = 1, descShort = "Det Store Kunnskapsrom", descLong = "Auditorium 1 er det st�rste auditoriumet p� skolen, her har samtlige studenter l�rt noe, sovnet eller begge deler.", lrPosX = 168, lrPosY = 50, ulPosX = 126, ulPosY = 20 },
                new Room {id = 9, roomNr = "B1010", name = "HeisB1", etg = 1, descShort = "H�ydeforflyttningsmaskin", descLong = "Dette er de mindre sporty studentenes m�te � forflytte seg mellom etasjene, p� folkemunne kjent som en heis.", lrPosX = 192, lrPosY = 50, ulPosX = 184, ulPosY = 41 },

            };

            Room[] rooms2etg =
            {
                new Room {id = 10, roomNr = "F2000", name = "Inngangsparti", etg = 2, descShort = "Det f�rste du ser", descLong = "Inngangspartiet er storsl�tt, fantastisk og det f�rst du ser n�r du kommer inn hovedinngangen p� HIN.", lrPosX = 77, lrPosY = 85, ulPosX = 41, ulPosY = 71 },
                new Room {id = 11, roomNr = "E2011", name = "Resepsjon", etg = 2, descShort = "Sp�rre disk", descLong = "Still deg bak denne disken og still sp�rsm�l, her f�r du svar p� det meste.", lrPosX = 89, lrPosY = 103, ulPosX = 50, ulPosY = 85 },
                new Room {id = 12, roomNr = "E2310", name = "2etgKorridor1", etg = 2, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 108, lrPosY = 123, ulPosX = 115, ulPosY = 198 },
                new Room {id = 13, roomNr = "E2600", name = "Bibliotek", etg = 2, descShort = "Kunnskapslager", descLong = "Her finner du faglitteratur om det meste, brukes n�r internett ikke strekker til.", lrPosX = 115, lrPosY = 198, ulPosX = 103, ulPosY = 123 },
                new Room {id = 14, roomNr = "A2220", name = "R�dgiverkontor", etg = 2, descShort = "Hjelp og tr�st kondomeriet", descLong = "Her f�r du hjelp og tr�st i de fleste situasjoner, husk � ta med en kondom p� veien ut.", lrPosX = 126, lrPosY = 68, ulPosX = 115, ulPosY = 54 },
                new Room {id = 15, roomNr = "B2010", name = "HeisB2", etg = 2, descShort = "H�ydeforflyttningsmaskin", descLong = "Dette er de mindre sporty studentenes m�te � forflytte seg mellom etasjene, p� folkemunne kjent som en heis.", lrPosX = 187, lrPosY = 70, ulPosX = 179, ulPosY = 55 },
                new Room {id = 16, roomNr = "D2500-1", name = "2etgKorridor2", etg = 2, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 77, lrPosY = 71, ulPosX = 41, ulPosY = 71 },
                new Room {id = 17, roomNr = "D2500-2", name = "2etgKorridor3", etg = 2, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 126, lrPosY = 76, ulPosX = 77, ulPosY = 66 },
                new Room {id = 18, roomNr = "D2500-3", name = "2etgKorridor4", etg = 2, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 202, lrPosY = 76, ulPosX = 126, ulPosY = 70 },
            };

            Room[] rooms3etg =
            {
                new Room {id = 19, roomNr = "B3065", name = "Do", etg = 3, descShort = "Unntatt fra offentlighet", descLong = "Her utf�res aktiviteter som er unntatt fra offentligheten.", lrPosX = 181, lrPosY = 128, ulPosX = 168, ulPosY = 115 },
                new Room {id = 20, roomNr = "B3010", name = "HeisB3", etg = 3, descShort = "H�ydeforflyttningsmaskin", descLong = "Dette er de mindre sporty studentenes m�te � forflytte seg mellom etasjene, p� folkemunne kjent som en heis.", lrPosX = 195, lrPosY = 128, ulPosX = 186, ulPosY = 115 },
                new Room {id = 21, roomNr = "D3330", name = "Linuxlab", etg = 3, descShort = "Det store nerde-rommet", descLong = "Her sitter datastudentene � trykker dagen lang, se du etter en nerd er dette rommet et godt sted � begynne.", lrPosX = 278, lrPosY = 151, ulPosX = 240, ulPosY = 132 },
                new Room {id = 22, roomNr = "C3010", name = "HeisC3", etg = 3, descShort = "H�ydeforflyttningsmaskin", descLong = "Dette er de mindre sporty studentenes m�te � forflytte seg mellom etasjene, p� folkemunne kjent som en heis.", lrPosX = 293, lrPosY = 128, ulPosX = 284, ulPosY = 115 },
                new Room {id = 23, roomNr = "B3220-1", name = "3etgKorridor1", etg = 3, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 181, lrPosY = 132, ulPosX = 168, ulPosY = 128 },
                new Room {id = 24, roomNr = "B3220-2", name = "3etgKorridor2", etg = 3, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 212, lrPosY = 132, ulPosX = 181, ulPosY = 128 },
                new Room {id = 25, roomNr = "D3310", name = "3etgKorridor3", etg = 3, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 278, lrPosY = 132, ulPosX = 212, ulPosY = 128 },
                new Room {id = 26, roomNr = "C3020", name = "3etgKorridor4", etg = 3, descShort = "Sidevei", descLong = "En korridor brukes stil � forflytte seg rundt p� skolen.", lrPosX = 300, lrPosY = 132, ulPosX = 278, ulPosY = 128 },
            };

            Room[] rooms4etg =
            {
                new Room {id = 27, roomNr = "B4260", name = "DT2013Kontor", etg = 4, descShort = "Nerde-kontoret", descLong = "Her sitter tredje �ret datateknikk, muligens de st�rste nerdene p� skolen.", lrPosX = 200, lrPosY = 57, ulPosX = 178, ulPosY = 40 },
                new Room {id = 28, roomNr = "B4000", name = "L�rerKontorB", etg = 4, descShort = "Realt kjedelig", descLong = "Her sitter de realfags l�rerne.", lrPosX = 200, lrPosY = 135, ulPosX = 148, ulPosY = 57 },
                new Room {id = 29, roomNr = "B4010", name = "HeisB4", etg = 4, descShort = "H�ydeforflyttningsmaskin", descLong = "Dette er de mindre sporty studentenes m�te � forflytte seg mellom etasjene, p� folkemunne kjent som en heis.", lrPosX = 183, lrPosY = 155, ulPosX = 172, ulPosY = 135 },
                new Room {id = 30, roomNr = "C4000", name = "L�rerKontorC", etg = 4, descShort = "L�re data?", descLong = "Her sitter l�rerne i datateknikk.", lrPosX = 284, lrPosY = 137, ulPosX = 258, ulPosY = 77 },
                new Room {id = 31, roomNr = "C4010", name = "HeisC4", etg = 4, descShort = "H�ydeforflyttningsmaskin", descLong = "Dette er de mindre sporty studentenes m�te � forflytte seg mellom etasjene, p� folkemunne kjent som en heis.", lrPosX = 284, lrPosY = 157, ulPosX = 275, ulPosY = 137 },
            };

            Connection[] connections1etg =
                                    {
                new Connection {roomAId = 1, roomBId = 2, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 86, lrPosY = 193, ulPosX = 84, ulPosY = 189, visiblilty = true }, // gymsal <-> kantine
				new Connection {roomAId = 2, roomBId = 3, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 113, lrPosY = 117, ulPosX = 109, ulPosY = 115, visiblilty = true }, // kantine <-> trappehall
				new Connection {roomAId = 3, roomBId = 4, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 118, lrPosY = 74, ulPosX = 95, ulPosY = 72, visiblilty = false }, // trappehall <-> glassg1
				new Connection {roomAId = 4, roomBId = 10, type = "stair", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "U", directionBA = "D", lrPosX = 86, lrPosY = 70, ulPosX = 84, ulPosY = 51, visiblilty = true }, // glassg1 <-> (2etg) inngangsparti
				new Connection {roomAId = 4, roomBId = 5, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 127, lrPosY = 76, ulPosX = 125, ulPosY = 51, visiblilty = false }, // glassg1 <-> glassg2
				new Connection {roomAId = 5, roomBId = 8, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 151, lrPosY = 52, ulPosX = 145, ulPosY = 50, visiblilty = true }, // glassg2 <-> aud1
				new Connection {roomAId = 5, roomBId = 7, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "S", directionBA = "N", lrPosX = 148, lrPosY = 77, ulPosX = 137, ulPosY = 75, visiblilty = true }, // glassg2 <-> kiosk
				new Connection {roomAId = 5, roomBId = 6, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 169, lrPosY = 76, ulPosX = 167, ulPosY = 51, visiblilty = false }, // glassg2 <-> glassg3
				new Connection {roomAId = 6, roomBId = 9, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 192, lrPosY = 52, ulPosX = 184, ulPosY = 50, visiblilty = true },	// glassg3 <-> heisB1	
				new Connection {roomAId = 9, roomBId = 15, type = "elevator", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "U", directionBA = "D", visiblilty = false }	// heisB1 <-> heisB2				
            };

            Connection[] connections2etg =
            {
                new Connection {roomAId = 10, roomBId = 11, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "S", directionBA = "N", lrPosX = 78, lrPosY = 81, ulPosX = 52, ulPosY = 79, visiblilty = false }, // inngangsparti <-> resepsjon
				new Connection {roomAId = 11, roomBId = 12, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX =89, lrPosY = 98, ulPosX = 87, ulPosY = 85, visiblilty = false }, // resepsjon <-> k1
				new Connection {roomAId = 12, roomBId = 13, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "S", directionBA = "N", lrPosX = 108, lrPosY = 124, ulPosX = 104, ulPosY = 122, visiblilty = true }, // k1 <-> bibliotek
				new Connection {roomAId = 10, roomBId = 16, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 78, lrPosY = 67, ulPosX = 53, ulPosY = 65, visiblilty = false }, // inngangsparti <-> k2
				new Connection {roomAId = 16, roomBId = 17, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 79, lrPosY = 66, ulPosX = 77, ulPosY = 61, visiblilty = false }, // k2 <-> k3
				new Connection {roomAId = 17, roomBId = 14, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 116, lrPosY = 62, ulPosX = 108, ulPosY = 60, visiblilty = true }, // k3 <-> r�dgiverkontor
				new Connection {roomAId = 17, roomBId = 18, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 128, lrPosY = 70, ulPosX = 126, ulPosY = 65, visiblilty = false }, // k3 <-> k4
				new Connection {roomAId = 18, roomBId = 15, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 188, lrPosY = 66, ulPosX = 180, ulPosY = 64, visiblilty = true }, // k4 <-> heisB2
				new Connection {roomAId = 15, roomBId = 20, type = "elevator", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "U", directionBA = "D", visiblilty = false } // heisB2 <-> heisB3
			};

            Connection[] connections3etg =
            {
                new Connection {roomAId = 19, roomBId = 23, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "S", directionBA = "N", lrPosX = 180, lrPosY = 129, ulPosX = 176, ulPosY = 127, visiblilty = true }, // do <-> k1
				new Connection {roomAId = 23, roomBId = 24, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 182, lrPosY = 133, ulPosX = 180, ulPosY = 128, visiblilty = false }, // k1 <-> k2
				new Connection {roomAId = 24, roomBId = 20, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 195, lrPosY = 129, ulPosX = 186, ulPosY = 127, visiblilty = true }, // k2 <-> heisB3
				new Connection {roomAId = 24, roomBId = 25, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 213, lrPosY = 133, ulPosX = 211, ulPosY = 128, visiblilty = false }, // k2 <-> k3
				new Connection {roomAId = 25, roomBId = 21, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "S", directionBA = "N", lrPosX = 256, lrPosY = 134, ulPosX = 251, ulPosY = 132, visiblilty = true }, // k3 <-> linuxlab
				new Connection {roomAId = 25, roomBId = 26, type = "opening", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "E", directionBA = "W", lrPosX = 271, lrPosY = 133, ulPosX = 269, ulPosY = 128, visiblilty = false }, // k3 <-> k4
				new Connection {roomAId = 26, roomBId = 22, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 285, lrPosY = 129, ulPosX = 276, ulPosY = 127, visiblilty = true }, // k4 <-> heisC3
				new Connection {roomAId = 20, roomBId = 29, type = "elevator", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "U", directionBA = "D", visiblilty = false }, // heisB3 <-> heisB4
				new Connection {roomAId = 22, roomBId = 31, type = "elevator", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "U", directionBA = "D", visiblilty = false } // heisC3 <-> heisC4
            };

            Connection[] connections4etg =
            {
                new Connection {roomAId = 29, roomBId = 28, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 179, lrPosY = 136, ulPosX = 175, ulPosY = 134, visiblilty = true }, // heisB4 <-> l�rerkontorB
				new Connection {roomAId = 28, roomBId = 29, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 185, lrPosY = 58, ulPosX = 181, ulPosY = 56, visiblilty = true }, // l�rerkontor <-> b4260
				new Connection {roomAId = 31, roomBId = 30, type = "door", accessAB = new string[]{ "ALL" }, accessBA = new string[]{ "ALL" }, directionAB = "N", directionBA = "S", lrPosX = 283, lrPosY = 138, ulPosX = 271, ulPosY = 136, visiblilty = true } // heisC4 <-> l�rerkontorC
			};

            var absolutePath = new Uri(Assembly.GetExecutingAssembly().CodeBase).AbsolutePath;
            string directory = Path.GetDirectoryName(absolutePath);
            string directoryName = directory.Substring(0, directory.Length - 4);

            Image[] images1etg =
            {
                new Image { roomId = 1, image = File.ReadAllBytes(directoryName + "/Images/1Gymsal.jpg") },
                new Image { roomId = 2, image = File.ReadAllBytes(directoryName + "/Images/2Kantine.jpg") },
                new Image { roomId = 3, image = File.ReadAllBytes(directoryName + "/Images/3Trappehall.jpg") },
                new Image { roomId = 4, image = File.ReadAllBytes(directoryName + "/Images/Glassg.jpg") },
                new Image { roomId = 5, image = File.ReadAllBytes(directoryName + "/Images/Glassg.jpg") },
                new Image { roomId = 6, image = File.ReadAllBytes(directoryName + "/Images/Glassg.jpg") },
                new Image { roomId = 7, image = File.ReadAllBytes(directoryName + "/Images/7Kiosk.jpg") },
                new Image { roomId = 8, image = File.ReadAllBytes(directoryName + "/Images/8Aud1.jpg") },
                new Image { roomId = 9, image = File.ReadAllBytes(directoryName + "/Images/Heis.jpg") }
            };

            Image[] images2etg =
            {

                new Image { roomId = 10, image = File.ReadAllBytes(directoryName + "/Images/10Inngangsparti.jpg") },
                new Image { roomId = 11, image = File.ReadAllBytes(directoryName + "/Images/11Resepsjon.jpg") },
                new Image { roomId = 12, image = File.ReadAllBytes(directoryName + "/Images/2etgKorridor.jpg") },
                new Image { roomId = 13, image = File.ReadAllBytes(directoryName + "/Images/13Bibliotek.jpg") },
                new Image { roomId = 14, image = File.ReadAllBytes(directoryName + "/Images/14R�dgiverkontor.jpg") },
                new Image { roomId = 15, image = File.ReadAllBytes(directoryName + "/Images/Heis.jpg") },
                new Image { roomId = 16, image = File.ReadAllBytes(directoryName + "/Images/2etgKorridor.jpg") },
                new Image { roomId = 17, image = File.ReadAllBytes(directoryName + "/Images/2etgKorridor.jpg") },
                new Image { roomId = 18, image = File.ReadAllBytes(directoryName + "/Images/2etgKorridor.jpg") }
            };

            Image[] images3etg =
            {
                new Image { roomId = 19, image = File.ReadAllBytes(directoryName + "/Images/19Do.jpg") },
                new Image { roomId = 20, image = File.ReadAllBytes(directoryName + "/Images/Heis.jpg") },
                new Image { roomId = 21, image = File.ReadAllBytes(directoryName + "/Images/21Linuxlab.jpg") },
                new Image { roomId = 22, image = File.ReadAllBytes(directoryName + "/Images/Heis.jpg") },
                new Image { roomId = 23, image = File.ReadAllBytes(directoryName + "/Images/3etgKorridor.jpg") },
                new Image { roomId = 24, image = File.ReadAllBytes(directoryName + "/Images/3etgKorridor.jpg") },
                new Image { roomId = 25, image = File.ReadAllBytes(directoryName + "/Images/3etgKorridor.jpg") },
                new Image { roomId = 26, image = File.ReadAllBytes(directoryName + "/Images/3etgKorridor.jpg") }

            };

            Image[] images4etg =
            {
                new Image { roomId = 27, image = File.ReadAllBytes(directoryName + "/Images/27DT2013Kontor.jpg") },
                new Image { roomId = 28, image = File.ReadAllBytes(directoryName + "/Images/28L�rerKontorB.jpg") },
                new Image { roomId = 29, image = File.ReadAllBytes(directoryName + "/Images/Heis.jpg") },
                new Image { roomId = 30, image = File.ReadAllBytes(directoryName + "/Images/28L�rerKontorB.jpg") },
                new Image { roomId = 31, image = File.ReadAllBytes(directoryName + "/Images/Heis.jpg") }

            };

            Item[] items =
            {
                new Item { id = 1, shortDesc = "Bok",  longDesc = "En bok om c# utvikling", locationType = "Room", locationTypeId = 1 },
                new Item { id = 2, shortDesc = "Bok",  longDesc = "En bok om systemdrift", locationType = "Room", locationTypeId = 1 },
                new Item { id = 3, shortDesc = "Bok",  longDesc = "En bok om Microsoft", locationType = "Room", locationTypeId = 1 },
                new Item { id = 4, shortDesc = "Bok",  longDesc = "En bok om Windows server", locationType = "Room", locationTypeId = 2 },
                new Item { id = 5, shortDesc = "Bok",  longDesc = "En bok om IIS", locationType = "Room", locationTypeId = 3 },
                new Item { id = 6, shortDesc = "Bok",  longDesc = "En bok om Azure", locationType = "Room", locationTypeId = 4 },
                new Item { id = 7, shortDesc = "Bok",  longDesc = "En bok om Hyper-V", locationType = "Room", locationTypeId = 5 },
                new Item { id = 8, shortDesc = "Bok",  longDesc = "En bok om sertifiseringer", locationType = "Room", locationTypeId = 6 },
                new Item { id = 9, shortDesc = "Bok",  longDesc = "En bok om HP AIS", locationType = "Room", locationTypeId = 7 },
                new Item { id = 10, shortDesc = "Bok",  longDesc = "En bok om Citrix XenApp", locationType = "Room", locationTypeId = 8 },
                new Item { id = 11, shortDesc = "Bok",  longDesc = "En bok om Visual Studio", locationType = "Room", locationTypeId = 9 },
                new Item { id = 12, shortDesc = "Bok",  longDesc = "En bok om Ignition", locationType = "Room", locationTypeId = 10 },
                new Item { id = 13, shortDesc = "Bok",  longDesc = "En bok om Siemens WinCC", locationType = "Room", locationTypeId = 11 },
                new Item { id = 14, shortDesc = "Bok",  longDesc = "En bok om Axis", locationType = "Room", locationTypeId = 12 },
                new Item { id = 15, shortDesc = "Bok",  longDesc = "En bok om VMWare", locationType = "Room", locationTypeId = 13 },
                new Item { id = 16, shortDesc = "Bok",  longDesc = "En bok om Havbruk", locationType = "Room", locationTypeId = 14 },
                new Item { id = 17, shortDesc = "Bok",  longDesc = "En bok om Nettverk", locationType = "Room", locationTypeId = 15 },
                new Item { id = 18, shortDesc = "Bok",  longDesc = "En bok om Tjenester", locationType = "Room", locationTypeId = 16 },
                new Item { id = 19, shortDesc = "Bok",  longDesc = "En bok om Sikkerhet", locationType = "Room", locationTypeId = 17 },
                new Item { id = 20, shortDesc = "Bok",  longDesc = "En bok om lastbalansering", locationType = "Room", locationTypeId = 18 },
                new Item { id = 21, shortDesc = "Bok",  longDesc = "En bok om HP 3par", locationType = "Room", locationTypeId = 19 },
            };

            Furniture[] furnitures =
            {
                new Furniture { id = 1, shortDesc = "Sofa",  longDesc = "En god og behagelig sofa", locationType = "Room", locationTypeId = 24 },
                new Furniture { id = 2, shortDesc = "Stol",  longDesc = "Pinnestol som raserer ryggraden", locationType = "Room", locationTypeId = 24 },
                new Furniture { id = 3, shortDesc = "Stol",  longDesc = "Rolls-Royce fra stol-industrien", locationType = "Room", locationTypeId = 24 }
            };

            context.room.AddOrUpdate(r => r.id, rooms1etg);
            context.room.AddOrUpdate(r => r.id, rooms2etg);
            context.room.AddOrUpdate(r => r.id, rooms3etg);
            context.room.AddOrUpdate(r => r.id, rooms4etg);
            context.item.AddOrUpdate(r => r.id, items);
            context.furniture.AddOrUpdate(r => r.id, furnitures);
            context.connection.AddOrUpdate(r => new { r.roomAId, r.roomBId }, connections1etg);
            context.connection.AddOrUpdate(r => new { r.roomAId, r.roomBId }, connections2etg);
            context.connection.AddOrUpdate(r => new { r.roomAId, r.roomBId }, connections3etg);
            context.connection.AddOrUpdate(r => new { r.roomAId, r.roomBId }, connections4etg);
            context.image.AddOrUpdate(r => r.roomId, images1etg);
            context.image.AddOrUpdate(r => r.roomId, images2etg);
            context.image.AddOrUpdate(r => r.roomId, images3etg);
            context.image.AddOrUpdate(r => r.roomId, images4etg);



        }
    }
}

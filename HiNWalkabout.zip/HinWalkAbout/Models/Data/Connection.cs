﻿using System.ComponentModel.DataAnnotations;

namespace HinWalkAbout.Models
{
    public class Connection
    {
        [Required]
        public int id { get; set; }

        [Required]
        public string type { get; set; }

        [Required]
        public string[] accessAB { get; set; }

        [Required]
        public string[] accessBA { get; set; }

        [Required]
        public string directionAB { get; set; }

        [Required]
        public string directionBA { get; set; }

        public double ulPosX { get; set; }
        public double ulPosY { get; set; }
        public double lrPosX { get; set; }
        public double lrPosY { get; set; }
        public bool visiblilty { get; set; }

        [Required]
        public int roomAId { get; set; }
        public virtual Room roomA { get; set; }

        [Required]
        public int roomBId { get; set; }
        public virtual Room roomB { get; set; }



    }
}
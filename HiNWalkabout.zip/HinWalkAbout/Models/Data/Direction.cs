﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Web;

namespace HinWalkAbout.Models {
    [ExcludeFromCodeCoverage]
    public class Direction {
        public Room DirectionNorth = null;
        public Room DirectionSouth = null;
        public Room DirectionWest = null;
        public Room DirectionEast = null;
        public Room DirectionUp = null;
        public Room DirectionDown = null;
    }
}
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace HinWalkAbout.Models
{
    public class Furniture
    {
        [Required]
        public int id { get; set; }

        [Required]
        public string shortDesc { get; set; }

        public string longDesc { get; set; }

        [Required]
        public string locationType { get; set; }
        public int locationTypeId { get; set; }
    }
}
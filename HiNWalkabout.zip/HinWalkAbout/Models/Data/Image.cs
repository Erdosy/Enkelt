﻿

namespace HinWalkAbout.Models
{
    public class Image
    {
        public int id { get; set; }
        public byte[] image { get; set; }

        public int roomId { get; set; }
        public virtual Room room { get; set; }
    }
}
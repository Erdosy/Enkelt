﻿using System.ComponentModel.DataAnnotations;

namespace HinWalkAbout.Models {
    public class Room {

        [Required]
        public int id { get; set; }

        [Required]
        public string roomNr { get; set; }

        [Required]
        public int etg { get; set; }

        [Required]
        public string name { get; set; }

        public string descShort { get; set; }
        public string descLong { get; set; }
        public double ulPosX { get; set; }
        public double ulPosY { get; set; }
        public double lrPosX { get; set; }
        public double lrPosY { get; set; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HinWalkAbout.Models {
    public class CommandInputModel {
        public string itemid { set; get; }
        public string command { set; get; }
    }
}
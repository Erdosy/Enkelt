﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HinWalkAbout.Models {
    public class FurnitureViewModel {
        public string shortDesc { set; get; }
        public string longDesc { set; get; }
        public string locationType { set; get; }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HinWalkAbout.Models {
    public class ItemsViewModel {

        public int id { set; get; }
        public string shortDesc { set; get; }
        public string longDesc { set; get; }
        public string locationType { set; get; }
        public string data { get; set; }
}
}
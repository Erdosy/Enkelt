﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace HinWalkAbout.Models {
    public class MovementViewModel {
        public string Timestamp { get; set; }
        public string UserName { get; set; }
        

        public int userLocation { get; set; }

        public int roomId { set; get; }
        public string roomName { set; get; }
        public string roomNumber { set; get; }
        public int roomFloor { set; get; }
        public string roomLongDesc { set; get; }
        public string roomShortDesc { set; get; }
        public byte[] roomImage { get; set; }

        public Boolean GameCompassNorth { get; set; }
        public Boolean GameCompassSouth { get; set; }
        public Boolean GameCompassWest { get; set; }
        public Boolean GameCompassEast { get; set; }
        public Boolean GameCompassUp { get; set; }
        public Boolean GameCompassDown { get; set; }


        public string roomNorthShortDesc { get; set; }
        public string roomSouthShortDesc { get; set; }
        public string roomWestShortDesc { get; set; }
        public string roomEastShortDesc { get; set; }
        public string roomUpShortDesc { get; set; }
        public string roomDownShortDesc { get; set; }


        public string roomNorthLongDesc { get; set; }
        public string roomSouthLongDesc { get; set; }
        public string roomWestLongDesc { get; set; }
        public string roomEastLongDesc { get; set; }
        public string roomUpLongDesc { get; set; }
        public string roomDownLongDesc { get; set; }
    }
}
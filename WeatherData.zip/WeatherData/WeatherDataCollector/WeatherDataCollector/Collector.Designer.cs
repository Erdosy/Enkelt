﻿namespace WeatherDataCollector
{
    partial class Collector
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnSettings = new System.Windows.Forms.Button();
            this.lblCollectIntervall = new System.Windows.Forms.Label();
            this.tbCollectIntervall = new System.Windows.Forms.TextBox();
            this.lblLog = new System.Windows.Forms.Label();
            this.rtbLog = new System.Windows.Forms.RichTextBox();
            this.lblTemp = new System.Windows.Forms.Label();
            this.panelTbox = new System.Windows.Forms.Panel();
            this.tbAtmPressMax = new System.Windows.Forms.TextBox();
            this.tbAtmPressMin = new System.Windows.Forms.TextBox();
            this.tbHumidMax = new System.Windows.Forms.TextBox();
            this.tbHumidMin = new System.Windows.Forms.TextBox();
            this.tbTempMax = new System.Windows.Forms.TextBox();
            this.tbTempMin = new System.Windows.Forms.TextBox();
            this.lblHumidity = new System.Windows.Forms.Label();
            this.lblAtmPressure = new System.Windows.Forms.Label();
            this.btnStartStop = new System.Windows.Forms.Button();
            this.panelTbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnSettings
            // 
            this.btnSettings.BackColor = System.Drawing.SystemColors.Control;
            this.btnSettings.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnSettings.Location = new System.Drawing.Point(159, 358);
            this.btnSettings.Name = "btnSettings";
            this.btnSettings.Size = new System.Drawing.Size(167, 30);
            this.btnSettings.TabIndex = 9;
            this.btnSettings.Text = "Change Settings";
            this.btnSettings.UseVisualStyleBackColor = false;
            this.btnSettings.Click += new System.EventHandler(this.btnSettings_Click);
            // 
            // lblCollectIntervall
            // 
            this.lblCollectIntervall.AutoSize = true;
            this.lblCollectIntervall.Location = new System.Drawing.Point(12, 245);
            this.lblCollectIntervall.Name = "lblCollectIntervall";
            this.lblCollectIntervall.Size = new System.Drawing.Size(141, 13);
            this.lblCollectIntervall.TabIndex = 1;
            this.lblCollectIntervall.Text = "Collect Intervall (times/hour):";
            // 
            // tbCollectIntervall
            // 
            this.tbCollectIntervall.Location = new System.Drawing.Point(0, 6);
            this.tbCollectIntervall.Name = "tbCollectIntervall";
            this.tbCollectIntervall.ReadOnly = true;
            this.tbCollectIntervall.Size = new System.Drawing.Size(167, 20);
            this.tbCollectIntervall.TabIndex = 1;
            // 
            // lblLog
            // 
            this.lblLog.AutoSize = true;
            this.lblLog.Location = new System.Drawing.Point(14, 12);
            this.lblLog.Name = "lblLog";
            this.lblLog.Size = new System.Drawing.Size(28, 13);
            this.lblLog.TabIndex = 5;
            this.lblLog.Text = "Log:";
            // 
            // rtbLog
            // 
            this.rtbLog.BackColor = System.Drawing.Color.White;
            this.rtbLog.Location = new System.Drawing.Point(48, 15);
            this.rtbLog.Name = "rtbLog";
            this.rtbLog.ReadOnly = true;
            this.rtbLog.Size = new System.Drawing.Size(278, 211);
            this.rtbLog.TabIndex = 1;
            this.rtbLog.Text = "";
            this.rtbLog.TextChanged += new System.EventHandler(this.rtbLog_TextChanged);
            // 
            // lblTemp
            // 
            this.lblTemp.AutoSize = true;
            this.lblTemp.Location = new System.Drawing.Point(12, 270);
            this.lblTemp.Name = "lblTemp";
            this.lblTemp.Size = new System.Drawing.Size(112, 13);
            this.lblTemp.TabIndex = 7;
            this.lblTemp.Text = "Temperature (Celsius);";
            // 
            // panelTbox
            // 
            this.panelTbox.Controls.Add(this.tbAtmPressMax);
            this.panelTbox.Controls.Add(this.tbAtmPressMin);
            this.panelTbox.Controls.Add(this.tbHumidMax);
            this.panelTbox.Controls.Add(this.tbHumidMin);
            this.panelTbox.Controls.Add(this.tbTempMax);
            this.panelTbox.Controls.Add(this.tbTempMin);
            this.panelTbox.Controls.Add(this.tbCollectIntervall);
            this.panelTbox.Location = new System.Drawing.Point(158, 232);
            this.panelTbox.Name = "panelTbox";
            this.panelTbox.Size = new System.Drawing.Size(173, 108);
            this.panelTbox.TabIndex = 9;
            // 
            // tbAtmPressMax
            // 
            this.tbAtmPressMax.Location = new System.Drawing.Point(90, 84);
            this.tbAtmPressMax.Name = "tbAtmPressMax";
            this.tbAtmPressMax.ReadOnly = true;
            this.tbAtmPressMax.Size = new System.Drawing.Size(77, 20);
            this.tbAtmPressMax.TabIndex = 7;
            // 
            // tbAtmPressMin
            // 
            this.tbAtmPressMin.Location = new System.Drawing.Point(0, 83);
            this.tbAtmPressMin.Name = "tbAtmPressMin";
            this.tbAtmPressMin.ReadOnly = true;
            this.tbAtmPressMin.Size = new System.Drawing.Size(74, 20);
            this.tbAtmPressMin.TabIndex = 6;
            // 
            // tbHumidMax
            // 
            this.tbHumidMax.Location = new System.Drawing.Point(90, 58);
            this.tbHumidMax.Name = "tbHumidMax";
            this.tbHumidMax.ReadOnly = true;
            this.tbHumidMax.Size = new System.Drawing.Size(77, 20);
            this.tbHumidMax.TabIndex = 5;
            // 
            // tbHumidMin
            // 
            this.tbHumidMin.Location = new System.Drawing.Point(0, 57);
            this.tbHumidMin.Name = "tbHumidMin";
            this.tbHumidMin.ReadOnly = true;
            this.tbHumidMin.Size = new System.Drawing.Size(74, 20);
            this.tbHumidMin.TabIndex = 4;
            // 
            // tbTempMax
            // 
            this.tbTempMax.Location = new System.Drawing.Point(90, 32);
            this.tbTempMax.Name = "tbTempMax";
            this.tbTempMax.ReadOnly = true;
            this.tbTempMax.Size = new System.Drawing.Size(77, 20);
            this.tbTempMax.TabIndex = 3;
            // 
            // tbTempMin
            // 
            this.tbTempMin.Location = new System.Drawing.Point(0, 31);
            this.tbTempMin.Name = "tbTempMin";
            this.tbTempMin.ReadOnly = true;
            this.tbTempMin.Size = new System.Drawing.Size(74, 20);
            this.tbTempMin.TabIndex = 2;
            // 
            // lblHumidity
            // 
            this.lblHumidity.AutoSize = true;
            this.lblHumidity.Location = new System.Drawing.Point(12, 295);
            this.lblHumidity.Name = "lblHumidity";
            this.lblHumidity.Size = new System.Drawing.Size(70, 13);
            this.lblHumidity.TabIndex = 10;
            this.lblHumidity.Text = "Humidity (%) :";
            // 
            // lblAtmPressure
            // 
            this.lblAtmPressure.AutoSize = true;
            this.lblAtmPressure.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.lblAtmPressure.Location = new System.Drawing.Point(12, 320);
            this.lblAtmPressure.Name = "lblAtmPressure";
            this.lblAtmPressure.Size = new System.Drawing.Size(140, 13);
            this.lblAtmPressure.TabIndex = 11;
            this.lblAtmPressure.Text = "Atmospheric pressure (mbar)";
            // 
            // btnStartStop
            // 
            this.btnStartStop.BackColor = System.Drawing.SystemColors.Control;
            this.btnStartStop.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.btnStartStop.Location = new System.Drawing.Point(17, 358);
            this.btnStartStop.Name = "btnStartStop";
            this.btnStartStop.Size = new System.Drawing.Size(124, 30);
            this.btnStartStop.TabIndex = 8;
            this.btnStartStop.Text = "Start collecting data";
            this.btnStartStop.UseVisualStyleBackColor = false;
            this.btnStartStop.Click += new System.EventHandler(this.btnStartStop_Click);
            // 
            // Collector
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(343, 400);
            this.Controls.Add(this.btnStartStop);
            this.Controls.Add(this.lblAtmPressure);
            this.Controls.Add(this.lblHumidity);
            this.Controls.Add(this.panelTbox);
            this.Controls.Add(this.btnSettings);
            this.Controls.Add(this.lblTemp);
            this.Controls.Add(this.lblCollectIntervall);
            this.Controls.Add(this.rtbLog);
            this.Controls.Add(this.lblLog);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.MaximumSize = new System.Drawing.Size(363, 443);
            this.MinimumSize = new System.Drawing.Size(363, 443);
            this.Name = "Collector";
            this.ShowIcon = false;
            this.Text = "Weather data collector";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Collector_FormClosing);
            this.panelTbox.ResumeLayout(false);
            this.panelTbox.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnSettings;
        private System.Windows.Forms.Label lblCollectIntervall;
        private System.Windows.Forms.TextBox tbCollectIntervall;
        private System.Windows.Forms.Label lblLog;
        private System.Windows.Forms.RichTextBox rtbLog;
        private System.Windows.Forms.Label lblTemp;
        private System.Windows.Forms.Panel panelTbox;
        private System.Windows.Forms.TextBox tbAtmPressMin;
        private System.Windows.Forms.TextBox tbHumidMax;
        private System.Windows.Forms.TextBox tbHumidMin;
        private System.Windows.Forms.TextBox tbTempMax;
        private System.Windows.Forms.TextBox tbTempMin;
        private System.Windows.Forms.Label lblHumidity;
        private System.Windows.Forms.Label lblAtmPressure;
        private System.Windows.Forms.TextBox tbAtmPressMax;
        private System.Windows.Forms.Button btnStartStop;
    }
}


﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Threading;

namespace WeatherDataCollector
{
    public partial class Collector : Form
    {
        private bool editEnabled; // Is edit mode enabled or not? 
        private float tempMin; // Min value for temperature
        private float tempMax; // Max value for temperature
        private float humidityMin; // Min value for humidity
        private float humidityMax; // Max value for humidity
        private float atmPressureMin; // Min value for atmospheric pressure
        private float atmPressureMax; // Max value for atmospheric pressure
        const String settingsFilePath = "Settings.dat"; // File for storing settings
        const String fileRootPath = "../../../../Output_data"; // Root path for data files
        private StreamReader input; // Streamreader for file input
        private StreamWriter output; // Streamwriter for file output
        private Data currentData; // struct for the latest reading
        public int intervall = 30; // Intervall. Times pr hour to update. 30 as default
        private Thread generationThread; // Thread for generating data
        private TimeThread generator; // Thread class for generating data
        delegate void Log(Data data); // Delegate for logging data from different thread


        public Collector()
        {
            InitializeComponent();
            rtbLog.AppendText(String.Format("{0:00}:{1:00} - Program Started\n", DateTime.Now.Hour, DateTime.Now.Minute));
            editEnabled = false;
            ReadSettingsFile(); // Reads settings from settings file
        }
        /// <summary>
        /// Reads settings from the file specified in settingsFilePath
        /// Puts the setting values into their corresponding textbox
        /// Creates Error dialog if setting file does not exist or isn't formatted correctly.
        /// Calls ReadSettings() to read values from textboxes.
        /// </summary>
        private void ReadSettingsFile()
        {
            if (File.Exists(settingsFilePath)) // Checks if settings file exists
            {
                input = new StreamReader(settingsFilePath); // Start input stream
                // String for every setting type
                String[] settingTypes = {"tempMin", "tempMax", "humidityMin",
                                        "humidityMax", "atmPressureMin", "atmPressureMax"};

                // Validates the settings file and inserts the settings values
                // Opens an error dialog if settings file isn't correct
                for (Byte i = 0; i < settingTypes.Length; i++)
                {
                    try
                    {
                        if (input.ReadLine().Equals(settingTypes[i]))
                        {
                            panelTbox.Controls[5 - i].Text = input.ReadLine();
                        }
                    }
                    catch (Exception exc)
                    {
                        ErrorDialog dialog = new ErrorDialog(exc.ToString() +
                                                "\nPlease choose settings and press save settings to start.");
                        dialog.ShowDialog();
                        enableEditing(editEnabled = true);
                        break;
                    }
                }
                tbCollectIntervall.Text = intervall.ToString();
                input.Close();
                ReadSettings();
            }
            else
            {
                // Create dialog form with error message
                ErrorDialog dialog = new ErrorDialog("No settings file found.\n" +
                                                    "Please choose settings and press save settings to start.");
                dialog.ShowDialog();
                enableEditing(editEnabled = false);
            }

        }

        /// <summary>
        /// Reads setting values from corresponding textboxes
        /// Checks if values are out of range and throws exception if they are
        /// Returns int value 0 if no fault and int value 1 if fault
        /// </summary>
        private int ReadSettings()
        {
            try
            {
                tempMin = float.Parse(tbTempMin.Text);
                tempMax = float.Parse(tbTempMax.Text);
                humidityMin = float.Parse(tbHumidMin.Text);
                humidityMax = float.Parse(tbHumidMax.Text);
                atmPressureMin = float.Parse(tbAtmPressMin.Text);
                atmPressureMax = float.Parse(tbAtmPressMax.Text);
                intervall = int.Parse(tbCollectIntervall.Text);

                if (tempMin < -50 || tempMin > tempMax)
                    throw new Exception("TempMin value is not allowed. Must be lower then TempMax and higher then -50.");
                if (tempMax > 50)
                    throw new Exception("TempMax value is not allowed. Must be lower then 50.");
                if (humidityMin < 0 || humidityMin > humidityMax)
                    throw new Exception("HumidityMin value is not allowed. Must be higher then 0 and lower then humidityMax.");
                if (humidityMax > 100)
                    throw new Exception("HumidityMax value is not allowed. Must be lower then 100.");
                if (atmPressureMin < 900 || atmPressureMin > atmPressureMax)
                    throw new Exception("AtmPressureMin value is not allowed. Must be higher then 900 and lower then AtmpressureMax");
                if (atmPressureMax > 1100)
                    throw new Exception("AtmPressureMax value is not allowed. Must be lower then 1100.");
                if (intervall < 1 || intervall > 60)
                    throw new Exception("You need to keep the intervall between 1 and 60");
            }
            catch (Exception exc)
            {
                ErrorDialog dialog = new ErrorDialog(exc.ToString());
                dialog.ShowDialog();
                return 1;
            }
            return 0;
        }

        /// <summary>
        /// Calls the enableEditing method
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnSettings_Click(object sender, EventArgs e)
        {
            enableEditing(editEnabled);
        }

        /// <summary>
        /// Enters or exits edit mode, depending on current mode.
        /// Changes status for textboxes in panelTbox, text on btnSettings,
        /// Enable status for btnStartStop and appends text to the rbtLog field.
        /// Calls SaveSettingsFile method, if edit mode was enabled.
        /// </summary>
        /// <param name="enable"> Used to see if program is in edit mode</param>
        private void enableEditing(Boolean enable)
        {
            if (enable) // Save settings
            {
                int i = ReadSettings();
                if (i == 0)
                {
                    foreach (TextBox textBox in panelTbox.Controls)
                    {
                        textBox.ReadOnly = true;
                    }
                    btnSettings.Text = "Change Settings";
                    editEnabled = false;
                    btnStartStop.Enabled = true;
                    rtbLog.AppendText(String.Format("{0:00}:{1:00} - Settings saved.\n", DateTime.Now.Hour, DateTime.Now.Minute));
                    SaveSettingsFile();
                }
            }
            else // Enter edit mode
            {
                foreach (TextBox textBox in panelTbox.Controls)
                {
                    textBox.ReadOnly = false;
                }
                btnSettings.Text = "Save Settings";
                editEnabled = true;
                btnStartStop.Enabled = false;
                rtbLog.AppendText(String.Format("{0:00}:{1:00} - Changing settings.\n", DateTime.Now.Hour, DateTime.Now.Minute));

            }
        }

        /// <summary>
        /// Saves the setting values to file. 
        /// Overwrites eventual old file.
        /// </summary>
        private void SaveSettingsFile()
        {
            try
            {
                output = new StreamWriter(settingsFilePath);
                output.WriteLine("tempMin");
                output.WriteLine(tbTempMin.Text);
                output.WriteLine("tempMax");
                output.WriteLine(tbTempMax.Text);
                output.WriteLine("humidityMin");
                output.WriteLine(tbHumidMin.Text);
                output.WriteLine("humidityMax");
                output.WriteLine(tbHumidMax.Text);
                output.WriteLine("atmPressureMin");
                output.WriteLine(tbAtmPressMin.Text);
                output.WriteLine("atmPressureMax");
                output.WriteLine(tbAtmPressMax.Text);
                output.Flush();
                output.Close();
            }
            catch (Exception exc)
            {
                ErrorDialog dialog = new ErrorDialog("Unexpected fault\n" + exc);
                dialog.ShowDialog();
            }
        }

        /// <summary>
        /// Starts/stops collection thread 
        /// Changes text on btnStartStop and Enabled status on btnSettings
        /// Opens dialogbox if unexpected fault.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnStartStop_Click(object sender, EventArgs e)
        {
            switch (btnStartStop.Text)
            {
                case "Start collecting data":
                    btnSettings.Enabled = false;
                    btnStartStop.Text = "Stop collecting data";
                    generator = new TimeThread(this);
                    generationThread = new Thread(new ThreadStart(generator.ThreadRun));
                    generationThread.IsBackground = true;
                    generationThread.Start();
                    break;
                case "Stop collecting data":
                    btnSettings.Enabled = true;
                    btnStartStop.Text = "Start collecting data";
                    generationThread.Abort();
                    break;
                case null:
                    ErrorDialog dialog = new ErrorDialog("Unexpected fault. I'm confused." +
                                            "\nPlease shut me down and let me rest for a bit.");
                    dialog.ShowDialog();
                    break;
            }
        }

        /// <summary>
        /// Generates data and outputs it into both log and output file
        /// </summary>
        public void GenerateData()
        {
            Random rnd = new Random();
            currentData.time = DateTime.Now;
            currentData.temperature = (float)(rnd.NextDouble() * (tempMax - tempMin) + tempMin);
            currentData.humidity = (float)(rnd.NextDouble() * (humidityMax - humidityMin) + humidityMin);
            currentData.atmPressure = (float)(rnd.NextDouble() * (atmPressureMax - atmPressureMin) + atmPressureMin);
            DataToLog(currentData);
            DataToFile(currentData);
        }

        /// <summary>
        /// Finds the right directory and file for output and then writes data to the file.
        /// Creates directories and files that need creating.
        /// </summary>
        /// <param name="currentData">The text to output to file</param>
        private void DataToFile(Data currentData)
        {
            String filePath = fileRootPath + "/" + currentData.time.Year + "/" + currentData.time.Month + "/" +
                                currentData.time.Day + "/";
            if (!Directory.Exists(filePath))
                Directory.CreateDirectory(filePath);
            String fileName = "t" + currentData.time.Hour + "_" + (currentData.time.Hour + 1) + ".dat";
            output = new StreamWriter(filePath + fileName, true);

            output.WriteLine(String.Format("{0:00}:{1:00} {2,6:00.00} {3,5:00.00} {4,5:0000.00}",
                        currentData.time.Hour, currentData.time.Minute, currentData.temperature,
                        currentData.humidity, currentData.atmPressure));
            output.Flush();
            output.Close();
        }

        /// <summary>
        /// Writes data to log.
        /// Checks to see if thread invoking is the creating thread, if not -> uses delegate to invoke.
        /// </summary>
        /// <param name="data"></param>
        private void DataToLog(Data data)
        {
            if (rtbLog.InvokeRequired)
            {
                Log d = new Log(DataToLog);
                Invoke(d, data);
            }
            else
            {

                rtbLog.AppendText(String.Format("{0:00}:{1:00} Temperature: {2,6:00.00}°C Humidity: {3,5:00.00}%" +
                                                " Atmospheric pressure: {4,5:0.00}mbar\n", currentData.time.Hour,
                                                currentData.time.Minute, currentData.temperature, currentData.humidity,
                                                currentData.atmPressure));
            }

        }

        /// <summary>
        /// Scrolls to end when text is entered into rbtLog.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void rtbLog_TextChanged(object sender, EventArgs e)
        {
            rtbLog.ScrollToCaret();
        }

        // Makes sure the generationThread closes when the program closes.
        private void Collector_FormClosing(object sender, FormClosingEventArgs e)
        {
            if(btnStartStop.Text == "Stop collecting data")
                btnStartStop_Click(btnStartStop, new EventArgs());       
        }

        /// <summary>
        /// Generates bogus data in main thread. Only used for testing.
        /// </summary>
        public void GenerateBogusData()
        {
            Random rnd = new Random();
            currentData.time = new DateTime(2014,12,01);
            
            for (int d = 0; d < 31; d++)
            {
                for (int h = 0; h < 24; h++)
                {
                    for (int m = 0; m < 60; m += 10)
                    {
                        currentData.time = currentData.time.AddMinutes(10);
                        currentData.temperature = (float)(rnd.NextDouble() * (tempMax - tempMin) + tempMin);
                        currentData.humidity = (float)(rnd.NextDouble() * (humidityMax - humidityMin) + humidityMin);
                        currentData.atmPressure = (float)(rnd.NextDouble() * (atmPressureMax - atmPressureMin) + atmPressureMin);
                        DataToLog(currentData);
                        DataToFile(currentData);
                    }
                }
            }

        }

    }



}


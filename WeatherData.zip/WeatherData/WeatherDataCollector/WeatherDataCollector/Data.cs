﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WeatherDataCollector
{
    /// <summary>
    /// Simple struct for data values
    /// </summary>
    public struct Data
    {
        public float temperature;
        public float humidity;
        public float atmPressure;
        public DateTime time;

    }
}

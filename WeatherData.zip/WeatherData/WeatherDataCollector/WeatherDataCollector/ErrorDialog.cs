﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WeatherDataCollector
{
    public partial class ErrorDialog : Form
    {
        public ErrorDialog(String errorMessage)
        {
            InitializeComponent();
            rtbErrorMessage.Text = errorMessage;
        }
        // Closes the form when OK is clicked.
        private void btnOK_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace WeatherDataCollector
{
    public class TimeThread
    {
        int wait; // Time to wait in miliseconds
        Collector collector; // Collector object to use

        /// <summary>
        /// Constructorfor TimeThread
        /// sets the collector object and wait time in miliseconds, based on intervall from collector object
        /// </summary>
        /// <param name="_collector"></param>
        public TimeThread(Collector _collector)
        {
            collector = _collector;
            wait = 3600000 / collector.intervall;
        }

        /// <summary>
        /// Running the thread. 
        /// Calling the GenerateData from collector object every wait miliseconds
        /// </summary>
        public void ThreadRun()
        {
            while (true)
            {
                collector.GenerateData();
                Thread.Sleep(wait);
            }

        }


    }
}

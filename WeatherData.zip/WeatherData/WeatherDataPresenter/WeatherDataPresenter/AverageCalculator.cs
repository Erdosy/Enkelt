﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Windows.Forms;

namespace WeatherDataPresenter
{
    class AverageCalculator
    {
        private DateTime startDate; // Start date for average calculation
        private DateTime endDate; // End date for average calculation
        private String fileRootPath; // Root file path for files
        private String currentDirectory; // Current working directory
        private String currentFile; // Current working file
        private StreamReader input; // Reads input from file
        private StreamWriter output; // Writes output to file

        /// <summary>
        /// Constructor for AverageCalculator
        /// </summary>
        /// <param name="_startDate">Start date</param>
        /// <param name="_endDate">End date</param>
        /// <param name="_fileRootPath">Root path for files</param>
        public AverageCalculator(DateTime _startDate, DateTime _endDate, String _fileRootPath)
        {
            startDate = _startDate;
            endDate = _endDate;
            fileRootPath = _fileRootPath;
        }

        /// <summary>
        /// Calculates and creates dAverage.dat files for every day in the time period specified
        /// in the AverageCalculator using the CalculateDayAverage method.
        /// Generates and shows an exception dialog for every day without available data.
        /// </summary>
        public void CalculateAverages()
        {
            while (startDate < endDate)
            {
                try
                {
                    currentDirectory = fileRootPath + "/" + startDate.Year + "/" + startDate.Month + "/" + startDate.Day + "/";
                    if (!Directory.Exists(currentDirectory))
                        throw new Exception("No data for " + currentDirectory);
                    if (!File.Exists(currentDirectory + "dAverage.dat"))
                    {
                        CalculateDayAverage(currentDirectory);
                    }
                }
                catch(Exception exc)
                {
                ThreadExceptionDialog diag = new ThreadExceptionDialog(exc);
                diag.ShowDialog();
                }
                startDate = startDate.AddDays(1);
            }
        }

        /// <summary>
        /// Calculates average values for an hour by going through all the lines in the hourly files.
        /// Outputs the result into the dAverage.dat file for the day.
        /// </summary>
        /// <param name="file"></param>
        void CalculateHourAverage(String directory, String file) 
        {
            int numberOfLines = 0; // variable for number of correct lines in file
            float sumOfTemperature = 0; // Sum for temperature of all correct lines in file
            float sumOfHumidity = 0; // Sum for humidity of all correct lines in file
            float sumOfAtmPressure = 0; // Sum for atmospheric pressure of all correct lines in file
            String data; // String to hold line by line of file
            input = new StreamReader(directory + file); // StreamReader to read the file
            
            //Goes through all the lines in the file
            while (!input.EndOfStream)
            {
                data = input.ReadLine();
                if (data.Length == 26) // Checks if line is expected length, else ignores line.
                {
                    sumOfTemperature += float.Parse(data.Substring(6, 6));
                    sumOfHumidity += float.Parse(data.Substring(13, 5));
                    sumOfAtmPressure += float.Parse(data.Substring(19, 7));
                    numberOfLines++;
                }
            }
            output = new StreamWriter(currentDirectory + "dAverage.dat", true);
            output.WriteLine(file.Substring(1,2) + "\t" + sumOfTemperature / numberOfLines + "\t" + sumOfHumidity / numberOfLines + 
                                "\t" + sumOfAtmPressure / numberOfLines);
            output.Close();
            input.Close();
        }

        /// <summary>
        /// Calculates the day average, first invoking the CalculateHourAverage method for every hour.
        /// </summary>
        /// <param name="directory"></param>
        void CalculateDayAverage(String directory)
        {
            for (int i = 0; i < 24; i++)
            {
                currentFile = "t" + i + "_" + (i + 1) + ".dat";
                if (File.Exists(currentDirectory + currentFile))
                {
                    CalculateHourAverage(currentDirectory, currentFile);
                }
            }
        }
    }
}

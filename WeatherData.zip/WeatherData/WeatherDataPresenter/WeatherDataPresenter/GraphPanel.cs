﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing;

namespace WeatherDataPresenter
{
    class GraphPanel : Panel
    {
        Graphics g; // Graphics for drawing
        Pen myPen; // Pen used for drawing
        int xZero; // x zero point in graph
        int yZero; // y zero point in graph
        int xWidth; // width of graph area
        int yHeight; // height of graph area
        Data[] data; // Data array holding weather data
        Boolean drawTemp = false; // Draw temperature graph?
        Boolean drawHumid = false; // Draw humidity graph?
        Boolean drawAtmPress = false; // Draw atmospheric pressure graph?

        /// <summary>
        /// Constructor with parameters.
        /// </summary>
        /// <param name="_data">Data array with weather data</param>
        /// <param name="_drawTemp">Draw temperature graph?</param>
        /// <param name="_drawHumid">Draw humidity graph?</param>
        /// <param name="_drawAtmPress">Draw atmospheric pressure graph?</param>
        public GraphPanel(Data[] _data, Boolean _drawTemp, Boolean _drawHumid, Boolean _drawAtmPress) : this()
        {
            drawTemp = _drawTemp;
            drawHumid = _drawHumid;
            drawAtmPress = _drawAtmPress;
            data = _data;
            
        }

        /// <summary>
        /// Base constructor
        /// </summary>
        public GraphPanel() : base() 
        {
            xWidth = 430;
            xZero = 30;
            yHeight = 350;
            yZero = 30;
        }

        /// <summary>
        /// Draws the graph panel
        /// Draws the graph to the selected types
        /// </summary>
        /// <param name="paintEvnt"></param>
        protected override void OnPaint(PaintEventArgs paintEvnt)
        {
            g = paintEvnt.Graphics;
            myPen = new Pen(Color.Black);
            g.DrawLine(myPen, xZero, yZero, xZero, yZero + yHeight);
            g.DrawLine(myPen, xZero, yZero + yHeight, xZero + xWidth, yZero + yHeight);
            g.DrawLine(myPen, xZero - 5, yZero + 5, xZero, yZero);
            g.DrawLine(myPen, xZero + 5, yZero + 5, xZero, yZero);
            g.DrawLine(myPen, xZero + xWidth - 5, yZero + yHeight - 5, xZero + xWidth, yZero + yHeight);
            g.DrawLine(myPen, xZero + xWidth - 5, yZero + yHeight + 5, xZero + xWidth, yZero + yHeight);
            if(drawAtmPress)
                DrawAtmPress(g);
            if(drawTemp)
                DrawTemp(g);
            if(drawHumid)
                   DrawHumid(g);

        }


        /// <summary>
        /// Draw the graph for temperature.
        /// FUNGERER IKKE!
        /// </summary>
        /// <param name="_g"></param>
        void DrawTemp(Graphics _g)
        {
            myPen = new Pen(Color.Red);
            g = _g;
            int numberofValues = data.Length;
            float lowestvalue = 0;
            float highestvalue = 0;
            foreach (Data value in data)
            {
                if (value.temperature < lowestvalue)
                    lowestvalue = value.temperature;
                if (value.temperature > highestvalue)
                    highestvalue = value.temperature;
            }
            float valueSpan = highestvalue - lowestvalue;
            float pointsForValue = yHeight / valueSpan;
            float pointsForNumber = xWidth / numberofValues;
            List<Point> points = new List<Point>();
            for (int i = 0; i < data.Length; i++)
            {
                if (!data[i].Equals(null))
                {
                    points.Add(new Point((int)(i * pointsForNumber), (int)(data[i].temperature * pointsForValue)));
                }
            }
            Point[] pointArray = new Point[points.Count];
            for (int i = 0; i < points.Count; i++)
            {
                pointArray[i].X = xZero + xWidth - points[i].X;
                pointArray[i].Y = yZero + yHeight - points[i].Y;
            }
            g.DrawLines(myPen, pointArray);
            g.DrawLine(myPen, xWidth + 40, yZero, xWidth + 40, yZero + yHeight);
            g.DrawString(String.Format("{0:0.0}" ,lowestvalue + valueSpan/2) , new Font("Ariel", 10), new SolidBrush(Color.Red), new Point(xWidth + 40, xZero + yHeight/2 ));
                

            g.DrawString("Dette er temp, fikk ikke til å vise grafen riktig", new Font("Arial",16) , new SolidBrush(Color.Red), new Point(10, 20));
        }

        /// <summary>
        /// Draw the graph for humidity
        /// SAMME SOM TEMPERATURE
        /// </summary>
        /// <param name="_g"></param>
        void DrawHumid(Graphics _g)
        {
            g = _g;
            g.DrawString("Dette er humid, fikk ikke til å vise grafen riktig", new Font("Arial", 16), new SolidBrush(Color.Blue), new Point(10,50));
        }

        /// <summary>
        /// Draw the graph for atmospheric pressure
        /// SAMME SOM TEMPERATURE
        /// </summary>
        /// <param name="_g"></param>
        void DrawAtmPress(Graphics _g)
        {
            g = _g;
            g.DrawString("Dette er atm press, fikk ikke til  vise grafen riktig", new Font("Arial", 16), new SolidBrush(Color.Green), new Point(10, 80));
        }

    }





}

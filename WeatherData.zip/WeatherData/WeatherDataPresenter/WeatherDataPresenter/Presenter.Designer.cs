﻿namespace WeatherDataPresenter
{
    partial class presenter
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.calendar = new System.Windows.Forms.MonthCalendar();
            this.btnDraw = new System.Windows.Forms.Button();
            this.chkbxTemperature = new System.Windows.Forms.CheckBox();
            this.chkbxHumidity = new System.Windows.Forms.CheckBox();
            this.chkbxAtmPress = new System.Windows.Forms.CheckBox();
            this.rtbText = new System.Windows.Forms.RichTextBox();
            this.panelGraph = new WeatherDataPresenter.GraphPanel();
            this.SuspendLayout();
            // 
            // calendar
            // 
            this.calendar.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.calendar.BackColor = System.Drawing.SystemColors.Window;
            this.calendar.Location = new System.Drawing.Point(18, 18);
            this.calendar.MaxDate = new System.DateTime(2099, 12, 31, 0, 0, 0, 0);
            this.calendar.MaxSelectionCount = 31;
            this.calendar.MinDate = new System.DateTime(2000, 1, 1, 0, 0, 0, 0);
            this.calendar.Name = "calendar";
            this.calendar.ShowToday = false;
            this.calendar.ShowTodayCircle = false;
            this.calendar.ShowWeekNumbers = true;
            this.calendar.TabIndex = 0;
            this.calendar.DateChanged += new System.Windows.Forms.DateRangeEventHandler(this.calendar_DateChanged);
            // 
            // btnDraw
            // 
            this.btnDraw.Location = new System.Drawing.Point(185, 215);
            this.btnDraw.Name = "btnDraw";
            this.btnDraw.Size = new System.Drawing.Size(75, 23);
            this.btnDraw.TabIndex = 2;
            this.btnDraw.Text = "Draw graphs";
            this.btnDraw.UseVisualStyleBackColor = true;
            this.btnDraw.Click += new System.EventHandler(this.btnDraw_Click);
            // 
            // chkbxTemperature
            // 
            this.chkbxTemperature.AutoSize = true;
            this.chkbxTemperature.ForeColor = System.Drawing.Color.Red;
            this.chkbxTemperature.Location = new System.Drawing.Point(12, 192);
            this.chkbxTemperature.Name = "chkbxTemperature";
            this.chkbxTemperature.Size = new System.Drawing.Size(112, 17);
            this.chkbxTemperature.TabIndex = 0;
            this.chkbxTemperature.Text = "Show temperature";
            this.chkbxTemperature.UseVisualStyleBackColor = true;
            // 
            // chkbxHumidity
            // 
            this.chkbxHumidity.AutoSize = true;
            this.chkbxHumidity.ForeColor = System.Drawing.Color.Blue;
            this.chkbxHumidity.Location = new System.Drawing.Point(166, 192);
            this.chkbxHumidity.Name = "chkbxHumidity";
            this.chkbxHumidity.Size = new System.Drawing.Size(94, 17);
            this.chkbxHumidity.TabIndex = 4;
            this.chkbxHumidity.Text = "Show humidity";
            this.chkbxHumidity.UseVisualStyleBackColor = true;
            // 
            // chkbxAtmPress
            // 
            this.chkbxAtmPress.AutoSize = true;
            this.chkbxAtmPress.ForeColor = System.Drawing.Color.Green;
            this.chkbxAtmPress.Location = new System.Drawing.Point(12, 215);
            this.chkbxAtmPress.Name = "chkbxAtmPress";
            this.chkbxAtmPress.Size = new System.Drawing.Size(156, 17);
            this.chkbxAtmPress.TabIndex = 5;
            this.chkbxAtmPress.Text = "Show atmospheric pressure";
            this.chkbxAtmPress.UseVisualStyleBackColor = true;
            // 
            // rtbText
            // 
            this.rtbText.Location = new System.Drawing.Point(3, 237);
            this.rtbText.Name = "rtbText";
            this.rtbText.Size = new System.Drawing.Size(263, 175);
            this.rtbText.TabIndex = 7;
            this.rtbText.Text = "";
            // 
            // panelGraph
            // 
            this.panelGraph.Location = new System.Drawing.Point(266, 18);
            this.panelGraph.Name = "panelGraph";
            this.panelGraph.Size = new System.Drawing.Size(585, 395);
            this.panelGraph.TabIndex = 6;
            // 
            // presenter
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(854, 416);
            this.Controls.Add(this.rtbText);
            this.Controls.Add(this.chkbxAtmPress);
            this.Controls.Add(this.chkbxHumidity);
            this.Controls.Add(this.chkbxTemperature);
            this.Controls.Add(this.panelGraph);
            this.Controls.Add(this.btnDraw);
            this.Controls.Add(this.calendar);
            this.MaximizeBox = false;
            this.Name = "presenter";
            this.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.ShowIcon = false;
            this.Text = "Presenter";
            this.Load += new System.EventHandler(this.Presenter_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MonthCalendar calendar;
        private System.Windows.Forms.Button btnDraw;
        private GraphPanel panelGraph;
        private System.Windows.Forms.CheckBox chkbxTemperature;
        private System.Windows.Forms.CheckBox chkbxHumidity;
        private System.Windows.Forms.CheckBox chkbxAtmPress;
        private System.Windows.Forms.RichTextBox rtbText;



    }
}


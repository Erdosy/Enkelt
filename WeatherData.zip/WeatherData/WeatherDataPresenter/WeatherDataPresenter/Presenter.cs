﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.Windows.Forms;
using System.IO;

namespace WeatherDataPresenter
{
    public partial class presenter : Form
    {
        String fileRootPath = "../../../../Output_data/"; // Root path for files
        Data[] data; // Data array for weather data 
        StreamReader input; // Reader for input from file

        public presenter()
        {

            InitializeComponent();



        }

        private void Presenter_Load(object sender, EventArgs e)
        {


        }

        /// <summary>
        /// Reads data from selected dates into data array.
        /// Removes current graphPanel
        /// Sends data and selection with graphs to draw to the graphPanel constructor.
        /// Redraws new graphPanel
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnDraw_Click(object sender, EventArgs e)
        {
            ReadData();
            panelGraph.Dispose();
            panelGraph = new GraphPanel(data, chkbxTemperature.Checked, chkbxHumidity.Checked, chkbxAtmPress.Checked);
            panelGraph.Location = new System.Drawing.Point(266, 18);
            panelGraph.Name = "panelGraph";
            panelGraph.Size = new System.Drawing.Size(585, 395);
            Controls.Add(this.panelGraph);
            DataToText();
        }

        /// <summary>
        /// Reads data from selected dates into data array.
        /// </summary>
        private void ReadData()
        {
            DateTime start = calendar.SelectionStart;
            DateTime end = calendar.SelectionEnd;
            Console.WriteLine(start);
            Console.WriteLine(end);
            TimeSpan period = end - start;
            data = new Data[(period.Days + 1) * 24];
            Console.WriteLine(data.Length);
            int dayNumber = 0;
            int index;
            while (start < end)
            {
                input = new StreamReader(fileRootPath + start.Year + "/" + start.Month + "/" + start.Day + "/dAverage.dat");
                while (!input.EndOfStream)
                {
                    String inputString = input.ReadLine();
                    index = int.Parse(inputString.Substring(0, 2)) + (24 * dayNumber);
                    data[index].temperature = float.Parse(inputString.Substring(3, 10));
                    data[index].humidity = float.Parse(inputString.Substring(14, 8));
                    data[index].atmPressure = float.Parse(inputString.Substring(23, 8));
                    data[index].time = start;
                    data[index].time = data[index].time.AddHours(index - (24 * dayNumber));
                }
                start = start.AddDays(1);
                dayNumber++;
            }

            



        }

        /// <summary>
        /// Creates a new thread to handle the CalculateAverages method from AverageCalculator
        /// when date is changed on calendar.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void calendar_DateChanged(object sender, DateRangeEventArgs e)
        {
            AverageCalculator calc = new AverageCalculator(calendar.SelectionStart, calendar.SelectionEnd, fileRootPath);
            Thread t1 = new Thread(new ThreadStart(calc.CalculateAverages));
            t1.Start();
        }

        /// <summary>
        /// Writes the data to rtbText.
        /// Old text is removed so it's only current data that's being displayed
        /// </summary>
        private void DataToText()
        {
            rtbText.Clear();
            foreach (Data weatherData in data)
            {
                if(weatherData.atmPressure > 0)
                    rtbText.AppendText(String.Format("{0:00}/{1:00}:{2:00} -{3:0.0}°C, {4:0.0}%, {5:0.0}mbar\n", 
                                                weatherData.time.Day, weatherData.time.Month, weatherData.time.Hour, 
                                                weatherData.temperature, weatherData.humidity, weatherData.atmPressure));
            }
        }

    }
}
